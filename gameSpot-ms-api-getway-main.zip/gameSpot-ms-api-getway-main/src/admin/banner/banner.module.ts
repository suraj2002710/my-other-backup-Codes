import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { BannerService } from "./banner.service";
import { BannerController } from "./banner.controller";


@Module({
    imports: [ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'USER_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig?.HOST_USER,
                port: <any>CommonConfig?.PORT_USER
            }
        },
        {
            name: 'ADMIN_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig.HOST_ADMIN,
                port: <any>CommonConfig.PORT_ADMIN
            }
        },
    ])],
    providers: [BannerService],
    controllers: [BannerController]
})
export class BannerModule { }