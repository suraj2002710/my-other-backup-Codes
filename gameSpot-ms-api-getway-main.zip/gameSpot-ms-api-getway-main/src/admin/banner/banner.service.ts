import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";

@Injectable()
export class BannerService{
    constructor(@Inject("ADMIN_MICROSERVICES") readonly adminClientProxy: ClientProxy
){}

    async createbanner(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'createbanner' }, payload);
    }

    async updateBanner(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'updateBanner' }, payload);
    }

    async getsingleBanner(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'getsingleBanner' }, payload);
    }

    async getBanner(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'getBanner' }, payload);
    }

    async deleteBanner(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'deleteBanner' }, payload);
    }

}