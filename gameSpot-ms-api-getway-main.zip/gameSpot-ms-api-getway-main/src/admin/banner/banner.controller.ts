import { Controller, Delete, Get, Post, Req, UseInterceptors } from "@nestjs/common";
import { BannerService } from "./banner.service";
import { CommonConfig } from "src/config/CommanConfig";
import { PayloadHelper } from "src/utils/Payload";
import { FileInterceptor } from "@nestjs/platform-express";

@Controller(`${CommonConfig.API_ADMIN_URL}banner`)
export class BannerController{
    constructor(private readonly BannerService:BannerService){}

    @UseInterceptors(FileInterceptor('banner'))
    @Post("createbanner")
    async BankDetail_approval(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.BannerService.createbanner(getPayload);
    }

    @UseInterceptors(FileInterceptor('banner'))
    @Post("updateBanner")
    async updateBanner(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.BannerService.updateBanner(getPayload);
    }


    @Get("single-banner/:id")
    async getsingleBanner(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.BannerService.getsingleBanner(getPayload);
    }


    @Post("getall-banner")
    async getBanner(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.BannerService.getBanner(getPayload);
    }

    @Delete("delete/:delete_id")
    async deleteBanner(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.BannerService.deleteBanner(getPayload);
    }
}