import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AdminGamesService {
    constructor(@Inject("GAME_MICROSERVICES") readonly authClientProxy: ClientProxy) { }

    async game_list(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_list' }, payload);
    }

}