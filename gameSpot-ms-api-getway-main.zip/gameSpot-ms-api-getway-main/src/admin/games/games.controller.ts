import { Controller, Post, Req } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { AdminGamesService } from "./games.service";


@Controller(`${CommonConfig.API_ADMIN_URL}game`)
export class AdminUsersController {
    constructor(private readonly AdminGameService: AdminGamesService) { }
    @Post("game_list")
    async game_list(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminGameService.game_list(getPayload);
    }
}