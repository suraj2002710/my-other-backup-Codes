import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { AdminUsersController } from "./user.controller";
import { AdminUsersService } from "./usrs.service";

@Module({
    imports:[ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'USER_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig?.HOST_USER,
                port: <any>CommonConfig?.PORT_USER
            }
        },
        {
            name: 'ADMIN_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig.HOST_ADMIN,
                port: <any>CommonConfig.PORT_ADMIN
            }
        },
    ])],
    providers:[AdminUsersService],
    controllers: [AdminUsersController]
})
export class AdminUserModule{}