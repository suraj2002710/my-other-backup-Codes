import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { JwtAuthGuard } from "../auth/gaurd/jwtguard";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { FileInterceptor } from "@nestjs/platform-express";
import { FantasyService } from "./fantasy.service";

// @UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_ADMIN_URL}fantasy`)
export class FantasyController{

    constructor(private readonly FantasyService: FantasyService){}

    @Post('create_tournaments')
    async create_tournaments(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.create_tournaments(getPayload);
    }

    @Post('create_contestType')
    async create_contestType(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.create_contestType(getPayload);
    }

    @Post('createTeam')
    async createTeam(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.createTeam(getPayload);
    }

    @Post('createPlayer')
    async createPlayer(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.createPlayer(getPayload);
    }

    @Get('fetchAndStoreMatches')
    async fetchAndStoreMatches(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.fetchAndStoreMatches(getPayload);
    }

}
