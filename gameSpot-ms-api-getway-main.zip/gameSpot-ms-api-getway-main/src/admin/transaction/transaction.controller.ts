import { Controller, Get, Post, Req } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { AdminTransactionService } from "./transaction.service";


@Controller(`${CommonConfig.API_ADMIN_URL}transaction`)
export class AdminTransactionController {
    constructor(private readonly AdminTransaction: AdminTransactionService) { }
    @Post("get-transaction-list")
    async get_with_drawle_request(@Req() request: any) {
        const getPayload = await PayloadHelper(request);
        return await this.AdminTransaction.get_with_drawle_request(getPayload);
    }

    @Post("accpect_withdrawle")
    async accpect_withdrawle(@Req() request: any) {
        const getPayload = await PayloadHelper(request);
        return await this.AdminTransaction.accpect_withdrawle(getPayload);
    }

    @Get("single/:transaction_id")
    async get_single_transaction(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminTransaction.get_single_transaction(getPayload);
    }

    @Get("withdraw-request-list")
    async withdrawle_request_List(@Req() request: any) {
        console.log("withdrawle-request-list")
        const getPayload = await PayloadHelper(request);
        return await this.AdminTransaction.get_withdrawle_request_List(getPayload);
    }

    @Post("withdraw_approval")
    async withdraw_request_approval(@Req() request: any) {
        console.log("withdraw/approval")
        const getPayload = await PayloadHelper(request);
        return await this.AdminTransaction.withdraw_request_approval(getPayload);
    }
}