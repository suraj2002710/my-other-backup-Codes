import {Inject, Injectable} from "@nestjs/common"
import { JwtService } from "@nestjs/jwt";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AdminAuthServices{
    constructor(@Inject("AUTH_MICROSERVICES") private authClientProxy :ClientProxy,
        private jwtService: JwtService,
    ){}

   

    async login(payload: any) {
        payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        console.log(payload)
    
        return await this.authClientProxy.send({ cmd: 'admin_login' }, payload);
    }

    async send_login_otp(payload: any) {
        
    
        return await this.authClientProxy.send({ cmd: 'send_login_otp' }, payload);
    }

    async login_otp_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'login_otp_verify' }, payload);
    }

    async generate_token(payload: any) {
        console.log(payload , 'token');
        
        return await this.jwtService.sign(payload);
    }
}
