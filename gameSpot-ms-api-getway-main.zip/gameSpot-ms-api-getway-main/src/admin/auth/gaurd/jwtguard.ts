import { ExecutionContext, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { AuthGuard } from '@nestjs/passport';
import { StatusCode, StatusMessage } from "../../../constants/HttpConstant";
import { async } from 'rxjs';
import { InjectModel } from '@nestjs/mongoose';

import { Model } from 'mongoose';
import { Users } from 'src/schema/user.schema';

@Injectable()
/* ==== Jwt auth guard start ===== */
export class JwtAuthGuard extends AuthGuard('apijwt') {
    constructor(
        @Inject('AUTH_MICROSERVICES') private readonly authClientProxy: ClientProxy,
        @InjectModel(Users.name) private readonly UsersModel: Model<Users>,

    ) {
        super();
    }

    async canActivate(context: ExecutionContext): Promise<any> {
        try {
            await super.canActivate(context);
            const request = context.switchToHttp().getRequest();
            let bearer_token = null;
            if (request?.headers?.authorization) {
                bearer_token = request?.headers?.authorization
                bearer_token = bearer_token.replace("Bearer ", "");
                bearer_token = bearer_token.replace(' ', '');
            }
            if (bearer_token) {
                console.log(bearer_token, request?.user);
                
                const user_is_validate: any = await this.UsersModel.findOne({ _id: request?.user?.id, status: 1 }).exec();
                //const user_is_validate = await this.authClientProxy.send({ cmd: 'user_is_validate_middleware' }, request?.user).toPromise();
                console.log(user_is_validate);
                
                if (user_is_validate?.status) {
                    return super.canActivate(context);
                }
                else {
                    throw new UnauthorizedException({
                        custom_code: StatusCode?.HTTP_UNAUTHORIZED,
                        custom_message: StatusMessage?.HTTP_UNAUTHORIZED
                    });
                }
            }
            else {
                throw new UnauthorizedException({
                    custom_code: StatusCode?.HTTP_UNAUTHORIZED,
                    custom_message: StatusMessage?.HTTP_UNAUTHORIZED
                });
            }
        } catch (err) {
            throw err || new UnauthorizedException({
                custom_code: StatusCode?.HTTP_UNAUTHORIZED,
                custom_message: StatusMessage?.HTTP_UNAUTHORIZED
            });
        }
    }

    handleRequest(err: any, user: any, info: any) {
        if (err || !user) {
            throw err || new UnauthorizedException({
                custom_code: StatusCode?.HTTP_TOKEN_EXPIRED,
                custom_message: StatusMessage?.HTTP_TOKEN_EXPIRED
            });
        }
        return user;
    }
}
/* ==== Jwt auth guard end ===== */