import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";
import { AdminAuthServices } from "./auth.service";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";

import { JwtAuthGuard } from "./gaurd/jwtguard";
import { FileInterceptor } from "@nestjs/platform-express";


@Controller(CommonConfig.API_ADMIN_URL)
export class AdminAuthController{
    constructor(private readonly AdminAuthServices:AdminAuthServices){}
    

    @Post('login')
    async login(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.AdminAuthServices.login(getPayload);
    }

    @Post('send-login-otp')
    async send_login_otp(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.AdminAuthServices.send_login_otp(getPayload);
    }

    @Post('verify-login-otp')
    async login_otp_verify(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.AdminAuthServices.login_otp_verify(getPayload);
    }

    

}