import { Module } from "@nestjs/common";
import { AdminAuthServices } from "./auth.service";
import { AdminAuthController } from "./auth.controller";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";
import { JwtStrategy } from "./strategies/Jwt.startegies";
import { Admin, AdminSchema } from "src/schema/admin.schema";

@Module({
    imports:[
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'AUTH_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_AUTH,
                    port: <any>CommonConfig?.PORT_AUTH
                }
            },
            
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
        ,
        MongooseModule.forFeature([{ name: Admin.name, schema: AdminSchema }]),
    ],
    providers: [AdminAuthServices, JwtStrategy],
    controllers:[AdminAuthController]
})
export class AdminAuthModule{}