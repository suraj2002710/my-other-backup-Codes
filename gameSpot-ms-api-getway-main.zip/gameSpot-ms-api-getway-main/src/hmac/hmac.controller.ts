// your.controller.ts
import { Controller, Post, Body } from '@nestjs/common';
import { HmacService } from './hmac.service';

@Controller('example')
export class HmacController {
    constructor(private readonly hmacService: HmacService) { }

    @Post('verify')
    verifyData(@Body() body: any) {
        const secret = 'ludoludoludoludoludoludo';
        const receivedHmac = body.hmac;
        const data = body.data;
        const calculatedHmac = this.hmacService.generateHmac(secret, data);

        if (calculatedHmac === receivedHmac) {
            return { success: true, message: 'HMAC verified successfully' };
        } else {
            return { success: false, message: 'HMAC verification failed' };
        }
    }
}
