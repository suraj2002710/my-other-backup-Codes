import {OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage, WebSocketGateway,WebSocketServer} from '@nestjs/websockets'
import { Server, Socket } from 'socket.io'
import { CommonConfig } from 'src/config/CommanConfig';


@WebSocketGateway(<any>parseInt(CommonConfig.SCOKET_PORT), { cors: true })
export class SocketGateway implements OnGatewayConnection, OnGatewayDisconnect{
    @WebSocketServer() server:Server;
    private users=new Map
    handleConnection(socket:Socket){
        console.log('connect socket id', socket.id)
    }
    handleDisconnect(socket:Socket) {
        console.log('connect socket id', socket.id)
    }

    @SubscribeMessage('join')
    handleJoin(socket:Socket,data:any){
        this.users.set(data?.joiner_id,socket.id)
        console.log("joinjoinjoinjoinjoinjoin=============>>>>>>>>",data,this.users)
    }
    
    @SubscribeMessage('snd-running-battle')
    handleRunning(socket: Socket,data:any){
        console.log(data,socket.id)
        let socketid=this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if(socket){
            socket.broadcast.emit("recev-running-battle",data)
        }
    }

    @SubscribeMessage('snd-open-battle')
    handleOpenBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if (socket) {
            socket.broadcast.emit("recev-open-battle", data)
        }
    }

    @SubscribeMessage('snd-create-battle')
    handleCreateBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if (socket) {
            socket.broadcast.emit("recev-create-battle", data)
        }
    }

    @SubscribeMessage('snd-challange-accpect')
    handleAccpectBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid,this.users);
        if (socketid) {
            this.server.to(socketid).emit("recev-challange-accpect", data)
        }
    }

    @SubscribeMessage('snd-challange-reject')
    handlerejectBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid,this.users);
        if (socketid) {
            this.server.to(socketid).emit("recev-challange-reject", data)
        }
    }

    @SubscribeMessage('snd-delete-battle')
    handleDeleteBattel(socket: Socket, data: any) {
        // console.log(data, socket.id)
        // let socketid = this.users.get(data.receiver_id)
        // console.log("socketid", socketid);
        // if (socket) {
            socket.broadcast.emit("recev-delete-battle", data)
        // }
    }

    @SubscribeMessage('snd-challange-running')
    handleRunningBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("snd-challange-running", socketid);
        if (socketid) {
            this.server.to(socketid).emit("recev-challange-running", data)
        }
    }

    @SubscribeMessage('snd-challange-update')
    handleUpdateBattel(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if (socketid) {
            this.server.to(socketid).emit("recev-challange-update", data)
        }
    }

    @SubscribeMessage('snd-update-roomcode')
    handleUpdatecode(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if (socketid) {
            this.server.to(socketid).emit("recev-update-roomcode", data.data)
        }
    }

    @SubscribeMessage('snd-cancel-battle')
    handlecancelcode(socket: Socket, data: any) {
        console.log(data, socket.id)
        let socketid = this.users.get(data.receiver_id)
        console.log("socketid", socketid);
        if (socketid) {
            this.server.to(socketid).emit("recev-cancel-battle", data.data)
        }
    }

    
}