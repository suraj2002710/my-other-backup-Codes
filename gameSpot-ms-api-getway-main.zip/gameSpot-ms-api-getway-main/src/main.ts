import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { CommonConfig } from './config/CommanConfig';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors()
  


  await app.listen(CommonConfig.PORT_API_GATEWAY);
}
bootstrap();
