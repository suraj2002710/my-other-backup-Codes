import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";

import { ReferalServices } from "./referal.service";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";


@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}referal-code`)
export class ReferalController {
    constructor(private readonly ReferalServices: ReferalServices) { }
    @Post('referal-code-update')
    async referal_code_update(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.ReferalServices.referal_code_update(getPayload);
    }


    @Post('get_referal_earning')
    async get_referal_earning(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.ReferalServices.get_referal_earning(getPayload);
    }

    @Post('get_referal_history')
    async get_referal_history(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.ReferalServices.get_referal_history(getPayload);
    }

    @Post('reedem')
    async reedem(@Req() request: Request) {
        console.log("reedem")
        const getPayload = await PayloadHelper(request);
        return await this.ReferalServices.reedem(getPayload);
    }

}