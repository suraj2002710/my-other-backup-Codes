import { Body, Controller, Post, Req, UseGuards } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { User_BankDetail_Service } from "./bank_details.service";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}bank-detail`)
export class User_BankDetail_Controller {
    constructor(private readonly User_BankDetail_Service: User_BankDetail_Service) { }

    @Post("add-bank-detail")
    async add_bank_details(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.User_BankDetail_Service.add_bank_details(getPayload);
    }

    @Post("bank-otp-verify")
    async bank_Otp_verify(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.User_BankDetail_Service.bank_Otp_verify(getPayload);
    }

    @Post("get_bank_and_upisDetails")
    async get_bank_and_upisDetails(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.User_BankDetail_Service.get_bank_and_upisDetails(getPayload);
    }
}