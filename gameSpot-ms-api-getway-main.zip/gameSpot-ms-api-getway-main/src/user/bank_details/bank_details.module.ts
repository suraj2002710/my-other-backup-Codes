import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { User_BankDetail_Controller } from "./bank_details.controller";
import { User_BankDetail_Service } from "./bank_details.service";
import { PassportModule } from "@nestjs/passport";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";


@Module({
    imports: [ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'USER_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_USER,
                    port: <any>CommonConfig?.PORT_USER
                }
            },
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        }),
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    controllers: [User_BankDetail_Controller],
    providers: [User_BankDetail_Service]
})
export class User_BankDetail_Module { }