import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";
import { InjectModel } from "@nestjs/mongoose";



@Injectable()
export class UserGamesService{
    constructor(@Inject("GAME_MICROSERVICES") private authClientProxy: ClientProxy) { }

    async get_user_game_history(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_user_game_history' }, payload);
    }

    async get_game(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_game' }, payload);
    }

    async get_all_running_challanges(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_all_running_challanges' }, payload);
    }

    async game_challange_accpect(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_accpect' }, payload);
    }

    async delete_game_challange(payload: any) {
        return await this.authClientProxy.send({ cmd: 'delete_game_challange' }, payload);
    }

    async game_challange_start(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_start' }, payload);
    }

    async game_challange_requested(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_requested' }, payload);
    }

    async game_challange_reject(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_reject' }, payload);
    }

    async get_single_challanges(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_single_challanges' }, payload);
    }
    async create_game_challange(payload: any) {
        return await this.authClientProxy.send({ cmd: 'create_game_challange' }, payload);
    }

    async update_room_code(payload: any) {
        return await this.authClientProxy.send({ cmd: 'update_room_code' }, payload);
    }

    async game_challange_result(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_result' }, payload);
    }

    async game_challange_running(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_running' }, payload);
    }

    async game_challange_update(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_update' }, payload);
    }

    async game_challange_upload_result(payload: any) {
        return await this.authClientProxy.send({ cmd: 'game_challange_upload_result' }, payload);
    }

}