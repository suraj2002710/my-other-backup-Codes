import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";
import { UserGamesService } from "./games.service";
import { UserGamesController } from "./games.controller";
// import { ServeStaticModule } from '@nestjs/serve-static';
// import { join } from 'path';



@Module({
    imports: [
        // ServeStaticModule.forRoot({
        //     rootPath: join(__dirname, '..', 'public'), // path to your static files
        //     serveRoot: '/static', // optional, default is '/'
        //   }),
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'GAME_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig.HOST_GAME,
                    port: <any>CommonConfig.PORT_GAME
                }
            },
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
        ,
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    providers: [UserGamesService],
    controllers: [UserGamesController]
})
export class UserGamesModule { }