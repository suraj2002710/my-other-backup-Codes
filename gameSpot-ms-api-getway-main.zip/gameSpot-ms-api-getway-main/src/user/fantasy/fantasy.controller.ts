import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { JwtAuthGuard } from "../auth/gaurd/jwtguard";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { FileInterceptor } from "@nestjs/platform-express";
import { FantasyService } from "./fantasy.service";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}fantasy`)
export class FantasyController{

    constructor(private readonly FantasyService: FantasyService){}

    
    @Post('get_tournaments')
    async get_tournaments(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.get_tournaments(getPayload);
    }    

    @Post('GetPlayer')
    async GetPlayer(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.GetPlayer(getPayload);
    }    


    @Post('create-team')
    async createUserTeam(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.createUserTeam(getPayload);
    }    
    @Get('get-match')
    async GetMatchs(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.GetMatchs(getPayload);
    }    

    @Post('create-match')
    async createMatch(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.FantasyService.createMatch(getPayload);
    }    
}
