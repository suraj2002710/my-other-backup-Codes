import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";
import { InjectModel } from "@nestjs/mongoose";



@Injectable()
export class FantasyService{
    constructor(@Inject("FANTASY_MICROSERVICES") private authClientProxy: ClientProxy) { }

    async get_tournaments(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_user_tournaments' }, payload);
    }
    
    async GetPlayer(payload: any) {
        return await this.authClientProxy.send({ cmd: 'GetPlayer' }, payload);
    }

    
    async createUserTeam(payload: any) {
        return await this.authClientProxy.send({ cmd: 'createUserTeam' }, payload);
    }
    async GetMatchs(payload: any) {
        return await this.authClientProxy.send({ cmd: 'GetMatchs' }, payload);
    }

    async createMatch(payload: any) {
        return await this.authClientProxy.send({ cmd: 'createMatch' }, payload);
    }
}  