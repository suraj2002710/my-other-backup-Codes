import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";

import { JwtAuthGuard } from "../auth/gaurd/jwtguard";
import { User_KycServices } from "./kyc.service"
import { FileFieldsInterceptor } from "@nestjs/platform-express";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}kyc`)
export class User_KycController {
    constructor(private readonly kycServices: User_KycServices) { }

    
    @Post('kyc-request')
    @UseInterceptors(FileFieldsInterceptor([{
        name: "front", maxCount: 1
    },
    {
        name: "back", maxCount: 1
    }
    ], {
        limits: {
            fileSize: 2 * 1024 * 1024, // Limit each file to 2MB
        },
        fileFilter: (req, file, cb) => {
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
                // Allow only images (you can adjust this as per your requirements)
                cb(null, true);
            } else {
                cb(new Error('Invalid file type'), false);
            }
        },
    }))
    async kyc_request(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.kycServices.kyc_request(getPayload);
    }

    @Post('update-kyc-request')
    @UseInterceptors(FileFieldsInterceptor([{
        name: "front", maxCount: 1
    },
    {
        name: "back", maxCount: 1
    }
    ], {
        limits: {
            fileSize: 2 * 1024 * 1024, // Limit each file to 2MB
        },
        fileFilter: (req, file, cb) => {
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
                // Allow only images (you can adjust this as per your requirements)
                cb(null, true);
            } else {
                cb(new Error('Invalid file type'), false);
            }
        },
    }))
    async update_Kyc_request(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.kycServices.update_Kyc_request(getPayload);
    }

    @Post("auto-kyc-generate-otp")
    async auto_kyc_generate_otp(@Req() request: any) {
        
        const getPayload = await PayloadHelper(request);
        return await this.kycServices.auto_kyc_generate_otp(getPayload);
    }
    @Post("auto-kyc-otp-verify")
    async auto_kyc_otp_verify(@Req() request: any) {
        
        const getPayload = await PayloadHelper(request);
        return await this.kycServices.auto_kyc_otp_verify(getPayload);
    }
    @Post("kyc-request-Otp-verify")
    async kyc_request_Otp_verify(@Req() request: any) {
        
        const getPayload = await PayloadHelper(request);
        return await this.kycServices.kyc_request_Otp_verify(getPayload);
    }

}