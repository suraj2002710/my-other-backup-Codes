import { Module } from "@nestjs/common";
import { AuthServices } from "./auth.service";
import { AuthController } from "./auth.controller";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";
import { JwtStrategy } from "./strategies/Jwt.startegies";

@Module({
    imports:[
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'AUTH_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_AUTH,
                    port: <any>CommonConfig?.PORT_AUTH
                }
            },
            {
                name: 'USER_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_USER,
                    port: <any>CommonConfig?.PORT_USER
                }
            },
            
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
        ,
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    providers: [AuthServices, JwtStrategy],
    controllers:[AuthController]
})
export class AuthModule{}