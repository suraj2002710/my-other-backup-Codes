import {Inject, Injectable} from "@nestjs/common"
import { JwtService } from "@nestjs/jwt";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AuthServices{
    constructor(
        @Inject("AUTH_MICROSERVICES") private authClientProxy :ClientProxy,
        @Inject("USER_MICROSERVICES") private userClientProxy :ClientProxy,
        private jwtService: JwtService,
    ){}

    async sign_up(payload: any) {
        payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        console.log(payload)
        return await this.authClientProxy.send({ cmd: 'user_sign_up' }, payload);
    }


    async login(payload: any) {
        payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        console.log(payload)
    
        return await this.authClientProxy.send({ cmd: 'user_login' }, payload);
    }

    async update_profile(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'user_update_profile' }, payload);
    }

    async get_profile(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'user_get_profile' }, payload);
    }

    async forgot_password(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'forgot_password' }, payload);
    }

    async forgot_password_otp_verify(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'forgot_password_otp_verify' }, payload);
    }

    async reset_password(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'reset_password' }, payload);
    }

    async remove_profile(payload: any) {
        // payload['body']['token'] = await this.generate_token({ email: payload?.body?.email });
        return await this.authClientProxy.send({ cmd: 'remove_profile' }, payload);
    }

    async send_login_otp(payload: any) {


        return await this.authClientProxy.send({ cmd: 'user_send_login_otp' }, payload);
    }

    async login_otp_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'user_login_otp_verify' }, payload);
    }

    async other_details(payload: any) {
        return await this.userClientProxy.send({ cmd: 'other_details' }, payload);
    }

    async generate_token(payload: any) {
        console.log(payload);
        
        return await this.jwtService.sign(payload);
    }
}
