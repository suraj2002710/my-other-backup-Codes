import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';
import { CommonConfig } from '../../../config/CommanConfig';
import { AuthServices } from '../auth.service';

@Injectable()
/* ==== Jwt strategy start ===== */
export class JwtStrategy extends PassportStrategy(Strategy, 'apijwt') {
    constructor(
        private authService: AuthServices
    ) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: CommonConfig.API_ACCESS_TOKEN_SECRET,
        });
    }

    async validate(payload: any) {
        return payload;
    }
}
/* ==== Jwt strategy end ===== */