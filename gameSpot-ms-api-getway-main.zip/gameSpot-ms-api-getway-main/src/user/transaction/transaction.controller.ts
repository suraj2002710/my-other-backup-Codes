import { Body, Controller, Post, Req, UseGuards } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { Transaction_Service } from "./trasnsaction.service";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_TRANSACTION_URL}`)
export class Transaction_Controller {
    constructor(private readonly Transaction_Service: Transaction_Service) { }

    @Post("withdraw_request")
    async users_transaction_withdraw_request(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.Transaction_Service.users_transaction_withdraw_request(getPayload);
    }
   

    @Post("withdraw_otpVerify")
    async user_withdraw_verify(@Req() request: any) {
        console.log("withdraw/otpVerify")
        const getPayload = await PayloadHelper(request);
        return await this.Transaction_Service.user_withdraw_verify(getPayload);
    }

    @Post("deposite_request")
    async users_transaction_deposite_request(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.Transaction_Service.users_transaction_deposite_request(getPayload);
    }

    @Post("user_History")
    async users_transaction_history(@Req() request: any) {
        console.log("start")
        const getPayload = await PayloadHelper(request);
        return await this.Transaction_Service.users_transaction_history(getPayload);
    }
}