import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { Transaction_Service } from "./trasnsaction.service";
import { Transaction_Controller } from "./transaction.controller";
import { PassportModule } from "@nestjs/passport";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";


@Module({
    imports: [ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'TRANSACTION_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig?.HOST_TRANSACTION,
                port: <any>CommonConfig?.PORT_TRANSACTION
            }
        },
    ]),
    PassportModule,
    JwtModule.register({
        secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
        signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
    })
    ,
    MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
],
    controllers: [Transaction_Controller],
    providers: [Transaction_Service]
})
export class Transaction_Module { }