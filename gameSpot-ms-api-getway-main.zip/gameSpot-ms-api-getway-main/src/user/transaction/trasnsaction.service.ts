import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";



@Injectable()
export class Transaction_Service {
    constructor(@Inject("TRANSACTION_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }
   
    async users_transaction_withdraw_request(payload: any) {
        return await this.authClientProxy.send({ cmd: 'users_transaction_withdraw_request' }, payload);
    }

   

    async user_withdraw_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'user_withdraw_verify' }, payload);
    }

    async users_transaction_deposite_request(payload: any) {
        return await this.authClientProxy.send({ cmd: 'users_transaction_deposite_request' }, payload);
    }

    async users_transaction_history(payload: any) {
        return await this.authClientProxy.send({ cmd: 'users_transaction_history' }, payload);
    }
}