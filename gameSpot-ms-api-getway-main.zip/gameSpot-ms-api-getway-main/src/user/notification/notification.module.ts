import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientsModule, Transport } from '@nestjs/microservices';

import { NotificationController } from './notification.controller';
import { NotificationService } from './notification.service';

import { MongooseModule } from '@nestjs/mongoose';
import { CommonConfig } from 'src/config/CommanConfig';
import { Users, UsersSchema } from 'src/schema/user.schema';

@Module({
    imports: [
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'USER_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_USER,
                    port: <any>CommonConfig?.PORT_USER
                }
            },
            {
                name: 'AUTH_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_AUTH,
                    port: <any>CommonConfig?.PORT_AUTH
                }
            },
        ]),
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    controllers: [NotificationController],
    providers: [NotificationService]
})
export class UserNotificationModule { }
