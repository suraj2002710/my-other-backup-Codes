import { Body, Controller, Get, Post, Req, UseGuards } from "@nestjs/common";

import { NotificationService } from "./notification.service";
import { PayloadHelper } from "src/utils/Payload";
import { Request } from "express";

import { InjectModel } from "@nestjs/mongoose";

import { Model } from "mongoose";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";
import { CommonConfig } from "src/config/CommanConfig";
import { Users } from "src/schema/user.schema";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL + 'notification'}`)
export class NotificationController {
    constructor(private readonly NotificationService: NotificationService,
        @InjectModel(Users.name) private readonly UsersModel: Model<Users>,
    ) { }

    @Get("fetch")
    async get_notification(@Body() body: any, @Req() request: Request) {
        const clientIP = request.ip || request.connection.remoteAddress;
        // console.log("clientIP",clientIP)

        const getPayload = await PayloadHelper(request)
        return this.NotificationService.get_notification(getPayload)
    }

    @Get('url*')
    async ip_url(@Body() body: any, @Req() request: Request) {
        console.log("ip_url")
        const getPayload = await PayloadHelper(request);
        return await this.NotificationService.ip_url(getPayload);
    }

}