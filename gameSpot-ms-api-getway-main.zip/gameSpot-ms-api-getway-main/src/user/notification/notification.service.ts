import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class NotificationService {
    constructor(
        @Inject('USER_MICROSERVICES') private readonly userClientProxy: ClientProxy,
    ) { }

    get_notification(payload: any) {
        console.log('payload', payload)
        return this.userClientProxy.send({ cmd: 'get_notification' }, payload);
    }

    async ip_url(payload: any) {
        console.log("service")
        return await this.userClientProxy.send({ cmd: 'ip_url' }, payload);
    }

}