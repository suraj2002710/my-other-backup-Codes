import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { Game_CategoryController } from "./game_category.controller";
import { Game_Category_Service } from "./game_category.service";


@Module({
    imports:[ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name:"MAIN_ADMIN_MICROSERVICES",
            transport:Transport.TCP,
            options:{
                port:<any>CommonConfig.PORT_MAIN_ADMIN,
                host:<any>CommonConfig.HOST_MAIN_ADMIN
            }
        }
    ])
    ],
    controllers:[Game_CategoryController],
    providers:[Game_Category_Service]
})
export class Game_CategoryModule{}