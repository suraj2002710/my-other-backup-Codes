import { Body, Controller, Post, Req } from "@nestjs/common";
import { Game_Category_Service } from "./game_category.service";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";


@Controller(`${CommonConfig.API_MAIN_ADMIN_URL}game-category`)
export class Game_CategoryController{
    constructor(private readonly Game_category_Service:Game_Category_Service){}

    @Post('create_category')
    async create_category(@Req() request:any){
        const payload = await PayloadHelper(request)
        return await this.Game_category_Service.create_Category(payload)
    }
    @Post('update_Category')
    async update_Category(@Req() request:any){
        const payload = await PayloadHelper(request)
        return await this.Game_category_Service.update_Category(payload)
    }
    @Post('delete_Category')
    async delete_Category(@Req() request:any){
        const payload = await PayloadHelper(request)
        return await this.Game_category_Service.delete_Category(payload)
    }
    @Post('get_single_Category')
    async get_single_Category(@Req() request:any){
        const payload = await PayloadHelper(request)
        return await this.Game_category_Service.get_single_Category(payload)
    }
    @Post('get_all_Category')
    async get_all_Category(@Req() request:any){
        const payload = await PayloadHelper(request)
        return await this.Game_category_Service.get_all_Category(payload)
    }

}