import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { Super_Admin_BankDetail_Controller } from "./bank_details.controller";
import { Super_Admin_BankDetail_Service } from "./bank_details.service";


@Module({
    imports: [ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'MAIN_ADMIN_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig?.HOST_MAIN_ADMIN,
                port: <any>CommonConfig?.PORT_MAIN_ADMIN
            }
        },
    ]),],
    controllers: [Super_Admin_BankDetail_Controller],
    providers: [Super_Admin_BankDetail_Service]
})
export class Super_Admin_BankDetail_Module { }