import { Body, Controller, Post, Req } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { Super_Admin_BankDetail_Service } from "./bank_details.service";


@Controller(`${CommonConfig.API_MAIN_ADMIN_URL}bank-detail`)
export class Super_Admin_BankDetail_Controller {
    constructor(private readonly Super_Admin_BankDetail_Service: Super_Admin_BankDetail_Service) { }

    @Post("approval")
    async BankDetail_approval(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.Super_Admin_BankDetail_Service.BankDetail_approval(getPayload);
    }

}