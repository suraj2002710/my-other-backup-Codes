import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AdminGameService{
    constructor(@Inject("MAIN_ADMIN_MICROSERVICES") readonly authclientProxy:ClientProxy){}
    async create_game(payload:any){
        return await this.authclientProxy.send({ cmd:"game_create"},payload)
    }
    async get_all_Game(payload:any){
        return await this.authclientProxy.send({ cmd:"get_all_Game"},payload)
    }
    async get_single_Game(payload:any){
        return await this.authclientProxy.send({ cmd:"get_single_Game"},payload)
    }
    async delete_Game(payload:any){
        return await this.authclientProxy.send({ cmd:"delete_Game"},payload)
    }
    async updateGame(payload:any){
        return await this.authclientProxy.send({ cmd:"updateGame"},payload)
    }
}