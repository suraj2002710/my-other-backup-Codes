import { Controller, Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { AdminGameService } from "./game.service";
import { AdminGamesController } from "./game.controller";


@Module({
    imports:[
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name:"MAIN_ADMIN_MICROSERVICES",
                transport:Transport.TCP,
                options:{
                    port:<any>CommonConfig.PORT_MAIN_ADMIN,
                    host:<any>CommonConfig.HOST_MAIN_ADMIN
                }
            }
        ])
    ],
    controllers: [AdminGamesController],
    providers: [AdminGameService]
})
export class SuperAdminGamesModule{}