import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";



@Injectable()
export class Super_Admin_Kyc_Service{
    constructor(@Inject("MAIN_ADMIN_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }
    async kyc_approval(payload: any) {
        return await this.authClientProxy.send({ cmd: 'kyc_update' }, payload);
    }
}