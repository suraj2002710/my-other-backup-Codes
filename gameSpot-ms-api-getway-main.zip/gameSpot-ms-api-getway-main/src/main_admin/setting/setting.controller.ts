import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { SettingServices } from "./setting.service";


@Controller(`${CommonConfig.API_MAIN_ADMIN_URL}setting`)
export class SettingController {
    constructor(private readonly SettingServices: SettingServices) { }
        
    @Post('payment_gateway')
    async payment_gateway(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.SettingServices.payment_gateway(getPayload);
    }

    

}