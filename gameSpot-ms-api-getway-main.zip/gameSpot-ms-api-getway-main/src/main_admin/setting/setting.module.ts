import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";

import { SettingServices } from "./setting.service";
import { SettingController } from "./setting.controller";


@Module({
    imports: [
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'MAIN_ADMIN_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_MAIN_ADMIN,
                    port: <any>CommonConfig?.PORT_MAIN_ADMIN
                }
            },
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
        ,
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    providers: [SettingServices],
    controllers: [SettingController]
})
export class SettingModule { }