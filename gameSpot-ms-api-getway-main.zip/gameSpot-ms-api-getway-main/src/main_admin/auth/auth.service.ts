import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class Admin_Auth_Service{
    constructor(@Inject("") readonly authClientProxcy:ClientProxy){}
    
}