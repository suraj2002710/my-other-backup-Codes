import React from 'react';
import AgoraRTC, { AgoraRTCProvider, useRTCClient } from "agora-rtc-react";
import { config } from './config';
import Authenticatedapp from './Authenticatedapp';


function App() {
    const agoraEngine = useRTCClient(AgoraRTC.createClient({mode: config.selectedProduct, codec: "vp8" }));
   
  return (
      <AgoraRTCProvider client={agoraEngine}>
      <Authenticatedapp agoraEngine={agoraEngine}/>
      </AgoraRTCProvider>
  );
}

export default App