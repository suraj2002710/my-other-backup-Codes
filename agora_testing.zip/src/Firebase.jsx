import {initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
const firebaseConfig = {
    apiKey: "AIzaSYBKHPYe52aoPooB2ZGpEz3-7zT-YbkahjA",
    authDomain: "auth-rog.firebaseapp.com",
    projectId: "auth-rog",
    storageBucket: "auth-rog.appspot.com",
    messagingSenderId: "520545659993",
    appId: "1:52054565993:web:685a47b5a231fef028d548"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
