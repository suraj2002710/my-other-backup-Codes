import React, { useEffect } from 'react';
import AgoraRTC from 'agora-rtc-sdk-ng';

const config = {
    mode: 'rtc',
    codec: 'vp8',
    appId: 'd87a1208232d4690ad44d20c338705d1',
    channel: 'vid_call',
    token: '007eJxTYIg9fOjujv9L1/45Y8U9YdXflQ/nzP7h9qpA8dy7Hfrbi9pmKTCkpZokJ1mYmVtYpJiZWBiYWiYbGhilmZpaGKaYG6UkJu9Lv5DaEMjIYFfcxMAIhSA+B0NZZkp8cmJODgMDAIEsJc8='
};

function VideoCall() {
    let client;
    let localAudioTrack;
    let localVideoTrack;

    useEffect(() => {
        async function startCall() {
            client = AgoraRTC.createClient({ mode: config.mode, codec: config.codec });

            const uid = await client.join(config.appId, config.channel, config.token, null);
console.log("uid",uid);
            // localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
            localVideoTrack = await AgoraRTC.createCameraVideoTrack();

            await client.publish([localAudioTrack, localVideoTrack]);

            client.on('user-published', async (user, mediaType) => {
                await client.subscribe(user, mediaType);

                if (mediaType === 'video') {
                    user.videoTrack.play('remote-container');
                }

                if (mediaType === 'audio') {
                    user.audioTrack.play();
                }
            });
        }

        startCall();

        return () => {
            localAudioTrack.close();
            localVideoTrack.close();
            client.leave();
        };
    }, []);

    return (
        <div>
            <div id="local-container" style={{ width: "640px", height: "480px" }}></div>
            <div id="remote-container" style={{ width: "640px", height: "480px" }}></div>
        </div>
    );
}

export default VideoCall;
