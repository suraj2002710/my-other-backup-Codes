import React, { useEffect, useState } from 'react'
import AgoraRTC from 'agora-rtc-sdk-ng'; // Ensure you have AgoraRTC imported for creating new tracks
import {
  LocalVideoTrack,
  RemoteUser,
  useJoin,
  useLocalCameraTrack,
  useLocalMicrophoneTrack,
  usePublish,
  useRemoteUsers,
  useClientEvent
} from "agora-rtc-react";
import { MdCallEnd } from "react-icons/md";
import { RiCameraSwitchLine } from "react-icons/ri";
import { TbCameraOff } from "react-icons/tb";
import { TbCamera } from "react-icons/tb";


import { config } from './config';


let intervalId = undefined;
function Host({ agoraEngine, setJoined }) {


  const [timer, setTimer] = useState(0);
  const [currentCameraId, setCurrentCameraId] = useState(null);
  const [cameraDevices, setCameraDevices] = useState([]);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const { isLoading: isLoadingCam, localCameraTrack } = useLocalCameraTrack();
  const { isLoading: isLoadingMic, localMicrophoneTrack } = useLocalMicrophoneTrack();
  const remoteUsers = useRemoteUsers();
  const deviceLoading = isLoadingMic || isLoadingCam;


  //timer logic
  useEffect(() => {
    if (remoteUsers.length > 0 && intervalId === undefined) {
      intervalId = setInterval(() => {
        setTimer((prevTime) => prevTime + 1);
      }, 1000);
    }
    else if (remoteUsers.length === 0) {
      clearInterval(intervalId);
      intervalId = undefined;
      setTimer(0);
    }
    return () => {
      clearInterval(intervalId);
      intervalId = undefined;
      setTimer(0);
    }
  }, [remoteUsers.length]);


  //setdevices and also setLocalVideoTrack
  useEffect(() => {
    AgoraRTC.getDevices().then(async (devices) => {
      const videoInputs = devices.filter(device => device.kind === 'videoinput');
      console.log(videoInputs, "devices");
      setCameraDevices(videoInputs)
      setCurrentCameraId(videoInputs[0]?.deviceId);
    }).catch((err)=>{
      console.log(err);
    })
  }, []);

  //switch camera login
  const switchCamera = async () => {
    const currentIndex = cameraDevices.findIndex(device => device.deviceId === currentCameraId);
    const nextIndex = (currentIndex + 1) % cameraDevices.length;
    const nextCameraId = cameraDevices[nextIndex]?.deviceId;
    setCurrentCameraId(nextCameraId);

    if (localCameraTrack) {
      const newCameraTrack = await AgoraRTC.createCameraVideoTrack({ cameraId: nextCameraId });
      localCameraTrack.replaceTrack(newCameraTrack.getMediaStreamTrack(), true);
    }
  }

  usePublish([localMicrophoneTrack, localCameraTrack]);

  useJoin({
    appid: config.appId,
    channel: config.channelName,
    token: config.rtcToken,
    uid: config.uid,
  });

  console.log("uid",agoraEngine?.uid);


  useClientEvent(agoraEngine, "user-joined", (user) => {
    console.log("The user", user.uid, " has joined the channel");
  });

  useClientEvent(agoraEngine, "user-left", (user) => {
    console.log("The user", user.uid, " has left the channel");
  });

  useClientEvent(agoraEngine, "user-published", (user, mediaType) => {
    console.log("The user", user.uid, " has published media in the channel");
  });

  //remove the video and microphone when leave
  const cleanup = async () => {
    if (intervalId !== undefined) {
      clearInterval(intervalId);
      intervalId = undefined;
      setTimer(0);
    }
    await agoraEngine.leave();
    localCameraTrack?.close();
    localMicrophoneTrack?.close();
    setJoined(false);
  };


  const handleSwitchCamera = async () => {
    if (cameraDevices.length <= 1) {
      alert("Back camera not available");
      return;
    }
    await switchCamera();
  };

  //turn camera on or off
  const toggleCamera = async () => {
    if (isCameraOn) {
      localCameraTrack?.setEnabled(false);
      setIsCameraOn(false);
    } else {
      localCameraTrack?.setEnabled(true);
      setIsCameraOn(true);
    }
  };

  return deviceLoading ? (<div>Loading devices...</div>) :
    (
      <div className='w-[100vw] h-[100vh]'>

        <div id="videos" className='w-full h-full relative'>
          {/* Render the local video track */}
          <div className='w-[30%] h-[25%] absolute right-2 top-3 z-10 '>
            <LocalVideoTrack track={localCameraTrack} play={true} />
          </div>
          {/* Render remote users' video and audio tracks */}
          {remoteUsers.map((remoteUser) => (
            <div className="w-full h-full absolute left-0 top-0 z-0 " key={remoteUser.uid}>
              <RemoteUser user={remoteUser} playVideo={true} playAudio={true} />
            </div>
          ))}

          <div id='videocontrols' className='absolute bottom-3 w-full z-10 flex justify-between items-center px-[10%] pb-5'>

            {isCameraOn ? <TbCameraOff onClick={() => toggleCamera()} className='text-4xl text-blue-50' />
              : <TbCamera onClick={() => toggleCamera()} className='text-4xl text-blue-50' />
            }
            <div className='flex flex-col justify-center gap-2 items-center'>
              {remoteUsers.length > 0 && <p className='text-white text-center bg-green-300 px-5 py-2 rounded-3xl'>{`${Math.floor(timer / 60).toString().padStart(2, '0')}:${(timer % 60).toString().padStart(2, '0')}`}</p>}
              <MdCallEnd onClick={() => cleanup()} className='text-4xl  text-red-600' />
            </div>
            <RiCameraSwitchLine onClick={() => handleSwitchCamera()} className='text-4xl text-blue-50' />


          </div>
        </div>
      </div>
    )
}

export default Host


