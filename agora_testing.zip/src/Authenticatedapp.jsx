import React, { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Host from './Host'
import { useClientEvent, useRTCClient } from "agora-rtc-react";
import { config } from './config';
import AgoraRTC from 'agora-rtc-sdk-ng';

async function fetchRTCToken(channelName) {
    if (config.serverUrl !== "") {
        try {
            const response = await fetch(
                `${config.proxyUrl}${config.serverUrl}/rtc/${channelName}/publisher/uid/${config.uid}/?expiry=${config.tokenExpiryTime}`
            );
            const data = await response.json();
            console.log("RTC token fetched from server: ", data.rtcToken);
            return data.rtcToken;
        } catch (error) {
            console.error(error);
            throw error;
        }
}
}

const useTokenWillExpire = () => {
    const agoraEngine = useRTCClient();

    // useClientEvent(agoraEngine, "token-privilege-will-expire", () => {
    //     if (config.serverUrl !== "") {
    //         fetchRTCToken(config.channelName)
    //             .then((token) => {
    //                 console.log("RTC token fetched from server: ", token);
    //                 if (token) return agoraEngine.renewToken(token);
    //             })
    //             .catch((error) => {
    //                 console.error(error);
    //             });
    //     } else {
    //         console.log("Please make sure you specified the token server URL in the configuration file");
    //     }
    // });
};
function Authenticatedapp({agoraEngine}) {
    const [channelName, setChannelName] = useState("vid_call");
    const [joined, setJoined] = useState(false);




    useTokenWillExpire();

    const fetchTokenFunction = async () => {
        // if (config.serverUrl !== "" && channelName !== "") {
            try {
                // const token = await fetchRTCToken(channelName)
                // config.rtcToken = token;
                // config.channelName = channelName;
                setJoined(true)
            } catch (error) {
                console.error(error);
            }
        // } else {
        //     console.log("Please make sure you specified the token server URL in the configuration file");
        // }
    };
    return (
            <div>
                {!joined ? (
                    <div>
                        <input
                            type="text"
                            value={channelName}
                            onChange={(e) => setChannelName(e.target.value)}
                            placeholder="Channel name" />
                    <button onClick={() => fetchTokenFunction()}>Join</button>
                    </div>
                ) : (
                    <div>
                        
                        <Routes>
                            <Route path="/" element={<Host agoraEngine={agoraEngine} setJoined={setJoined}/>} />
                        </Routes>
                    </div>
                )
                }
            </div>
    );
}

export default Authenticatedapp