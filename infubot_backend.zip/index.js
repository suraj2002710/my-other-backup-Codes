//Environment Configurationconst dotenv = require("dotenv");const dotenv = require("dotenv");\
const dotenv = require("dotenv");
const ENV_FILE = process.env.NODE_ENV || "development";
const envPath = `.env.${ENV_FILE}`;
console.log("index envPath", envPath);
dotenv.config({ path: envPath });
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");
const fs = require("fs");
const winston = require("winston");
const colors = require("colors");
const { Server } = require("socket.io");
const http = require("http");
const admin = require("firebase-admin");
const {User}=require('./models/Users')
//Internal Imports
const { send_notification, check_device_availability } = require("./services/pushy_notification");
const { initializeSocket } = require("./socket_chat_infra");
// const serverAdapter  = require('./queue_infra/bull_board');

//API Routers Imports
const faqRouter = require("./routers/faq");
const userRouter = require("./routers/user");
const googleRouter = require("./routers/googleUser");
const transactionRouter = require("./routers/transaction");
const walletRouter = require("./routers/wallet");
const creatorRouter = require("./routers/creator");
const creatorBotSettingRouter = require("./routers/creatorBotSetting");
const creatorLinkSuggestionRouter = require("./routers/creatorLinkSuggestion");
const creatorTextSuggestionRouter = require("./routers/creatorTextSuggestion");
const audioConnectivityRouter = require("./routers/audioConnectivity");
const videoConnectivityRouter = require("./routers/videoConnectivity");
const chatHistoryRouter = require("./routers/chatHistory");
const creatorBotInsightsRouter = require("./routers/creatorBotInsights");
const versionRouter = require("./routers/version");
const orderRouter = require("./routers/orders");
const creatorRevenueHistoryRouter = require("./routers/creatorRevenueHistory");
const creatorKYCRouter = require("./routers/creatorKYC");
const creatorBillingDetailsRouter = require("./routers/creatorBillingDetails");
const creatorBankDetailsRouter = require("./routers/creatorBankDetails");
const otpValidatorRouter = require("./routers/otpValidator");
const superAdminRouter = require("./routers/superAdmin");
const nicheOnboardingQuestions = require("./routers/onboardingQuestions");
const creatorDocumentIndexer = require("./routers/creatorDataIndexer");
const InterestedCreator = require("./routers/interestedCreator");
const CreatorAIAnswer = require("./routers/creatorAIAnswer");
const ContactUsForm = require("./routers/contactUsRequest");
const CreatorAIPersonality = require("./routers/creatorAIPersonality");
const CompanyPolicy = require("./routers/policy");
const BaseRates = require("./routers/baseRate");
const PaymentGateway = require("./routers/paymentGateway");
const CashfreeWebhookHandler = require("./webhooks/payment_gateway/cashfree");
const CashfreeCheckoutHandler = require("./payment_gateways/cashfree/checkout_handler");
const StripePaymentGatewayHandler = require("./routers/StripeGateway");
const CreatorQueueController = require("./routers/creatorQueueManager");
const ChatContentController = require("./routers/chatContent");
const moment = require("moment-timezone");
const paymentDate = moment().tz("Asia/Kolkata").toDate();
const { v4: uuidv4 } = require('uuid')
console.log("payment date.....", paymentDate);
//Logger Setup
const { initializeLogger } = require("./utilities/logger");
const logger = initializeLogger();
if (process.env.Environment !== "production") {
   // add a console logger transport
   logger.add(
      new winston.transports.Console({
         format: winston.format.simple(),
      }),
   );
}

//Test Imports
const { generateAgoraTestToken } = require("./services/agora_token_test");
// const {load_to_audio_call_notification_queue,pauseWorker, resumeWorker,drainAllJobs,listPendingJobs} = require("./queue_infra/bullmq_producer");

//Firebase App Setup
const serviceAccount = require("./firebase_service_account.json");
global.__basename = __dirname;
admin.initializeApp({
   credential: admin.credential.cert(serviceAccount),
});

//MongoDB Connection Configuration
mongoose
   .connect(process.env.MongooseConnectionString, {
      user: process.env.MongooseUser,
      pass: process.env.MongoosePassword,
   })
   .then((res) => {
      console.log("DB Connected successfully!".green);
   })
   .catch((err) => {
      console.log(err);
   });

// // kafka
// const kafkaServiceInstance =require('./kafka/index');

// Express Server Setup
const app = express();
const server = http.createServer(app);
initializeSocket(server);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Proxy Setup
app.set("trust proxy", true);

//CORS Setup
const allowedOrigins = ["*", "http://localhost:5174", "https://bot.influbot.ai", process.env.MY_AI_FRONTEND_DEPLOY_URL];

app.use(function (req, res, next) {
   // const origin = req.headers.origin;
   // Only set the Access-Control-Allow-Origin header if the origin is in the allowedOrigins list
   // if (allowedOrigins.includes(origin)) {
   res.setHeader("Access-Control-Allow-Origin", "*");
   // }
   res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
   res.setHeader("Access-Control-Allow-Headers", "*");
   res.setHeader("Access-Control-Allow-Credentials", true);
   next();
});

//EJS Setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Route setup
app.use(express.static("public"));

app.use("/api/faq", faqRouter);
app.use("/api/user", userRouter);
app.use("/api/google-user", googleRouter);
app.use("/api/transaction", transactionRouter);
app.use("/api/wallet", walletRouter);
app.use("/api/creator", creatorRouter);
app.use("/api/interested-creator", InterestedCreator);
app.use("/api/otp-validator", otpValidatorRouter);
app.use("/api/creator-bot-setting", creatorBotSettingRouter);
app.use("/api/creator-link-suggestion", creatorLinkSuggestionRouter);
app.use("/api/creator-text-suggestion", creatorTextSuggestionRouter);
app.use("/api/audio-connectivity", audioConnectivityRouter);
app.use("/api/video-connectivity", videoConnectivityRouter);
app.use("/api/chat-history", chatHistoryRouter);
app.use("/api/bot-insights", creatorBotInsightsRouter);
app.use("/api/version", versionRouter);
app.use("/api/orders", orderRouter);
app.use("/api/creator-revenue-history", creatorRevenueHistoryRouter);
app.use("/api/creator-kyc", creatorKYCRouter);
app.use("/api/creator-billing-details", creatorBillingDetailsRouter);
app.use("/api/creator-bank-details", creatorBankDetailsRouter);
app.use("/api/super-admin", superAdminRouter);
app.use("/api/creator-onboarding", nicheOnboardingQuestions);
app.use("/api/creator-indexer", creatorDocumentIndexer);
app.use("/api/creator-ai", CreatorAIAnswer);
app.use("/api/contact-us", ContactUsForm);
app.use("/api/ai-personality", CreatorAIPersonality);
app.use("/api/company_policy", CompanyPolicy);
app.use("/api/base-rates", BaseRates);
app.use("/api/payment-gateway", PaymentGateway);
// app.use("/api/stripe", StripePaymentGatewayHandler);
// app.use("/api/creator_queue", CreatorQueueController);
// app.use('/admin/queues', serverAdapter.getRouter());
app.use("/api/chat_content", ChatContentController);
// app.use("/webhook/cashfree",CashfreeWebhookHandler)
// app.use("/cashfree/checkout", CashfreeCheckoutHandler)

app.use("/public", express.static("public"));

//Express server
server.listen(process.env.port || process.env.PORT || 3978, () => {
   console.log(`\nlocalhost listening to 3978`);
   console.log("\nGet Bot Framework Emulator: https://aka.ms/botframework-emulator");
   console.log('\nTo talk to your bot, open the emulator select "Open Bot"');
});

//CRON Setup
// var cron = require("node-cron");
// const {
//   deleteConversationHistory,
// } = require("./jobs/deleteConversationHistory");
// const { deleteChatHistory } = require("./jobs/deleteChatHistory");

// cron.schedule("0 */12 * * *", () => {
//   deleteConversationHistory();
//   deleteChatHistory();
// });

app.get("/download-apk", (req, res) => {
   const apkPath = path.join(__dirname, "public", "apk", "kiran_1.17.apk");
   res.setHeader("Content-Disposition", "attachment; filename=kiran_1.17.apk");
   res.setHeader("Content-Type", "application/vnd.android.package-archive");

   const filestream = fs.createReadStream(apkPath);
   filestream.pipe(res);

   filestream.on("error", function (err) {
      console.error(err);
      if (!res.headersSent) {
         res.status(500).send("Error occurred during download");
      }
   });
});

//API for generating Agora Token for React
app.get("/agora/generate-test-agora-token/:role", async (req, res) => {
   const response = await generateAgoraTestToken(req.params.role);
   console.log("Token", response);
   return res.status(200).json({
      token: response.token,
      channel_room: response.channel_room,
   });
});

app.post("/indicpay/web-hook", (req, res) => {
   try {
      console.log("----------indicpay webhook-----------", req.body);
   } catch (error) {
      console.log("----------Error in indicpay webhook-----------", error);
   }
});

app.use(express.json());

app.get("/redirection/to/browser", (req, res) => {
   try {
      console.log("----------redirection to browser-----------", req.query.createName.split("?"));
      let creatorName = req.query.createName.split("?")[0];
      if (creatorName) {
         let url = `googlechrome://navigate?url=https://bot.influbot.ai/${creatorName}`;
         const userAgent = req.headers["user-agent"];
         // if (userAgent.includes("iPhone")) {
         //    console.log("--------------req from iphone -------- Instagram-")
         //    res.redirect(`https://bot.influbot.ai/${creatorName}`);
         // } else 
         if (userAgent && userAgent.includes("Instagram")) {

            console.log("Instagram user");
            res.redirect(url);
         } else {
            console.log("Instagram user in else");

            res.redirect(`https://bot.influbot.ai/${creatorName}`);
         }
      } else
         res.status(400).json({
            message: "creator name is required",
         });
   } catch (error) {
      res.send({ message: "error in redirection to browser", error: error });
   }
});



app.get("/update/user/uuid",async(req,res)=>{
   try{
      const uuid = uuidv4().replace(/-/g, '').substring(0, 8) + '-' +
             uuidv4().replace(/-/g, '').substring(8, 12) + '-' +
             uuidv4().replace(/-/g, '').substring(12, 16) + '-' +
             uuidv4().replace(/-/g, '').substring(16, 20) + '-' +
             uuidv4().replace(/-/g, '').substring(20);


    let getAllUser=await User.find()
    res.send(getAllUser)

   }catch(error){
      console.log("error in updating user uuid",error)
   }
})
