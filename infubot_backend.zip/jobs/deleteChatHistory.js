const DeleteChatHistoryJob = "DELETE_CHAT_HISTORY_JOB";

const logger = require("winston");
const { ChatHistory } = require("../models/ChatHistory");

module.exports.deleteChatHistory = async () => {
  try {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const query = { createdAt: { $lt: twentyFourHoursAgo } };

    await ChatHistory.deleteMany(query);

    logger.info(`[${DeleteChatHistoryJob}] response success`);
  } catch (error) {
    logger.error(
      `[${DeleteChatHistoryJob}] response error :- ${error.message}`
    );
  }
};
