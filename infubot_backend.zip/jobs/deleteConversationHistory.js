const DeleteConversationHistoryJob = "DELETE_CONVERSATION_HISTORY_JOB";

const logger = require("winston");
const { Conversation } = require("../models/Conversation");

module.exports.deleteConversationHistory = async () => {
  try {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const query = { createdAt: { $lt: twentyFourHoursAgo } };

    await Conversation.deleteMany(query);

    logger.info(`[${DeleteConversationHistoryJob}] response success`);
  } catch (error) {
    logger.error(
      `[${DeleteConversationHistoryJob}] response error :- ${error.message}`
    );
  }
};
