const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define the UserSchema
const UserHolderSchema = new Schema(
  {
    id: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      required: true,
      enum: ["creator", "user"],
    },
    ip: {
      type: String,
      required: true,
    },
    reason: {
      type: String,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

// Create a model from the schema
const UserHolded = mongoose.model("UserHolded", UserHolderSchema);

module.exports.UserHolded = UserHolded;
