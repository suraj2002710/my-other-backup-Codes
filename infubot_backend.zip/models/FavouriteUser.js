const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorFavouriteUsersSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
    unique: true,
  },
  user_id : {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
    unique: true,
  },
  cost_per_msg: {
    type: Number,
    default: 50,
    required: true,
  },
  cost_audio_per_min: {
    type: Number,
    default: 50,
    required: true,
  },
  cost_video_per_min: {
    type: Number,
    default: 50,
    required: true,
  }
});

const CreatorFavouriteUsers = mongoose.model(
  "CreatorFavouriteUsers",
  CreatorFavouriteUsersSchema
);

module.exports.CreatorFavouriteUsers = CreatorFavouriteUsers;
