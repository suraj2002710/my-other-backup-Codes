const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const VideoConnectivtySchema = new Schema(
  {
    user_id: {
      type: String,
    },
    creator_id: {
      type: String,
    },
    channel_room_id: {
      type: String,
    },
    connection: {
      type: String,
      enum: ["waiting", "ongoing", "cancelled", "not_answered","complete","declined"],
    },
    start_time: {
      type: Date,
      required : false
      // default : Date.now
    },
    end_time: {
      type: Date,
      required : false
    },
    duration : {
      type : String,
      required : false
    },
    declined_by : {
      type : String,
      default : null
    },
  },
  {
    timestamps: true,
  }
);

const VideoConnectivty = mongoose.model(
  "VideoConnectivty",
  VideoConnectivtySchema
);

module.exports = VideoConnectivty;
