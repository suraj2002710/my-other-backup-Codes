const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UserVisitSchema = new Schema(
  {
    creator_id: {
      type: Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
    },
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    visited_at: {
      type: Date,
      default: Date.now,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const UserVisit = mongoose.model("User Visits", UserVisitSchema);

module.exports.UserVisit = UserVisit;
