const mongoose = require("mongoose");
const crypto = require('crypto');
const Schema = mongoose.Schema;

const HashMapperSchema = new Schema(
  {
    id: {
      type : "String",
      required: true,
    },
    secret_value: {
      type: String,
      required: true,
    },
    ip: {
      type: String,
      required: true,
    },
    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);



const HashMapper = mongoose.model("HashMapper", HashMapperSchema);

module.exports.HashMapper = HashMapper;
