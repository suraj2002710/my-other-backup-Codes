const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const VersionSchema = new Schema(
  {
    ios_version: {
      type: String,
      required: true,
    },
    andriod_version: {
      type: String,
      required: true,
    },
    andriod_url: {
      type: String,
      required: true,
    },
    ios_url: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Version = mongoose.model("Version", VersionSchema);

module.exports.Version = Version;
