const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorAIIndexerSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
  },
  document_name : {
    type: String,
    required : true
  },
  document_id: {
    type: String,
    required : true,
    unique : true
  },
  tags: [{
    type: String
  }],
  status: {
    type: String,
    enum: ['pending', 'processed', 'indexed'],
    default: 'pending'
  },
  metadata: {
    type: String,
    required : true,
    get: (data) => {
      try {
        return JSON.parse(data);
      } catch (e) {
        return data;
      }
    },
    set: (data) => {
      return JSON.stringify(data);
    }
  }
}, {
  toJSON: { getters: true }, // Enable getters when converting to JSON
  toObject: { getters: true }  // Enable getters when converting to a regular Object
});

const CreatorAIIndexer = mongoose.model(
  "CreatorAIIndexer",
  CreatorAIIndexerSchema
);

module.exports.CreatorAIIndexer = CreatorAIIndexer;
