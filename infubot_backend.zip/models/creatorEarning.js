const mongoose = require("mongoose");const Schema = mongoose.Schema;

const CreatorEarningsSchema = new Schema(
   {
      creator_id: {
         type: String,
         required: true,
      },
      creator_earning: {
         type: Number,
         default: 0,
      },
      earn_by_video_call: {
         type: Number,
         default: 0,
      },
      earn_by_message: {
         type: Number,
         default: 0,
      },
      earn_by_ai_message: {
         type: Number,
         default: 0,
      },
      total_security_amount_left:{
        type: Number,
        default: 0,
      },
      total_withdraw: {
         type: Number,
         default: 0,
      },
   },
   {
      timestamps: true,
   },
);

const CreatorEarning = mongoose.model("CreatorEarnings", CreatorEarningsSchema);

module.exports.CreatorEarning = CreatorEarning;
