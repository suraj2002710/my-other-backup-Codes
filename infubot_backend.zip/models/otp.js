const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const OTPSchema = new Schema({
  email: {
    type: String,
    required: true,
  },
  otp: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 300, // OTP expires in 5 minutes
  },
  isValid: {
    type: Boolean,
    default: true,
  },
  count : {
    type : Number,
    default : 1
  }
  // Additional fields can be added as required
});

const OTP = mongoose.model("OTP", OTPSchema);

module.exports.OTP = OTP;
