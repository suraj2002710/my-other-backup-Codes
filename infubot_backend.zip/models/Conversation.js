const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ConversationSchema = new Schema(
  {
    user_id: {
      type: String,
    },
    creator_id: {
      type: String,
    },
    conversation_id: {
      type: String,
    },
    user_message: {
      type: String,
    },
    intent: {
      type: String,
    },
    webId: {
      type: String,
    },
    activity: {
      type: Object,
    },
  },
  {
    timestamps: true,
  }
);

const Conversation = mongoose.model("Conversation", ConversationSchema);

module.exports.Conversation = Conversation;
