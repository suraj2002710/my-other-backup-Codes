const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorTextSuggestionSchema = new Schema({
  text: {
    type: String,
    required: true,
  },
  is_active: {
    type: String,
    required: true,
  },
});

const CreatorTextSuggestion = mongoose.model(
  "CreatorTextSuggestion",
  CreatorTextSuggestionSchema
);

module.exports.CreatorTextSuggestion = CreatorTextSuggestion;
