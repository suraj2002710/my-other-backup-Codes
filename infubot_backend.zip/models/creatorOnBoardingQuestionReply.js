const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
const Schema = mongoose.Schema;

const CreatorOnboardingQuestionReplySchema = new Schema(
  {
    creator_id: {
      type: Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
    },
    question_id: {
      type: Schema.Types.ObjectId,
      ref: "OnboardingQuestionsSchema",
      required: true,
    },
    reply: {
      type: String,
      default: "Text",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const CreatorOnboardingQuestionReply = mongoose.model(
  "CreatorOnboardingQuestionReply",
  CreatorOnboardingQuestionReplySchema
);

module.exports.CreatorOnboardingQuestionReply = CreatorOnboardingQuestionReply;
