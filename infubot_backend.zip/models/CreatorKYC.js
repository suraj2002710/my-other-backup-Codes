const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorKYCSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
    // unique: true,
  },
  pan_card_number: {
    type: String,
    required: true,
  },
  adhaar_card_number: {
    type: String,
  },
  doc_image: {
    type: String,
  },
});

const CreatorKYC = mongoose.model("CreatorKYC", CreatorKYCSchema);

module.exports.CreatorKYC = CreatorKYC;
