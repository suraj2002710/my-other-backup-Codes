const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
const Schema = mongoose.Schema;

const OnboardingQuestionsSchema = new Schema(
  {
    question: {
      type: String,
      required: true,
    },
    type : {
        type: String,
        default: "Text",
        enum: ["Text", "Checkbox", "Radio", "Number"],
        required: true,
    },
    isCheckbox: {
        type: Boolean,
        default : false
    },
    isRadio: {
        type: Boolean,
        default : false
    },
    supportedCheckboxValues : {
        type : [String],
        default : []
    },
    supportedRadioValues : {
        type : [String],
        default : []
    },
    creator_niche: {
        type: String,
        required : true,
        enum: ["Beauty", "Entertainment", "Fashion", "Fitness", "Food","Lifestyle","Travel"],
      },
  },
  {
    timestamps: true,
  }
);

const OnboardingQuestions = mongoose.model("OnboardingQuestions", OnboardingQuestionsSchema);

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect("mongodb+srv://payment_app:12341234@cluster0-e7srs.mongodb.net/celebgaze?retryWrites=true&w=majority", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    // Read JSON file
    const data = fs.readFileSync(path.join(__dirname, "../seeder/onboardingQuestion.json"), "utf8");

    // Parse JSON data
    const questions = JSON.parse(data);

    // Insert data into MongoDB
    await OnboardingQuestions.insertMany(questions);

    console.log("Data seeded successfully!");
    process.exit(0);
  } catch (err) {
    console.error("Error seeding data:", err);
    process.exit(1);
  }
};


// seedData()

module.exports.OnboardingQuestions = OnboardingQuestions;
