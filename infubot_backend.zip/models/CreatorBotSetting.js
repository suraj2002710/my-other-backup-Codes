const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorBotSettingSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
    unique: true,
  },
  bot_title: {
    type: String,
    default: "My bot title",
    required: true,
  },
  bot_name: {
    type: String,
    default: "AI assistant name",
    required: true,
  },
  bot_language: {
    type: String,
    default: "English",
    required: true,
  },
  message: {
    type: String,
    default: "Hello Everyone",
    required: true,
  },
  cost_per_msg: {
    type: Number,
    default: 50,
    required: true,
  },
  cost_per_ai_msg: {
    type: Number,
    default: 25,
    required: true,
  },
  cost_audio_per_min: {
    type: Number,
    default: 50,
    required: true,
  },
  cost_video_per_min: {
    type: Number,
    default: 50,
    required: true,
  },
  cosy_of_voice_message_per_minute: {
    type: Number,
    default: 50,
    required: true,
  },
  cost_of_single_image : {
    type: Number,
    default: 50,
    required: true,
  },
  cost_of_single_video : {
    type: Number,
    default: 50,
    required: true,
  },
  enable_audio: {
    type: Boolean,
    default : true
  },
  enable_video: {
    type: Boolean,
    default : true
  },
  bot_color_code: {
    type: String,
    default: "#2341DF,#08AAF7",
    required: true,
  },
  show_suggestion: {
    type: Boolean,
  },
  show_link_suggestion: {
    type: Boolean,
    required: true,
    default: false,
  },
  show_welcome_popup: {
    type: Boolean,
    required: true,
    default: false,
  },
  textSuggestion: {
    type: Array,
    default: [
      {
        text: "Study",
        is_active: true,
      },
      {
        text: "Fun",
        is_active: true,
      },
      {
        text: "Fitness",
        is_active: true,
      },
    ],
    required: true,
  },
  showLinkSuggestion: {
    type: Array,
    required: true,
  },
});

const CreatorBotSetting = mongoose.model(
  "CreatorBotSetting",
  CreatorBotSettingSchema
);

module.exports.CreatorBotSetting = CreatorBotSetting;
