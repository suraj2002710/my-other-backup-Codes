const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorLinkSuggestionSchema = new Schema({
  text: {
    type: String,
    required: true,
    unique: true,
  },
  is_active: {
    type: String,
    required: true,
  },
});

const CreatorLinkSuggestion = mongoose.model(
  "CreatorLinkSuggestion",
  CreatorLinkSuggestionSchema
);

module.exports.CreatorLinkSuggestion = CreatorLinkSuggestion;
