const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorBankDetailsSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
    unique: true,
  },
  upi_id: {
    type: String,
  },
  ifsc_code: {
    type: String,
  },
  account_number: {
    type: String,
  },
  account_name: {
    type: String,
  },
  account_type: {
    type: String,
  },
});

const CreatorBankDetails = mongoose.model(
  "CreatorBankDetails",
  CreatorBankDetailsSchema
);

module.exports.CreatorBankDetails = CreatorBankDetails;
