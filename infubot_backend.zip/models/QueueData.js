const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const QueueDataSchema = new Schema(
    {
        kafka_topic_id: {
            type: String,
            required: true,
          },
          creator_id: {
            type: String,
            required: true,
          },
          user_id: {
            type: String,
            required: true,
          },
          wallet_balance: {
            type: Number,
            required: true,
          },
          expected_time: {
            type: Number,
            required: true,
          },
          position_in_queue: {
            type: Number,
            required: true,
          },
          position_in_queue_when_insert_in_queue: {
            type: Number,
            required: true,
          }
    
    },
    {
      timestamps: true,
    }
);

const QueueData = mongoose.model("Queue_Datas", QueueDataSchema);

module.exports = QueueData;
