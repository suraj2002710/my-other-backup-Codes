const mongoose = require("mongoose");const Schema = mongoose.Schema;

const CreatorFineTuneSchema = new Schema(
   {
      creator_id: {
         type: String,
         required: true,
      },
     creator_ai_name:{
        type:String,
        required: false,
     },
     creator_about:{
        type:String,
        required: false,
     },
     modest:{
        type:Number,
        default:50,
     },
     flirty:{
        type:Number,
        default:50,
     },
     friendly:{
        type:Number,
        default:50,
     },
     aggressive:{
        type:Number,
        default:50,
     },
     quiet:{
        type:Number,
        default:50,
     },
     loud:{
        type:Number,
        default:50,
     },
     kind:{
        type:Number,
        default:50,
     },
     sarcastic:{
        type:Number,
        default:50,
     },
     youtube_url:{
        type:String,
        required: false,
     },
     instagram_url:{
        type:String,
        required: false,
     },
     pdf_url:{
        type:String,
        required: false,
     }
   },
   {
      timestamps: true,
   },
);

const CreatorFineTune = mongoose.model("AI_CreatorFineTune", CreatorFineTuneSchema);

module.exports.CreatorFineTune = CreatorFineTune;
