const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CallNotificationSchema = new Schema(
  {
    user_email: {
      type: String,
      required: false,
    },
    creator_email: {
      type: String,
      required: true,
    },
    user_id: {
      type: String,
      required: false,
    },
    creator_id: {
      type: String,
      required: true,
    },
    call_type: { // 'audio' or 'video'
      type: String,
      required: true,
    },
    call_seen: {  
      type: Boolean,
      default: false,
      required: true
    },
    call_id: {  
      type: String,
      required: true,
    }
  },
  {
    timestamps: true, // timestamps will automatically add 'createdAt' and 'updatedAt' fields
  }
);

const CallNotification = mongoose.model("CallNotification", CallNotificationSchema);

module.exports.CallNotification = CallNotification;
