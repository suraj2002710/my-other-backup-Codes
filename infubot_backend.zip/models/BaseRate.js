const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const BaseRatesSchema = new Schema({
  base_cost_per_msg: {
    type: Number,
    default : 10
  },
  base_cost_per_ai_msg: {
    type: Number,
    default : 2
  },
  base_cost_audio_per_min: {
    type: Number,
    default : 42
  },
  base_cost_video_per_min: {
    type: Number,
    default : 110
  },
  base_cost_video_per_min: {
    type: Number,
    default : 110
  },
  base_cost_of_voice_message_per_min : {
    type: Number,
    default: 50,
    required: true,
  },
  base_cost_of_single_image : {
    type: Number,
    default: 50,
    required: true,
  },
  base_cost_of_single_video : {
    type: Number,
    default: 50,
    required: true,
  },
  gst: {
    type: Number,
    default : 15
  },
  platform_fee: {
    type: Number,
    default : 5
  },
  base_rate_of_security_amount: {
    type: Number,
    default: 10,
    // required: true,
  },
}, {
  timestamps: true
});

const BaseRates = mongoose.model("BaseRates", BaseRatesSchema);

module.exports.BaseRates = BaseRates;
