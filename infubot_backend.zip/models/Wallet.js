const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const WalletSchema = new Schema({
  user_id: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  user_email: {
    type: String,
    required: true,
  },
  wallet_balance: {
    type: Number,
    required: true,
  },
  sign_up_bonus: {
    type: Number,
    required: false,
  },
});

const Wallet = mongoose.model("Wallet", WalletSchema);

module.exports.Wallet = Wallet;
