const mongoose = require("mongoose");
const moment = require("moment-timezone");
const Schema = mongoose.Schema;

const CreatorWithdrawHistorySchema = new Schema(
   {
      creator_id: {
         type: String,
         required: true,
      },
      withdraw_by_video_call: {
         type: Number,
         default: 0,
      },
      withdraw_by_message: {
         type: Number,
         default: 0,
      },
      withdraw_by_ai_message: {
         type: Number,
         default: 0,
      },
      total_security_amount:{
        type: Number,
        default: 0,
      },
      total_withdraw: {
         type: Number,
         default: 0,
      },
      withdraw_date:{
         type: Date,
         default: () => moment().tz("Asia/Kolkata").toDate(),
      }
   },
   {
      timestamps: true,
   },
);

const CreatorWithdrawHistory = mongoose.model("CreatorWithdrawHistory", CreatorWithdrawHistorySchema);

module.exports.CreatorWithdrawHistory = CreatorWithdrawHistory;
