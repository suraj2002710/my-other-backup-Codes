const mongoose = require("mongoose");

const Schema = mongoose.Schema;


const UserBidderSchema = new Schema({
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique : true
    },
    bid_amount : {
      type: Number,
      required: true,
    },
    bided_at : {
      type: Date,
      default: Date.now
    }
  });

const CreatorBiddingSchema = new Schema(
  {
    creator_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
    },
    bidder: [UserBidderSchema],
  },
  {
    timestamps: true,
  }
);

const CreatorBidding = mongoose.model(
  "CreatorBidding",
  CreatorBiddingSchema
);

module.exports.CreatorBidding = CreatorBidding;
