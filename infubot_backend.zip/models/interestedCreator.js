const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const InterestedCreatorSchema = new Schema(
  {
    fullname: {
      type: String,
      required: false,
    },
    dob: {
      type: Date,
      required: false,
    },
    email: {
      type: String,
      unique: true,
      required : true,
      validate: {
        validator: function (v) {
          return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
        },
        message: "Please enter a valid email",
      },
    },
    instagram_handle: {
      type: String,
      unique: true,
      required : false
    },
    number_of_followers: {
      type: String,
      required : false
    },
    previous_experiance_with_ai : {
      type: Boolean,
      default: false,
    },
    interested_niche: {
      type: String,
      default : "Fitness",
      enum: ["Beauty", "Entertainment", "Fashion", "Fitness", "Food","Lifestyle","Travel"],
    },
    processing_stage : {
      type: String,
      default : "New",
      enum: ["New", "InProgress", "Under Review","Document Processing","Complete"],
    },
  },
  {
    timestamps: true,
  }
);

const InterestedCreator = mongoose.model("InterestedCreator", InterestedCreatorSchema);

module.exports.InterestedCreator = InterestedCreator;
