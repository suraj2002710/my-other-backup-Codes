const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorNewSchema = new Schema(
  {
    CID:{
      type: String,
      required: false,
    },
    first_name: {
      type: String,
      required: false,
    },
    last_name: {
      type: String,
      required: false,
    },
    dob: {
      type: Date,
      required: false,
    },
    email: {
      type: String,
      unique: true,
      required : true,
      validate: {
        validator: function (v) {
          return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
        },
        message: "Please enter a valid email",
      },
    },
    password: {
      type: String,
      required: true,
    },
    fcm_token: {
      type: String,
      required: false,
    },
    pushy_device_id: {
      type: String,
      required: false,
    },
    phone_number: {
      type: String,
      unique: true,
      required : false
    },
    bio: {
      type: String,
    },
    profile_pic: {
      type: String,
      default: "public/creator/defaul_profile_pic.png",
    },
    address: {
      type: String,
    },
    username: {
      type: String,
      unique: true,
      required: true,
    },
    payout_setting: {
      type: Boolean,
      default: false,
    },
    email_verifed: {
      type: Boolean,
    },
    is_active: {
      type: Boolean,
    },
    is_logged_in: {
      type: Boolean,
      default:false
    },
    has_ai_personality: {
      type: Boolean,
      default : false
    },
    creator_status: {
      type: String,
      default: "available",
      enum: ["available","audio_call", "video_call", "chatting","on_call","ai_mode"],
    },
    creator_niche: {
      type: String,
      default : "Fitness",
      enum: ["Beauty", "Entertainment", "Fashion", "Fitness", "Food","Lifestyle","Travel"],
    },
    gender : {
      type: String,
      required : false,
      enum: ["Male", "Female","Non-binary"],
    },
    country : {
      type : String,
      required : false,
    },
    state : {
      type : String,
      required : false,
    },
    dnd_mode : {
      type: Boolean,
      default:false
    },
    is_creator_on_screen: {
      type: Boolean,
      default:false,
    },
    is_kyc_added : {
      type: Boolean,
      default:false
    },
    is_banking_details_added : {
      type: Boolean,
      default:false
    },
    is_billing_details_added : {
      type: Boolean,
      default:false
    },
    is_kyc_verified : {
      type: Boolean,
      default:false
    },
    is_banking_details_verified : {
      type: Boolean,
      default:false
    },
    is_billing_details_verified : {
      type: Boolean,
      default:false
    },
    instagram_url: {
      type: String,
      required: false,
    },
    profit_share: {
      type: Number,
      required: false,
    },
    creator_message: {
      type: String,
      default: "Hey! How's it going? What's on your mind today?"
    },
    creator_login_token:{
      type: String,
      required: false,
    }
  },
  {
    timestamps: true,
  }
);

const Creator = mongoose.model("NewCreator", CreatorNewSchema);

module.exports.Creator = Creator;
