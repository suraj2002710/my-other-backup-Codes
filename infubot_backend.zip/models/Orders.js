const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const OrderSchema = new Schema(
  {
    creator_id: {
      required: true,
      type: Schema.Types.ObjectId,
      ref: "Creator",
    },

    creator_username: {
      required: true,
      type: String,
    },
    user_id: {
      required: true,
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    order_id: {
      required: true,
      type: String,
    },
    type: {
      default: "Wallet Recharge",
      type: String,
    },

    gross_amount: {
      required: true,
      type: String,
    },

    txn_status: {
      type: String,
      default: "processing",
      enum: ["processing", "success","failed"],
    },

    payment_gateway : {
      type: String,
      required : false
    },

    payment_method: {
      type: String, 
      required : false
    },
  },
  {
    timestamps: true,
  }
);

const Orders = mongoose.model("Order", OrderSchema);

module.exports.Orders = Orders;
