const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const txnSchema = new mongoose.Schema({
  user_id: {
    type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
  },
  user_email : {
    type : String,
    required : true
  },
  creator_id : {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: false,
  },
  creator_email : {
    type : String,
    required : false
  },
  type : {
    type : String,
    required : true,
    enum : ["Audio","Video","Wallet Recharge"]
  },
  amount : {
    type : Number,
    required : true
  },
  total_amount : {
    type : Number,
    required : false
  },
  gst : {
    type : Number,
    required : false
  },
  platform_fee : {
    type : Number,
    required : false
  },
  transaction_id : {
    type : String,
    required : false
  },
  payment_received_from:{
    type : String,
    required : false
  },
  payment_date:{
    type : String,
    required : false
  },
  status : {
    type : String,
    required : false,
    enum : ["success","failed","pending"]
  }
},{
  timestamps: true,
});

// module.exports = mongoose.model('Transaction', txnSchema);

const Transaction = mongoose.model(
  "Transaction",
  txnSchema
);

module.exports.Transaction = Transaction;

