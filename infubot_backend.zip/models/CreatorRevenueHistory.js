const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorRevenueHistorySchema = new Schema(
  {
    creator_email: {
      type: String,
      required: true,
    },
    user_email: {
      type: String,
      required: true,
    },
    user_name: {
      type: String,
      required: true,
    },
    creator_name: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    type: {
      type: String,
      enum: ["video", "audio", "chat","ai"],
      required: true,
    },
    duration : {
      type : String,
      required : false
    }
  },
  {
    timestamps: true,
  }
);

const CreatorRevenueHistory = mongoose.model(
  "CreatorRevenueHistory",
  CreatorRevenueHistorySchema
);

module.exports.CreatorRevenueHistory = CreatorRevenueHistory;
