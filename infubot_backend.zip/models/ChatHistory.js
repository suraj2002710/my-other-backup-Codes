const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const ChatHistorySchema = new Schema(
  {
    user_name: {
      type: String,
      required: true,
    },
    creator_name: {
      type: String,
      required: true,
    },
    user_id: {
      type: String,
      required: true,
    },
    creator_id: {
      type: String,
      required: true,
    },
    message_from: {
      type: String,
      required: true,
    },
    message_text: {
      type: String,
      required: true,
    },
    message_id: {
      type: String,
      required: true,
    },
    is_notification: {
      type: String,
    },
    is_seen: {
      type: String,
    },
    user_conversation_id: {
      type: String,
    },
    from_ai: {
      type: Boolean,
      default : false
    }
  },
  {
    timestamps: true,
  }
);

const ChatHistory = mongoose.model("ChatHistory", ChatHistorySchema);

module.exports.ChatHistory = ChatHistory;
