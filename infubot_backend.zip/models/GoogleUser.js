const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const GoogleUserSchema = new Schema(
  {
    sub: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    first_name: {
      type: String,
      required: true,
    },
    last_name: {
      type: String,
      required: true,
    },
    profile_image: {
      type: String,
    },
    email: {
      type: String,
      required: true,
    },
    email_verified: {
      type: Boolean,
      required: true,
    },
    locale: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const GoogleUser = mongoose.model("Googleuser", GoogleUserSchema);

module.exports.GoogleUser = GoogleUser;
