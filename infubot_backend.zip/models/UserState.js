const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userStateSchema = new Schema({
  userId: String,
  data: Object,
});

const UserState = mongoose.model("UserState", userStateSchema);

module.exports.UserState = UserState;
