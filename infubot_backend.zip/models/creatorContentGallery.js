const mongoose = require("mongoose");

const Schema = mongoose.Schema;

// Define a sub-schema for reports
const reportSchema = new Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  reason: {
    type: String,
    required: true,
    enum: [
      'Inappropriate Content',
      'Harassment or Bullying',
      'Hate Speech',
      'Intellectual Property Violation',
      'Spam or Misleading',
      'Other'
    ]
  },
  reportedAt: {
    type: Date,
    default: Date.now
  }
});


const creatorContentGallerySchema = new Schema(
  {
    // User who uploaded the content
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
    },
    // Description of the content
    description: {
      type: String,
      required: true,
    },
    // Content type (image/video)
    contentType: {
      type: String,
      required: true,
      enum: ["image", "video"],
    },
    // URL of the content
    contentURL: {
      type: String,
      required: true,
    },
    // Pricing details
    price: {
      type: Number,
      required: false,
      default: 0,
    },
    // Privacy setting (public/private)
    isPrivate: {
      type: Boolean,
      required: true,
      default: false,
    },
    discount: {
      type: Number,
      required: false,
      default: 0,
    },
    offerDetails: {
      type: String,
      required: false,
    },
    views: {
      type: Number,
      required: true,
      default: 0,
    },
    likes: {
      count: {
        type: Number,
        required: true,
        default: 0,
      },
      users: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      }],
    },
    flag: {
      count: {
        type: Number,
        required: true,
        default: 0,
      },
      users: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      }],
    },
    comment: {
      text: {
        type: String,
        required: false,
      },
      users: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      }],
    },
    dislikes: {
      count: {
        type: Number,
        required: true,
        default: 0,
      },
      users: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      }],
    },
    reports: [reportSchema]
  },
  {
    timestamps: true,
  }
);

const CreatorContentGallery = mongoose.model(
  "CreatorContentGallery",
  creatorContentGallerySchema
);

module.exports.CreatorContentGallery = CreatorContentGallery;
