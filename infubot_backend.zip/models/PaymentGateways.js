const mongoose = require('mongoose');

const gatewaySchema = new mongoose.Schema({
  gateway_id: {
    type: Number,
    required: true,
    unique: true
  },
  icon: String,
  title: String,
  type: String,
  open_in: String,
  order_id: String,
  payment_url: String,
  status: Number,
  created_at: Date,
  updated_at: Date
});

module.exports.PaymentGateways = mongoose.model('Gateways', gatewaySchema);