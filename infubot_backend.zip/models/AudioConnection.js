const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AudioConnectivtySchema = new Schema(
  {
    user_id: {
      type: String,
    },
    creator_id: {
      type: String,
    },
    channel_room_id: {
      type: String,
    },
    connection: {
      type: String,
      enum: ["waiting", "ongoing", "cancelled", "not_answered", "complete","declined"],
    },
    start_time: {
      type: Date,
    },
    end_time: {
      type: Date,
    },
    declined_by : {
      type : String,
      default : null,
    },
    duration : {
      type : String,
      required : false
    },
    user_queue_id : {
      type : String,
      default : null,
    }
  },
  {
    timestamps: true,
  }
);

const AudioConnectivty = mongoose.model(
  "AudioConnectivty",
  AudioConnectivtySchema
);

module.exports = AudioConnectivty;
