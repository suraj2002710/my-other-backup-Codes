const mongoose = require('mongoose');

// Define the schema for deleted users
const DeletedUserSchema = new mongoose.Schema({
  user_id : {
    type: "String",
    required: true,
  },
  email: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  deleted_on : {
    type: Date,
    default: Date.now
  },
  reason: {
    type: String,
    required: false
  }
}, { timestamps: true }); // Includes createdAt and updatedAt timestamps

// Create the model from the schema
const DeletedUser = mongoose.model('DeletedUser', DeletedUserSchema);

module.exports.DeletedUser = DeletedUser;
