const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorBillingDetailsSchema = new Schema({
  creator_id: {
    type: Schema.Types.ObjectId,
    ref: "Creator",
    required: true,
    unique: true,
  },
  billing_name: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  zip_code: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  state: {
    type: String,
    required: true,
  },
  gstin: {
    type: String,
  },
});

const CreatorBillingDetails = mongoose.model(
  "CreatorBillingDetails",
  CreatorBillingDetailsSchema
);

module.exports.CreatorBillingDetails = CreatorBillingDetails;
