const mongoose = require("mongoose");
const crypto = require('crypto');
const Schema = mongoose.Schema;

const OTPSecretMapperSchema = new Schema(
  {
    id: {
      type : "String",
      required: true,
    },
    secret_value: {
      type: String,
      required: true,
    },
    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);



const OTPSecretMapper = mongoose.model("OTPSecretMapper", OTPSecretMapperSchema);

module.exports.OTPSecretMapper = OTPSecretMapper;
