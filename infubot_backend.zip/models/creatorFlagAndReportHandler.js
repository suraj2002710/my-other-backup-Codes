const mongoose = require("mongoose");

const Schema = mongoose.Schema;


const flagSchema = new Schema({
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    reason: {
      type: String,
      required: true,
    },
    reportedAt: {
      type: Date,
      default: Date.now
    }
  });

const reportSchema = new Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  reason: {
    type: String,
    required: true,
  },
  feedback: {
    type : String,
    required : true
  },
  reportedAt: {
    type: Date,
    default: Date.now
  }
});


const CreatorFlagsAndReportsSchema = new Schema(
  {
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
    },
    flag: [flagSchema],
    reports: [reportSchema]
  },
  {
    timestamps: true,
  }
);

const CreatorFlagger = mongoose.model(
  "CreatorFlagsAndReports",
  CreatorFlagsAndReportsSchema
);

module.exports.CreatorFlagger = CreatorFlagger;
