const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const conversationStateSchema = new Schema({
  conversationId: String,
  data: Object,
});

const ConversationState = mongoose.model(
  "ConversationState",
  conversationStateSchema
);

module.exports.ConversationState = ConversationState;
