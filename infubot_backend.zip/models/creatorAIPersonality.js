const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CreatorAIPersonalitySchema = new Schema(
  {
    tagline : {
      type: String,
      required : false,
      default : null
    },
    general_description : {
      type: String,
      required : false,
      default : null
    },
    ai_personality_name : {
      type: String,
      required : false,
      default : null
    },
    personality_description : {
      type: String,
      required : false,
      default : null
    },
    creator_id: {
      type: Schema.Types.ObjectId,
      ref: "Creator",
      required: true,
      unique: true,
    },
    tonality: {
      type: [String],
      required: true,
    },
    profession: {
      type: [String],
      required: true,
    },
    isFriendly: { type: Boolean, required: false , default:true},
    isHumorous: { type: Boolean, required: false , default:true},
    isOutgoing: { type: Boolean, required: false , default:true},
    isCreative: { type: Boolean, required: false , default:true},
    isConfident: { type: Boolean, required: false , default:true},
    isEmotional: { type: Boolean, required: false , default:true},
    isArtistic: { type: Boolean, required: false , default:true},
    isAdventurous: { type: Boolean, required: false , default:true},
    isActive: { type: Boolean, required: false , default:true},
  },
  {
    timestamps: true,
  }
);

const CreatorAIPersonality = mongoose.model(
  "CreatorAIPersonality",
  CreatorAIPersonalitySchema
);

module.exports.CreatorAIPersonality = CreatorAIPersonality;
