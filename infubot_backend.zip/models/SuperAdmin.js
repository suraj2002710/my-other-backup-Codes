const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const SuperAdminSchema = new Schema(
  {
    first_name: {
      type: String,
      required: true,
    },
    last_name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      unique: true,
      required : false,
      validate: {
        validator: function (v) {
          return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
        },
        message: "Please enter a valid email",
      },
    },
    password: {
      type: String,
      required: true,
    },
    phone_number: {
      type: String,
      unique: true,
      required : true
    },
    profile_pic: {
      type: String,
      default: "public/creator/defaul_profile_pic.png",
    },
    username: {
      type: String,
      unique: true,
      required: false,
    }
  },
  {
    timestamps: true,
  }
);

const SuperAdmin = mongoose.model("SuperAdmin", SuperAdminSchema);

module.exports.SuperAdmin = SuperAdmin;
