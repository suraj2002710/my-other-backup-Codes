const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CompanyPolicySchema = new Schema(
  {
    policyType: {
      type: String,
      enum: ["Privacy Policy", "Start Chat Message", "Privacy Policy Approval Text","Web UI Message"],
      unique : true,
      required : true
    },
    content: {
      type: String,
      required: true
    }
  },
  {
    timestamps: true,
  }
);

const CompanyPolicy = mongoose.model(
  "CompanyPolicy",
  CompanyPolicySchema
);

module.exports.CompanyPolicy = CompanyPolicy;
