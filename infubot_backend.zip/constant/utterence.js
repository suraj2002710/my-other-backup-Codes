module.exports = {
  DIRTY_TALK: (name) => {
    //SEX_CHAT
    const response = {
      type: "message",
      text: `So glad you choose dirty talk. ${name} can't wait to connect with you on the same. Please click on the link below to deposite the required amount to continue with the chat.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  DEFAULT: (name) => {
    //SEX_CHAT
    const response = {
      type: "message",
      text: `Hey there! 🚀 Welcome to influbot.ai – where possibilities unfold. Buckle up for an adventure of innovation and convenience. Let's make every moment with the app count!`,
      inputHint: "Pay Now",
    };
    return response;
  },

  CATCH_COMPANION: (name) => {
    const response = {
      type: "message",
      text: `Amazing! ${name} also does not have plenty of friends. We are sure you can be her closest companion. To move further click on the link below deposit the required amount`,
      inputHint: "Pay Now",
    };
    return response;
  },

  WORKOUT_SESH: (name) => {
    const response = {
      type: "message",
      text: `${name} does have some crazy curves. Wondering how she get those. Catch up with her and she can get you all the details you want. Do you wish to move further ?`,
      inputHint: "Pay Now",
    };
    return response;
  },

  LIFESTYLE: (name) => {
    const response = {
      type: "message",
      text: `Wondering what ${name} does the entire day? Well you can now ask her instead. The link mentioned below will redirect you to her. Don't wait, GO !!!`,
      inputHint: "Pay Now",
    };
    return response;
  },

  SEX_LIFE_BETTER: (name) => {
    const response = {
      type: "message",
      text: `Struggling with your partner? Ask the pro. Get connected with her below and solve your queries now.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  FUN: (name) => {
    const response = {
      type: "message",
      text: `This sounds so much fun! ${name} is already waiting for this. Don't make her wait any longer and pay now to get connected with her.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  FANTASIES: (name) => {
    const response = {
      type: "message",
      text: `Wish to exchange your fantacies with ${name}? Deposite your amount now and see how dirty it gets.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  NASTY: (name) => {
    const response = {
      type: "message",
      text: `People get horny all the time and trust me ${name} is too. Get connected with her now and calm both of you.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  HIDDEN_SIDE: (name) => {
    const response = {
      type: "message",
      text: `Wondering how nasty ot can get? Click below and get transparent with your favorite, ${name}`,
      inputHint: "Pay Now",
    };
    return response;
  },

  NASTY_PICTURE: (name) => {
    //SEE_PHOTOS
    const response = {
      type: "message",
      text: `We all love some media, Don't we? Don't worry, step back and relax. Media sharing will be available soon till then your favorite creator can satisfy you with some voice notes. Wish to continue?`,
      inputHint: "Pay Now",
    };
    return response;
  },

  OUT_OF_SCOPE: (name) => {
    const outOfScopeArray = [
      `Oops! I don't understand this. Does this means you want to connect with ${name}`,
      `Ugh! Unfortunately my brain is unable to take this, but does this means you want to chat with ${name} directly?`,
      `Sorry! I might not be able to help you in this. Should I connect you with ${name} for a chat? I am sure she will be able to understand better.`,
      `Damn, I am not as smart as ${name}. Should I redirect this to her so she understands what you're trying to ask?`,
    ];

    console.log(
      outOfScopeArray[Math.floor(Math.random() * outOfScopeArray.length)]
    );

    return outOfScopeArray[Math.floor(Math.random() * outOfScopeArray.length)];
  },

  WHO_ARE_YOU: (name) => {
    const response = {
      type: "message",
      text: `I am her assistant bot, Meg, chatting with you right now but as soon as you process the payment, ${name} will be connected with you.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  SEE_PHOTOS: (name) => {
    const response = {
      type: "message",
      text: `That's great to move further in connecting with her. Please click on the link below to pay.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  SEX_CHAT: (name) => {
    const response = {
      type: "message",
      text: `Let ${name} answer all your queries and needs. Plesae click on the link below to get started.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  MEETING: (name) => {
    const response = {
      type: "message",
      text: `Ugh! This can;t be happen but ${name} can personally talk to you and vibe with you. Want to move further ?`,
      inputHint: "Pay Now",
    };
    return response;
  },

  NEEDS: (name) => {
    const response = {
      type: "message",
      text: `${name} will definitely answer your question and talk with you choice.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  GIFT: (name) => {
    const response = {
      type: "message",
      text: `${name} loves gifts, get to the link below to start a converstion with her and know what she really wants.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  WHY_CREATOR_HERE: (name) => {},

  REALISTIC_PIC: (name) => {
    const response = {
      type: "message",
      text: `${name} will surely confirm you that it's her chatting with you once you pay and I can get out of the picture.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  HOWS_DAY: (name) => {
    const response = {
      type: "message",
      text: `My day is amazing. It's sunny out here. ${name} will be excited to know how your day was. Get connected with her now.`,
      inputHint: "Pay Now",
    };
    return response;
  },

  NO_BALANCE: (name) => {
    const response = {
      type: "message",
      text: `Hey, Your don't have sufficient balance. Please recharge your wallet to talk to ${name}`,
      inputHint: "Pay Now",
    };
    return response;
  },
};
