module.exports = {
  SOMETHING_WENT_WRONG: "Something went worng, please try again!",

  BTN_NAUGHTY_CHATS: "Naughty Chats",
  BTN_ROMANTIC: "Romantic",
  BTN_SAD_SONGS: "Sad Songs",
  BTN_PROMOTIONS: "Promotions",
  BTN_CONTACT: "Contact",
  SONETHING_WENT_WRONG:
    "It seems bot is not up at that moment. Please try again after some time.",
};
