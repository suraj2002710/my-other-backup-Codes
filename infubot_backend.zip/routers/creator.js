const express = require("express");const fs = require("fs");

const creatorController = require("../controllers/creatorControllers");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");
const { userVerifyToken } = require("../services/userVerifyToken");
const multer = require("multer");
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const AWS = require('aws-sdk');
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const path = require("path");
const multerS3 = require("multer-s3");
const mime = require("mime-types");
const { v4: uuidv4 } = require("uuid");
const { rateLimiter } = require("../utilities/rate_limiter");
const { superAdminVerifyToken } = require("../services/superAdminVerifyToken");

let {CreatorFineTune}=require('../models/CreatorFineTune');
let {Creator}=require('../models/Creator')
AWS.config.update({
   accessKeyId: 'AKIAU7NFKKARJRRN5OHF',
   secretAccessKey: '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',
   region: 'us-east-1',
 });


const s3 = new AWS.S3();
const bucketName = 'influbot-backend';

const fileFilter = (req, file, cb) => {
   // Accept images only
   if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
      req.fileValidationError = "Only image files are allowed!";
      return cb(new Error("Only image files are allowed!"), false);
   }
   cb(null, true);
};

function generateRandomString() {
   let result = '';
   const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

   for (let i = 0; i < 8; i++) {
       result += characters.charAt(Math.floor(Math.random() * characters.length));
   }

   return result;
}

// S3 upload function
const uploadToS3 = (file) => {
   return new Promise((resolve, reject) => {
       const params = {
           Bucket: bucketName,
           Key: `profile_pics/${generateRandomString()}_${file.originalname}`,
           Body: file.buffer,
           ContentType: file.mimetype,
         //   ACL: 'public-read'
       };

       console.log(params)
       s3.upload(params, (err, data) => {
           if (err) {
             console.log(err)
               reject(err);
           } else {
            console.log("----------------------s3 upload data--------------",data)
               resolve(data);
           }
       });
   });
};


const storage = multer.diskStorage({
   destination: function (req, file, cb) {
      const dest = "public/uploads/";

      // Check if the directory exists
      fs.access(dest, fs.constants.F_OK, (err) => {
         if (err) {
            // Directory does not exist, so create it
            fs.mkdir(dest, { recursive: true }, (err) => {
               if (err) {
                  cb(err);
               } else {
                  // Directory created, proceed to use it
                  cb(null, dest);
               }
            });
         } else {
            // Directory exists, proceed to use it
            cb(null, dest);
         }
      });
   },
   filename: function (req, file, cb) {
      cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname)); // Define the filename
   },
});

const creator_content_gallery_storage = multer.diskStorage({
   destination: function (req, file, cb) {
      const dest = "public/creator-content/";

      // Check if the directory exists
      fs.access(dest, fs.constants.F_OK, (err) => {
         if (err) {
            // Directory does not exist, so create it
            fs.mkdir(dest, { recursive: true }, (err) => {
               if (err) {
                  cb(err);
               } else {
                  // Directory created, proceed to use it
                  cb(null, dest);
               }
            });
         } else {
            // Directory exists, proceed to use it
            cb(null, dest);
         }
      });
   },
   filename: function (req, file, cb) {
      cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname)); // Define the filename
   },
});

// File filter for size and extension


// Set up Multer upload with fileFilter and size limit
const upload = multer({
   // storage: storage,
   limits: {
      fileSize: 1024 * 1024 * 30, // Limit of 5MB
   },
   fileFilter: fileFilter,
});



const creator_content_gallery = multer({
   storage: creator_content_gallery_storage,
   limits: {
      fileSize: 1024 * 1024 * 5, // Limit of 5MB
   },
});

//AWS Configuration
// const s3 = new S3Client({
//    region: "ap-south-1",
//    credentials: {
//       accessKeyId: process.env.AWS_KEY,
//       secretAccessKey: process.env.AWS_SECRET,
//    },
// });

const aws_upload = multer({
   storage: multerS3({
      s3: s3,
      bucket: "influbot",
      contentType: multerS3.AUTO_CONTENT_TYPE,
      key: function (req, file, cb) {
         // Use UUID to generate a unique file name
         const uniqueFileName = `${uuidv4()}`;
         cb(null, uniqueFileName);
      },
   }),
});

const router = express.Router();


router.post(
   "/update-creator-profile",
   creatorVerifyToken,
   upload.single("profile_pic"),
   async (req, res) => {
      console.log("------------------called upload pic----------------")
       if (req.fileValidationError) {
           return res.status(400).send(req.fileValidationError);
       }
       
       try {
         console.log(req.file)
         if(req.file){
            const data = await uploadToS3(req.file);
            console.log("file name ..............",data.key)
            req.body.profilePicUrl ="https://d3fvw6pnhjntvr.cloudfront.net/"+data.key; // Assuming you want to store the URL of the uploaded image
         }
           await creatorController.updateCreatorProfile(req, res);
       } catch (err) {
           res.status(500).send(err.message);
       }
   }
);

// router.post(
//    "/update-creator-profile",
//    creatorVerifyToken,
//    // aws_upload.single('profile_pic'),
//    upload.single("profile_pic"),
//    creatorController.updateCreatorProfile,
// );



router.get("/details/:id", creatorController.getCreatorDetails);


// router.get("/all", creatorController.getAllCreators);

router.post("/create-creator", creatorController.createCreator);

router.get("/get-profile", creatorVerifyToken, creatorController.getCreatorProfile);

router.get('/get-creator/fine-tune-data',creatorVerifyToken,creatorController.getCreatorFineTuneData)

router.post('/update/creator/fine-tune-data',creatorVerifyToken,creatorController.updateCreatorFineTuneData)

// router.get(
//   "/check-if-creator-email-exist",
//   creatorVerifyToken,
//   creatorController.checkIfEmailAlreadyExist
// );


router.get("/get-creator-profile-for-user/:creator_username", creatorController.getCreatorProfileForUser);


// router.post(
//   "/update-creator-profile_v2",
//   creatorVerifyToken,
//   aws_upload.single('profile_pic'),
//   // upload.single('profile_pic'),
//   creatorController.updateCreatorProfileV2
// );

router.get(
   "/profile_pic/view/:id",
   superAdminVerifyToken,
   // creatorVerifyToken,
   // aws_upload.single('profile_pic'),
   // upload.single('profile_pic'),
   creatorController.generateProfilePicture,
);

router.delete(
   "/delete-creator-profile/:id",
   superAdminVerifyToken,
   // creatorVerifyToken,
   creatorController.deleteCreatorProfile,
);

// router.delete(
//   "/delete-account",
//   creatorVerifyToken,
//   creatorController.deleteAccount
// );

router.post("/creator-login", rateLimiter.creator_login_rate_limiter, creatorController.postLogin);

// router.post("/creator-login-v2/send-otp", rateLimiter.creator_login_rate_limiter, creatorController.creatorLoginWithOTP);

// router.post("/creator-login-v2/otp-verify", rateLimiter.creator_login_rate_limiter, creatorController.verifyCreatorLoginOTP);

router.get("/creator-logout", creatorVerifyToken, creatorController.logoutCreator);

router.get("/send-otp", creatorController.generateCreatorOTP);

router.get("/verify-otp", creatorController.verifyCreatorOTP);

router.post("/send-notification-to-creator", userVerifyToken, creatorController.sendNotificationToCreator);

router.post("/check-creator-username", creatorController.checkCreatorUsernameExistance);

router.post("/creator-reset-password", creatorVerifyToken, creatorController.updatePassword);

// router.post(
//   "/creator-update-password",
//   creatorController.updatePassword
// );

router.post("/creator-notification", creatorController.getNotificationDetails);

router.put("/update-profile-pic", upload.single("profile_pic"), creatorVerifyToken, creatorController.updateCreatorProfilePicture);

// router.delete("/delete-creator", creatorController.deleteAllCreator);

router.post(
   "/upload-content",
   creatorVerifyToken,
   // creator_content_gallery.array('images'),
   aws_upload.array("images"),
   creatorController.uploadCreatorContentGallery,
);

// router.get("/content-galley", creatorVerifyToken, creatorController.getCreatorContentGallery);

// router.get("/content-galley/content/:id", creatorVerifyToken, creatorController.getSpecificContent);

// router.get("/content-galley/content/:id/view", creatorVerifyToken, creatorController.generatePresignedUrlForImage);

// router.delete("/content-galley/content/:id", creatorVerifyToken, creatorController.deleteSpecificCreatorContent);

// router.put("/content-galley/content/:id/discount", creatorVerifyToken, creatorController.addDiscount);

// router.post("/content-galley/content/:id/like", userVerifyToken, creatorController.like);

// router.post("/content-galley/content/:id/dislike", userVerifyToken, creatorController.dislike);

// router.post("/content-galley/content/:id/view", userVerifyToken, creatorController.view);

// router.post("/content-galley/content/:id/comment", userVerifyToken, creatorController.addComment);

// router.post("/content-galley/content/:id/report", userVerifyToken, creatorController.reportContent);

// router.post("/content-galley/content/:id/flag", userVerifyToken, creatorController.flagContent);

// router.get("/category-list", creatorController.getCreatorProfessionList);

router.get("/flag-list", creatorController.getCreatorFlagReasonList);

router.get("/report-list", creatorController.getCreatorReportReasonList);

router.post("/flag/:id", userVerifyToken, creatorController.flagCreator);

router.post("/unflag/:id", userVerifyToken, creatorController.unflagCreator);

router.get("/report/:id", userVerifyToken, creatorController.checkIfCreatorAlreadyReported);

router.post("/report/:id", userVerifyToken, creatorController.reportCreator);

router.post("/unreport/:id", userVerifyToken, creatorController.unreportCreator);

// router.get(
//    "/flag_and_reports/:id",
//    // userVerifyToken,
//    creatorController.getCreatorFlagAndReports,
// );


router.post("/fine-tune-data",async(req,res)=>{
   try{
      const creators = await Creator.find();
      if (creators.length > 0) {
          console.log(creators);
         //  creators.map(async(item)=>{
         //    console.log(item.id)
         //    let creatorFineTuneData=await CreatorFineTune.create({creator_id:item.id})
         //  })
         //  return res.status(200).json({
         //      statusCode: 200,
         //      message: "Creators found successfully.",
         //      data: creators
         //  });
      }
    return  res.status(400).json({
      statusCode:400,
      message:"creator not found."
    })
   }catch(error){

      console.log(error)
      return res.status(400).json({
         statusCode:400,
         message:error.message
      })
   }
})

module.exports = router;
