const express = require("express");

const superAdminController = require("../controllers/superAdminController");
const { superAdminVerifyToken } = require("../services/superAdminVerifyToken");
// const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

// router.get("/all", superAdminController.getAllSuperAdmins);

// router.delete("/delete/all", superAdminVerifyToken,superAdminController.deleteAllSuperAdmins);

router.delete("/delete/:super_admin_id", superAdminVerifyToken,superAdminController.deleteSuperAdminById);

// router.post("/create-super-admin", superAdminVerifyToken,superAdminController.createSuperAdmin);

router.post(
  "/check-profile",
  superAdminVerifyToken,
  superAdminController.getSuperAdminDetailsByPhone
);

router.post(
  "/get-profile",
  superAdminVerifyToken,
  superAdminController.getSuperAdminProfile
);

router.post(
  "/get-super-admin-profile-for-user",
  superAdminVerifyToken,
  superAdminController.getSuperAdminProfile
);

router.post(
  "/update-super-admin-profile",
  superAdminVerifyToken,
  superAdminController.updateSuperAdminDetails
);

router.post(
  "/reset-password",
  superAdminVerifyToken,
  superAdminController.resetPassword
);

router.post("/super-admin-login", superAdminController.loginSuperAdmin);

router.get("/creator_profile_info/:id", superAdminVerifyToken, superAdminController.getCreatorProfileForSuperAdmin);

router.put("/creator_profile_info/:id", superAdminVerifyToken, superAdminController.updateCreatorProfileForSuperAdmin);

router.get("/creator_profile_info/:id/bot", superAdminVerifyToken, superAdminController.getCreatorBotSettingDetails);

router.put("/creator_profile_info/:id/bot", superAdminVerifyToken, superAdminController.updateCreatorBotInformation);

router.get("/creator_profile_info/:id/revenue", superAdminVerifyToken, superAdminController.getCreatorRevenueDetails);

router.get("/creator_profile_info/:id/creator-call-logs", superAdminVerifyToken, superAdminController.getCreatorCallLogsDetails);

router.get("/creator_profile_info/:id/kyc-details", superAdminVerifyToken, superAdminController.getCreatorKYCDetails);

router.put("/creator_profile_info/:id/kyc-details", superAdminVerifyToken, superAdminController.updateCreatorKYCInformation);

router.get("/creator_profile_info/:id/billing-details", superAdminVerifyToken, superAdminController.getCreatorBillingDetails);

router.put("/creator_profile_info/:id/billing-details", superAdminVerifyToken, superAdminController.updateCreatorBillingInformation);

router.get("/creator_profile_info/:id/bank-details", superAdminVerifyToken, superAdminController.getCreatorBankDetails);

router.put("/creator_profile_info/:id/bank-details", superAdminVerifyToken, superAdminController.updateCreatorBankInformation);

router.get("/creator_profile_info/all/ai", superAdminVerifyToken, superAdminController.getAllCreatorAIDetails);

router.get("/creator_profile_info/:id/ai", superAdminVerifyToken, superAdminController.getCreatorAIDetails);

router.put("/creator_profile_info/:id/ai", superAdminVerifyToken, superAdminController.updateCreatorAIPersonality);

router.put("/interested_creator_info/:id", superAdminVerifyToken, superAdminController.updateInterestedCreatorStatus);


router.post("/create-money-withdraw",  superAdminController.createWithdrawalRequest);

// transaction details

// router.get("/transaction-details/:id", superAdminVerifyToken, superAdminController.getTransactionDetails);

// router.put("/transaction-details/:id", superAdminVerifyToken, superAdminController.updateTransactionDetails);

router.get("/transaction-details/all", superAdminController.getAllTransactionDetails);
module.exports = router;
