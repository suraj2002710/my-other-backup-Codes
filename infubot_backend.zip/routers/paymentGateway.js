const express = require("express");

const PaymentGatewayController = require("../controllers/paymentGatewayController");

const router = express.Router();

const { userVerifyToken } = require("../services/userVerifyToken");

router.get("/", PaymentGatewayController.getAllPaymentGateways);

const {payUForm,payUFailureHandler,payUSuccessHandler} = require('../payment_gateways/payU/index')

const minimumRecharge =(req,res,next)=>{
   try {
    console.log("inside minimumRecharge")
      const {amount} = req.body
      if(amount<100){
          return res.status(400).json({message:"Minimum recharge amount is 100"})
      }
      next()
  
   } catch (error) {

     return res.status(500).json({message:"Internal server error"})
   }
}
//payU
router.post('/pay-u/form',userVerifyToken,minimumRecharge,payUForm)
router.post('/pay-u/success',payUSuccessHandler)
router.post('/pay-u/failure',payUFailureHandler)

//indicPay
const {generatePayUrl,successHandler} = require('../payment_gateways/indicPay/index')

router.post('/indic-pay/generate-pay-url',userVerifyToken,minimumRecharge,generatePayUrl)
router.post('/indic-pay/web-hook',successHandler)
module.exports = router;


//pg phone pay

const {pgPayUrl,pgSuccessHandler}=require("../payment_gateways/pg-phonePay/index");
router.post('/phone-pay/generate-pay-url',userVerifyToken,minimumRecharge,pgPayUrl)
router.post('/phone-pay/web-hook',pgSuccessHandler)


//india online pay

let {generatePayUrlForIndiaOnly,successHandlerForIndiaOnlinePay}=require('../payment_gateways/indiaOnLinePay/index')

router.post('/india-online-pay/generate-pay-url',userVerifyToken,minimumRecharge,generatePayUrlForIndiaOnly)
router.post('/india-online-pay/web-hook',successHandlerForIndiaOnlinePay)