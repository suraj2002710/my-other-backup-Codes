const express = require("express");
const { superAdminVerifyToken } = require("../services/superAdminVerifyToken");

const baseRateController = require("../controllers/baseRateController");

const router = express.Router();

router.get("/", superAdminVerifyToken, baseRateController.getBaseRates);

router.post("/", superAdminVerifyToken, baseRateController.changeBaseRates);

module.exports = router;