const express = require("express");
const multer = require("multer");



const storage = multer.memoryStorage({
  destination: function (req, file, cb) {
    cb(null, "");
  },
});

const upload = multer({ storage: storage });

const userController = require("../controllers/userControllers");
const { userVerifyToken } = require("../services/userVerifyToken");
const {rateLimiter} = require("../utilities/rate_limiter")

const router = express.Router();

// router.get("/all", userController.getAllUsers);

// router.get("/live", userController.getAllLiveUsers);

// router.post("/profile", userVerifyToken, userController.getUserProfile);
router.get("/profile", userVerifyToken,userController.getUserProfile);

// router.post("/search-user-by-email", userController.getUserByEmail);

router.post("/check-email", userController.checkIfEmailExist);

router.post("/signup", userController.createUser);

router.post("/login", userController.loginUser);

// router.post("/login", rateLimiter.user_login_rate_limiter, userController.loginUser);

router.post("/google-login", userController.GoogleUser);


// router.post("/google-login", rateLimiter.user_login_rate_limiter, userController.GoogleUser);

router.get("/logout", userVerifyToken, userController.logoutUser);

// router.delete("/all", userController.deleteAllUsers);

// router.delete("/:id", userController.deleteUser);

// router.delete("/profile/delete",userVerifyToken, userController.deleteAccount);

router.get("/profile/delete-reason-list",userController.deletedReasonList);

// router.put(
//   "/update-profile",
//   userVerifyToken,
//   userController.updateUserDetails
// );

//reset-password

module.exports = router;
