const express = require("express");
const fs = require('fs');

const CreatorAIAnswer = require("../controllers/creatorAIAnswer");
// const { creatorVerifyToken } = require("../services/creatorVerifyToken");
// const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.post("/answer", CreatorAIAnswer.getAnswer);

router.post("/question", CreatorAIAnswer.addQuestion);

router.get("/question", CreatorAIAnswer.getAllQuestions);


module.exports = router;
