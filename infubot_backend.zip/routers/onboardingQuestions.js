const express = require("express");

const OnboardingQuestions = require("../controllers/onBoardingQuestions");

const router = express.Router();

router.get("/", OnboardingQuestions.getAllQuestions);

router.post("/", OnboardingQuestions.addGenreOnboardingQuestion);

router.get("/:creator_niche", OnboardingQuestions.getAllQuestionsOfNiche);

router.delete("/:creator_niche/:id", OnboardingQuestions.deleteOnboardingQuestions);

router.delete("/", OnboardingQuestions.deleteAllQuestions);

module.exports = router;
