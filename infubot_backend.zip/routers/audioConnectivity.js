const express = require("express");

const audioController = require("../controllers/audioController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");
const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.post(
  "/user-request-audio-connection",
  // userVerifyToken,
  audioController.userRequestToAudioConnectivity
);

router.post(
  "/creator-respond-audio",
  // userVerifyToken,
  audioController.creatorRespondToAudioCall
);

router.get(
  "/call-logs",
  creatorVerifyToken,
  audioController.creatorCallLogs
);

router.delete(
  "/call-logs",
  creatorVerifyToken,
  audioController.deleteAllCallLogs
);

router.get(
  "/call-logs-of-user-for-creator/:id",
  creatorVerifyToken,
  audioController.allCallLogsOfSpecificUser
);

router.get(
  "/missed-call-logs",
  creatorVerifyToken,
  audioController.missedCallLogs
);

router.get(
  "/missed-call-logs-of-user-for-creator/:id",
  creatorVerifyToken,
  audioController.missedCallLogsOfSpecificUser
);


router.post("/creator-decline-call", creatorVerifyToken, audioController.creatorDeclineCall)

router.post("/user-decline-call", audioController.userDeclinedCall)

module.exports = router;
