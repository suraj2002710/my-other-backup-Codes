const express = require("express");
const fs = require('fs');

const ContactUsFormController = require("../controllers/contactUsFormController");

const router = express.Router();

router.get("/", ContactUsFormController.getAllContactUsRequest);

router.post("/", ContactUsFormController.contactUsFormSubmit);


router.delete(
  "/all",
  ContactUsFormController.deleteAllContactUsRequest
);


module.exports = router;
