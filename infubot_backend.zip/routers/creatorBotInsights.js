const express = require("express");

const creatorBotInsightsControllers = require("../controllers/creatorBotInsightController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get(
  "/get-creator-bot-insights",
  creatorVerifyToken,
  creatorBotInsightsControllers.getCreatorBotInsights
);

module.exports = router;
