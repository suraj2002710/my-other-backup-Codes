const express = require("express");

const commonControllers = require("../controllers/commonControllers");

const router = express.Router();

router.get("/health-check", commonControllers.getSystemHealth);

router.get("/system-check", commonControllers.getServerHealth);

router.get("/token",commonControllers.getToken);

module.exports = router;