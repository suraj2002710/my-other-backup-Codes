const express = require("express");

const creatorBankDetailsController = require("../controllers/creatorBankDetailsController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get(
  "/",
  creatorVerifyToken,
  creatorBankDetailsController.getCreatorBankDetails
);

router.post(
  "/add-bank-details",
  creatorVerifyToken,
  creatorBankDetailsController.addCreatorBankDetails
);

router.post(
  "/update-bank-details",
  creatorVerifyToken,
  creatorBankDetailsController.updateCreatorBankDetails
);

router.post(
  "/change-bank-details",
  creatorVerifyToken,
  creatorBankDetailsController.changeBankDetails
);

module.exports = router;
