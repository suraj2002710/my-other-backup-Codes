const express = require("express");
const fs = require('fs');

const InterestedCreatorController = require("../controllers/interestedCreatorController");
const { superAdminVerifyToken } = require("../services/superAdminVerifyToken");
// const { creatorVerifyToken } = require("../services/creatorVerifyToken");
// const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.get("/all", InterestedCreatorController.getAllInterestedCreators);

router.post("/signup", InterestedCreatorController.interestedCreatorSignup);

router.put("/update-status", superAdminVerifyToken, InterestedCreatorController.interestedCreatorSignup);


router.delete(
  "/all",
  InterestedCreatorController.deleteAllInterestedCreator
);


module.exports = router;
