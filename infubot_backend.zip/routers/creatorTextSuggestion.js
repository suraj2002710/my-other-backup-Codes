const express = require("express");

const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const creatorTextSuggestionController = require("../controllers/creatorTextSuggestionController");

const router = express.Router();

router.get(
  "/get-creator-text-suggestion",
  creatorVerifyToken,
  creatorTextSuggestionController.getCreatorTextSuggestion
);

router.get(
  "/get-active-creator-text-suggestion",
  creatorVerifyToken,
  creatorTextSuggestionController.getActiveCreatorTextSuggestion
);

router.post(
  "/add-creator-text-suggestion",
  creatorVerifyToken,
  creatorTextSuggestionController.addCreatorTextSuggestion
);

router.post(
  "/bulk-addition-creator-text-suggestion",
  creatorVerifyToken,
  creatorTextSuggestionController.bulkAdditionCreatorTextSuggestion
);

router.post(
  "/update-creator-text-suggestion/:id",
  creatorVerifyToken,
  creatorTextSuggestionController.updateCreatorTextSuggestion
);

router.post(
  "/delete-creator-text-suggestion/:id",
  creatorVerifyToken,
  creatorTextSuggestionController.deleteCreatorTextSuggestion
);

module.exports = router;
