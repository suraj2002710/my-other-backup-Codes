const express = require("express");

const creatorLinkSuggestionController = require("../controllers/creatorLinkSuggestionController");

const router = express.Router();

router.get(
  "/get-creator-link-suggestion",
  creatorLinkSuggestionController.getCreatorLinkSuggestion
);

router.get(
  "/get-active-creator-link-suggestion",
  creatorLinkSuggestionController.getActiveCreatorLinkSuggestion
);

router.post(
  "/add-creator-link-suggestion",
  creatorLinkSuggestionController.addCreatorLinkSuggestion
);

router.post(
  "/update-creator-link-suggestion/:id",
  creatorLinkSuggestionController.updateCreatorLinkSuggestion
);

module.exports = router;
