const express = require("express");

const CreatorQueueController = require("../controllers/creatorQueueController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get(
  "/waiting-list",
  creatorVerifyToken,
  CreatorQueueController.getAllWaitingUsersOfTheCreatorInQueue
);

router.get(
    "/queue-info",
    creatorVerifyToken,
    CreatorQueueController.getCreatorQueueInformation
);

router.get(
  "/pause-queue",
  creatorVerifyToken,
  CreatorQueueController.pauseCreatorQueue
);


router.get(
  "/resume-queue",
  creatorVerifyToken,
  CreatorQueueController.resumeCreatorQueue
);


router.post(
  "/delete_user_from_queue",
  CreatorQueueController.removeUserFromQueue
);

module.exports = router;
