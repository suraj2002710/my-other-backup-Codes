const express = require("express");

const otpValidatorController = require("../controllers/otpValidatorController");

const router = express.Router();

router.post("/validate-otp", otpValidatorController.validateOTP);

// router.post("/creator-otp-trigger", otpValidatorController.resendOTP);

router.post("/send-otp", otpValidatorController.sendOTP);

router.post("/resend-otp", otpValidatorController.resendOTP);

module.exports = router;
