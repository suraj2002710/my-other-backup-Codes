const express = require("express");
const multer = require("multer");

const storage = multer.memoryStorage({
  destination: function (req, file, cb) {
    cb(null, "");
  },
});

const upload = multer({ storage: storage });

const orderController = require("../controllers/orderController");
const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.post("/create-order", userVerifyToken, orderController.createOrder);

router.post("/generate-order-amount", userVerifyToken, orderController.generateOrderAmount);

router.get("/order-status/:order_id", userVerifyToken, orderController.getCashfreeOrderStatus);

router.post("/order-history", userVerifyToken, orderController.getOrderHistory);

router.delete("/order-history", userVerifyToken, orderController.deleteOrderHistory);

//reset-password

module.exports = router;
