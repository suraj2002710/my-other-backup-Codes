const express = require("express");

const googleUserController = require("../controllers/googleUserController");
const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

// router.get("/all", googleUserController.getAllGoogleUsers);

router.post(
  "/profile",
  userVerifyToken,
  googleUserController.getGoogleUserProfile
);

router.post("/serach-user-by-email", googleUserController.getGoogleUserByEmail);

router.post("/signup", googleUserController.createGoogleUser);

module.exports = router;
