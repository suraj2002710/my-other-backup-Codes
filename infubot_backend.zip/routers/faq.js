const express = require("express");

const faqController = require("../controllers/faqControllers");

const router = express.Router();

router.get("/", faqController.getAllFAQs);

router.post("/", faqController.postFAQ);

router.get("/:id", faqController.getDetailFAQ);

router.put("/:id", faqController.updateFaq);

// router.delete("/all", faqController.deleteAllFAQ);

module.exports = router;
