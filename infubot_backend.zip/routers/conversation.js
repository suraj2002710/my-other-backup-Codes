const express = require("express");

const conversationController = require("../controllers/conversationControllers");

const router = express.Router();

router.get("/get-user-conversation-list/:user-id", conversationController.getUserConversationList);

router.post("/add-conversation", conversationController.addUserConversation);

router.get("/create-user-conversation", conversationController.createUserConversation);

module.exports = router;