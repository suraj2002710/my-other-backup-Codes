const express = require("express");

const videoController = require("../controllers/videoController");
const { userVerifyToken } = require("../services/userVerifyToken");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.post(
  "/user-request-video-connection",
  userVerifyToken,
  videoController.userRequestToVideoConnectivity
);

// router.post(
//   "/creator-respond-video",
//   // userVerifyToken,
//   videoController.creatorRespondToVideoCall
// );

router.get(
  "/video-logs",
  creatorVerifyToken,
  videoController.creatorVideoLogs
);


// router.delete(
//   "/video-logs",
//   creatorVerifyToken,
//   videoController.deleteAllVideoLogs
// );

module.exports = router;
