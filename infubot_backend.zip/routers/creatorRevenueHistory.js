const express = require("express");

const router = express.Router();

const creatorRevenueHistoryController = require("../controllers/creatorRevenueHistoryController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

router.get("/", creatorVerifyToken, creatorRevenueHistoryController.getCreatorRevenueList);

// router.post("/v2", creatorVerifyToken,creatorRevenueHistoryController.getCreatorRevenueListv2);

// router.post(
//   "/get-user-costing-list",
//   creatorRevenueHistoryController.getUserCostingList
// );

module.exports = router;
