const express = require("express");

const transactionController = require("../controllers/transactionControllers");
const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.get("/", transactionController.getAllTransaction);

router.get("/user-transaction", userVerifyToken, transactionController.getUserTranscation);

// router.post(
//   "/creator-transaction",
//   transactionController.getCreatorTranscation
// );

module.exports = router;
