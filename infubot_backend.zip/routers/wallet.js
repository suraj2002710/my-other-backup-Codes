const express = require("express");

const walletController = require("../controllers/walletController");
const { userVerifyToken } = require("../services/userVerifyToken");

const router = express.Router();

router.get("/", userVerifyToken, walletController.getUserWallet);

// router.post("/update-wallet", userVerifyToken, walletController.updateuserWallet);

// router.post("/update-wallet-gateway", walletController.updateuserWalletGateway);

// router.post("/create-payment-link/stripe", walletController.createStripePaymentLink);

// router.post("/create-payment-link/cashfree", walletController.createCashfreePaymentLink);


module.exports = router;
