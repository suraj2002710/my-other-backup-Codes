const express = require("express");
const fs = require('fs');

const CreatorAIPersonality = require("../controllers/creatorAIPersonalityController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get("/", creatorVerifyToken, CreatorAIPersonality.getCreatorAIPersonality);

// router.post("/", creatorVerifyToken,CreatorAIPersonality.addCreatorAIPersonality);

router.post("/", creatorVerifyToken, CreatorAIPersonality.updateCreatorAIPersonality);

router.delete("/", creatorVerifyToken,CreatorAIPersonality.deleteCreatorAIPersonality);


module.exports = router;
