const express = require("express");

const creatorBillingDetailsController = require("../controllers/creatorBillingDetailsController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get(
  "/",
  creatorVerifyToken,
  creatorBillingDetailsController.getCreatorBillingDetails
);

router.post(
  "/add-billing-details",
  creatorVerifyToken,
  creatorBillingDetailsController.addCreatorBillingDetails
);

router.post(
  "/update-billing-details",
  creatorVerifyToken,
  creatorBillingDetailsController.updateCreatorBillingDetails
);

router.post(
  "/change-billing-details",
  creatorVerifyToken,
  creatorBillingDetailsController.changeCreatorBillingDetails
);


router.delete(
  "/delete-billing-details",
  creatorVerifyToken,
  creatorBillingDetailsController.deleteCreatorBillingDetails
);

module.exports = router;
