const express = require("express");

const creatorBotSettingController = require("../controllers/creatorBotSettingController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

router.get(
  "/",
  creatorVerifyToken,
  creatorBotSettingController.getCreatorBotSettingDetails
);

router.post(
  "/add-bot-setting",
  creatorVerifyToken,
  creatorBotSettingController.addCreatorBotSetting
);

router.post(
  "/update-bot-setting",
  creatorVerifyToken,
  creatorBotSettingController.updateCreatorBotSetting
);

module.exports = router;
