const express = require("express");

const multer = require("multer");
const multerS3 = require('multer-s3');
const aws = require('aws-sdk');
const path = require("path");
const fs = require('fs');

const creatorAIIndexer = require("../controllers/CreatorAIIndexer");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

// console.log("Creds",process.env.AWS_SECRET,process.env.AWS_KEY,process.env.AWS_S3_REGION)

// Configure AWS
// aws.config.update({
//   secretAccessKey: process.env.AWS_SECRET, // replace with your secret access key
//   accessKeyId: process.env.AWS_KEY, // replace with your access key id
//   region: process.env.AWS_S3_REGION // replace with your region
// });

// const s3 = new aws.S3();

// Configure multer-s3 storage
// const storage = multerS3({
//   s3: s3,
//   bucket: 'influbot', // replace with your bucket name
//   acl: 'public-read', // assigns the access control list
//   metadata: function (req, file, cb) {
//     cb(null, {fieldName: file.fieldname});
//   },
//   key: function (req, file, cb) {
//     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // Define the filename
//   }
// });

// File filter for size and extension
// const fileFilter = (req, file, cb) => {
//   if (!file.originalname.match(/\.(pdf)$/)) {
//     req.fileValidationError = 'Only pdf files are allowed!';
//     return cb(new Error('Only pdf files are allowed!'), false);
//   }
//   cb(null, true);
// };

// Set up Multer upload with fileFilter
// const upload = multer({ 
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 5 // Limit of 5MB
//   },
//   fileFilter: fileFilter
// });

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
      const dest = 'public/documents/';
  
      // Check if the directory exists
      fs.access(dest, fs.constants.F_OK, (err) => {
        if (err) {
          // Directory does not exist, so create it
          fs.mkdir(dest, { recursive: true }, (err) => {
            if (err) {
              cb(err);
            } else {
              // Directory created, proceed to use it
              cb(null, dest);
            }
          });
        } else {
          // Directory exists, proceed to use it
          cb(null, dest);
        }
      });
    },
    filename: function(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // Define the filename
    }
  });
  
  
  
  // File filter for size and extension
  const fileFilter = (req, file, cb) => {
    // Accept images only
    if (!file.originalname.match(/\.(pdf)$/)) {
      req.fileValidationError = 'Only pdf files are allowed!';
      return cb(new Error('Only pdf files are allowed!'), false);
    }
    cb(null, true);
  };
  
  
  // Set up Multer upload with fileFilter and size limit
  const upload = multer({ 
    storage: storage,
    limits: {
      fileSize: 1024 * 1024 * 5 // Limit of 5MB
    },
    fileFilter: fileFilter
  });
  


const router = express.Router();

router.post("/index", upload.single('document'), creatorVerifyToken, creatorAIIndexer.indexDocument);

router.get("/all", creatorAIIndexer.getAllCreatorDocuments);

// router.delete("/delete", creatorVerifyToken, creatorAIIndexer.deleteCreatorDocument);

router.get("/index/:document_id/status", creatorVerifyToken, creatorAIIndexer.indexingDocumentStatus);

module.exports = router;
