const express = require("express");
const multer = require('multer');
const path = require('path');
const fs = require('fs')

const creatorKYCController = require("../controllers/creatorKYCController");
const { creatorVerifyToken } = require("../services/creatorVerifyToken");

const router = express.Router();

const creator_kyc_document_storage = multer.diskStorage({
  destination: function(req, file, cb) {
    const dest = 'public/creator/KYC/';

    // Check if the directory exists
    fs.access(dest, fs.constants.F_OK, (err) => {
      if (err) {
        // Directory does not exist, so create it
        fs.mkdir(dest, { recursive: true }, (err) => {
          if (err) {
            cb(err);
          } else {
            // Directory created, proceed to use it
            cb(null, dest);
          }
        });
      } else {
        // Directory exists, proceed to use it
        cb(null, dest);
      }
    });
  },
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // Define the filename
  }
});

// File filter for size and extension
const fileFilter = (req, file, cb) => {
  // Accept images only
  if (!file.originalname.match(/\.(jpg|jpeg|png|pdf)$/)) {
    req.fileValidationError = 'Only image files are allowed!';
    return cb(new Error('Only image files are allowed!'), false);
  }
  cb(null, true);
};


// Set up Multer upload with fileFilter and size limit
const upload = multer({ 
  storage: creator_kyc_document_storage,
  // limits: {
  //   fileSize: 1024 * 1024 * 5 // Limit of 5MB
  // },
  // fileFilter: fileFilter
});


router.get("/", creatorVerifyToken, creatorKYCController.getCreatorKYCDetails);

router.post(
  "/add-kyc-details",
  creatorVerifyToken,
  upload.single('document'),
  creatorKYCController.addCreatorKYCDetails
);

router.post(
  "/update-kyc-details",
  creatorVerifyToken,
  creatorKYCController.updateCreatorKYCDetails
);

router.post(
  "/change-kyc-details",
  creatorVerifyToken,
  upload.single('document'),
  creatorKYCController.changeCreatorKYCDetails
);

router.delete(
  "/delete-kyc-details",
  creatorVerifyToken,
  creatorKYCController.deleteCreatorKYCDetails
);

module.exports = router;
