const express = require("express");
const fs = require('fs');

const CompanyPolicyController = require("../controllers/policyController");


const router = express.Router();

router.get("/start_chat", CompanyPolicyController.getStartChatMessage);

router.get("/privacy_policy", CompanyPolicyController.getPrivacyPolicyApprovalText);

router.get("/privacy_policy_approval_text", CompanyPolicyController.getPrivacyPolicy);

router.post("/update", CompanyPolicyController.updateMessages);

// router.post("/privacy_policy", CompanyPolicyController.changePrivacyPolicyApprovalText);

// router.post("/privacy_policy_approval_text", CompanyPolicyController.changePrivacyPolicy);


module.exports = router;
