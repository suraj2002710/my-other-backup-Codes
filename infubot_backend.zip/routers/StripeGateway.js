const router = require("express").Router();
const stripe = require("stripe")("sk_test_51OWx60SFfc0X56biCuUepJAStPd55GLlNZ3c9es45RRXqlte5tyAhymexgCC6y08KaQ6dzH0n3ipwWGLAcK0YScb00UU15Plef");
const StripePaymentGatewayController = require("../controllers/paymentGatewayController");


router.post("/create-payment-intent", async (req, res) => {
  const { amount, paymentMethodId, paymentMethodType } = req.body;
  try {
      const paymentIntent = await stripe.paymentIntents.create({
          amount,
          currency: "inr",
          automatic_payment_methods: {
              enabled: true,
              allow_redirects: 'never'
          },
          description: 'Wallet Recharge',
          payment_method: paymentMethodId,
          payment_method_types: [paymentMethodType],
          shipping: {
              name: 'Jane Doe',
              address: {
                  line1: '456 Elm Street',
                  line2: 'Suite 5A',
                  city: 'New York',
                  state: 'NY',
                  postal_code: '10001',
                  country: 'US'
              },
          },
          metadata: {
              purpose_code: 'P0104', // Example purpose code, choose one that fits your transaction
          },
          confirm: true,
      });
      res.json({ success: true, clientSecret: paymentIntent.client_secret });
  } catch (error) {
      res.status(500).json({ success: false, message: error.message });
  }
});

router.get("/webhook/payment-success", async(req,res)=>{
  return res.status(200).json({
    statusCode: 200,
    data: null,
    message: "Done",
    error: null,
  })
})
router.post("/webhook/payment-success", async(req,res)=>{
  try {
    console.log("Payment Success",req,body);
  } catch (error) {
    console.error("Error in StripePaymentGateway /payment-success:", error);
    res.status(400).json({
      statusCode: 400,
      data: null,
      message: error.message,
      error: true,
    });
  }
})

router.get("/webhook/payment-failed", async(req,res)=>{
  return res.status(200).json({
    statusCode: 200,
    data: null,
    message: "Done",
    error: null,
  })
})
router.post("/webhook/payment-failed", async(req,res)=>{
  try {
    console.log("Payment Failed",req.body);
  } catch (error) {
    console.error("Error in StripePaymentGateway /payment-failed:", error);
    res.status(400).json({
      statusCode: 400,
      data: null,
      message: error.message,
      error: true,
    });
  }
})

module.exports = router;
