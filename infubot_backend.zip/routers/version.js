const express = require("express");

const versionController = require("../controllers/versionController");

const router = express.Router();

router.get("/get-version-details", versionController.getVersionDetails);

router.get("/get-latest-version", versionController.getLatestVersion);

router.post("/add-version", versionController.addVersion);

module.exports = router;
