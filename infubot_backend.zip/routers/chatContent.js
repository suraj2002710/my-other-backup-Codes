const express = require("express");
const chatHistoryController = require("../controllers/chatContentController");
const multerS3 = require('multer-s3');
const { S3Client } = require('@aws-sdk/client-s3');
const { v4: uuidv4 } = require('uuid');
const { creatorVerifyToken } = require("../services/creatorVerifyToken");
const multer = require('multer');
// const io_redis = require('ioredis');
// const {config} = require("../queue_infra/redis_config");
// const redis_client = new io_redis(config);

const router = express.Router();

const s3 = new S3Client({
    region: "ap-south-1",
    credentials: {
        accessKeyId: process.env.AWS_KEY,
        secretAccessKey: process.env.AWS_SECRET
    }
});
  
const aws_upload_voice_message = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'influbot',
        contentType: multerS3.AUTO_CONTENT_TYPE,
        metadata: function (req, file, cb) {
            cb(null, {
                originalName: file.originalname,
            });
        },
        key: function (req, file, cb) {
            const fileExtension = file.originalname.split('.').pop();
            const folderStructure = `uploads/${req.creator.id}/voice_messages/`;
            const uniqueFileName = `${uuidv4()}.${fileExtension}`;
            const fullKey = `${folderStructure}${uniqueFileName}`;
            const metadata = {
                originalName: file.originalname,
            };
            // redis_client.set(`chat_content:${fullKey}:voice_messages:metadata`, JSON.stringify(metadata));
            console.log(`File uploaded to folder: ${fullKey}`);
            cb(null, fullKey);
        }
    })
});


const aws_upload_chat_creator_image = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'influbot',
        contentType: multerS3.AUTO_CONTENT_TYPE,
        metadata: function (req, file, cb) {
            cb(null, {
                originalName: file.originalname,
            });
        },
        key: function (req, file, cb) {
            const fileExtension = file.originalname.split('.').pop();
            // Example: Organizing uploads by year/month/day
            const folderStructure = `uploads/${req.creator.id}/image/`;

            const uniqueFileName = `${uuidv4()}.${fileExtension}`;
            // Prefix the unique file name with the folder structure
            const fullKey = `${folderStructure}${uniqueFileName}`;

            // Store original file name and potentially other metadata in Redis
            const metadata = {
                originalName: file.originalname,
                // Add other metadata here as needed
            };
            // Storing JSON stringified metadata in Redis for easy retrieval
            // redis_client.set(`chat_content:${fullKey}:image:metadata`, JSON.stringify(metadata));
            // console.log(`File uploaded to folder: ${fullKey}`);
            cb(null, fullKey);
        }
    })
});


const aws_upload_chat_creator_videos = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'influbot',
        contentType: multerS3.AUTO_CONTENT_TYPE,
        metadata: function (req, file, cb) {
            cb(null, {
                originalName: file.originalname, // Store original name as metadata in S3
                // You can add more metadata here as needed
            });
        },
        key: function (req, file, cb) {
            const fileExtension = file.originalname.split('.').pop();
            // Example: Organizing uploads by year/month/day
            const folderStructure = `uploads/${req.creator.id}/video/`;

            const uniqueFileName = `${uuidv4()}.${fileExtension}`;
            // Prefix the unique file name with the folder structure
            const fullKey = `${folderStructure}${uniqueFileName}`;

            // Store original file name and potentially other metadata in Redis
            const metadata = {
                originalName: file.originalname,
                // Add other metadata here as needed
            };
            // Storing JSON stringified metadata in Redis for easy retrieval
            // redis_client.set(`chat_content:${fullKey}:video:metadata`, JSON.stringify(metadata));
            // console.log(`File uploaded to folder: ${fullKey}`);
            cb(null, fullKey);
        }
    })
});


  
router.post(
    "/upload-voice-message",
    creatorVerifyToken,
    aws_upload_voice_message.single('voice_message'),
    chatHistoryController.uploadVoiceMessage
);

router.post(
    "/upload-chat-image",
    creatorVerifyToken,
    aws_upload_chat_creator_image.single('chat_image'),
    chatHistoryController.uploadChatImage
);

router.post(
    "/upload-chat-video",
    creatorVerifyToken,
    aws_upload_chat_creator_videos.single('chat_video'),
    chatHistoryController.uploadChatVideo
);


router.post(
    "/generate-presigned-url-creator",
    creatorVerifyToken,
    chatHistoryController.generatePresignedUrlForImage
)

// Additional routes can be uncommented or added here

module.exports = router;
