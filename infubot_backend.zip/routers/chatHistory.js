const express = require("express");

const chatHistoryController = require("../controllers/chatHistoryController");

const router = express.Router();
let {creatorVerifyToken}=require("../services/creatorVerifyToken")

router.post(
  "/get-chat-history-for-creator",
  creatorVerifyToken,
  chatHistoryController.getChatHistoryListForCreator
);

router.post(
  "/get-chat-of-user-by-id-for-creator",
  // creatorVerifyToken,
  chatHistoryController.getChatOfUserByIdForCreator
);

// router.post(
//   "/get-chat-of-user-by-id-for-creator-v2",
//   chatHistoryController.getChatOfUserByIdForCreatorWithRedis
// );


// router.delete(
//   "/delete-chat-of-user-by-id-for-creator",
//   chatHistoryController.deleteUserEntireChatHistory
// );

module.exports = router;
