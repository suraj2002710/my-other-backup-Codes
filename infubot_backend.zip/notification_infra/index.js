const { send_notification_to_creator_for_audio_call_message_formatter, send_notification_to_creator_for_video_call_message_formatter, send_notification_to_creator_for_message_message_formatter, send_notification_to_creator_for_ai_message_message_formatter } = require("./message_formatter/firebase");
const { firebase_notify } = require("./notify/firebase");
const { pushy_notify } = require("./notify/pushy")
const { storeCallNotification } = require("../services/notificationStore");
const { send_notification_to_creator_for_audio_call_message_formatter_pushy, send_notification_to_creator_for_video_call_message_formatter_pushy, send_notification_to_creator_for_call_cancellation } = require("./message_formatter/pushy");
const { random_user_profile } = require("../utilities/random_profile_images");


module.exports.send_notification_to_creator_for_audio_call = async (creator_details, user_details, connectivity_details) => {
    try {
        console.log('Payload', creator_details, user_details, connectivity_details)
        if (process.env.AUDIO_CALL_NOTIFICATION_SYSTEM == "firebase") {
            const formatted_notification_payload = await send_notification_to_creator_for_audio_call_message_formatter(
                creator_details, user_details, connectivity_details
            );
            console.log("formatted_notification_payload", formatted_notification_payload);
            const notify = await firebase_notify(formatted_notification_payload);
            console.log("---Inside send_notification_to_creator_for_audio_call", notify)
            if (notify) {
                storeCallNotification(
                    creator_details?.email,
                    user_details.id,
                    creator_details?.id,
                    formatted_notification_payload?.data?.type,
                    formatted_notification_payload?.data?.username,
                    formatted_notification_payload?.data?.audio_id
                );
                return true
            } else {
                return false
            }
        } else if (process.env.AUDIO_CALL_NOTIFICATION_SYSTEM == "pushy") {
            console.log("Audio Call Pushy")
            const formatted_notification_payload = await send_notification_to_creator_for_audio_call_message_formatter_pushy(
                creator_details, user_details, connectivity_details
            );
            console.log("formatted_notification_payload", formatted_notification_payload);
            const notify = await pushy_notify(formatted_notification_payload);
            console.log("---Inside send_notification_to_creator_for_audio_call", notify)
            if (notify) {
                storeCallNotification(
                    creator_details?.email,
                    user_details.id,
                    creator_details?.id,
                    formatted_notification_payload?.data?.type,
                    formatted_notification_payload?.data?.username,
                    formatted_notification_payload?.data?.audio_id
                );
                return true
            } else {
                return false
            }
        }
    } catch (error) {
        console.log("Error in send_notification_to_creator_for_audio_call", error)
    }
}


module.exports.send_notification_to_creator_for_video_call = async (creator_details, user_details, connectivity_details) => {
    // console.log("---->send_notification_to_creator_for_video_call", creator_details, user_details, connectivity_details)
    try {
        if (process.env.VIDEO_CALL_NOTIFICATION_SYSTEM == "firebase") {
            const formatted_notification_payload = await send_notification_to_creator_for_video_call_message_formatter(
                creator_details, user_details, connectivity_details
            );
            console.log("formatted_notification_payload", formatted_notification_payload);
            const notify = await firebase_notify(formatted_notification_payload);
            console.log("---Inside send_notification_to_creator_for_video_call", notify)
            if (notify) {
                storeCallNotification(
                    creator_details.email,
                    user_details.id,
                    creator_details.id,
                    formatted_notification_payload?.data?.type,
                    formatted_notification_payload?.data?.username,
                    formatted_notification_payload?.data?.video_id
                );
                return true
            } else {
                return false
            }
        } else if (process.env.VIDEO_CALL_NOTIFICATION_SYSTEM == "pushy") {
            const formatted_notification_payload = await send_notification_to_creator_for_video_call_message_formatter_pushy(
                creator_details, user_details, connectivity_details
            );
            // console.log("formatted_notification_payload", formatted_notification_payload);
            const notify = await pushy_notify(formatted_notification_payload);
            // console.log("---Inside send_notification_to_creator_for_video_call", notify)
            if (notify) {
                storeCallNotification(
                    creator_details.email,
                    user_details._id,
                    creator_details._id,
                    formatted_notification_payload?.data?.type,
                    formatted_notification_payload?.data?.username,
                    formatted_notification_payload?.data?.video_id
                );
                return true
            } else {
                return false
            }
        }
    } catch (error) {
        console.log("Error in send_notification_to_creator_for_video_call", error)
    }
}

module.exports.send_notification_to_creator_for_message = async (user_details, creator_details, conversation_details) => {
    try {
        // const formatted_notification_payload = await send_notification_to_creator_for_message_message_formatter(
        //     user_details, creator_details, conversation_details
        // );
      let notifyData=  {
            notification: {
              title: `${user_details.first_name} ${user_details.last_name}`,
              body:  conversation_details.text,
            },
            token: creator_details.fcm_token,
            data:{
                type: "chat",
                user_conversation_id:conversation_details.conversation_id.toString(),
                message_text: conversation_details.text.toString(),
                recipient: "creator",
                user_email: user_details.email.toString(),
                creator_email: creator_details.email.toString(),
                user_id: user_details.id.toString(),
                creator_id: creator_details.id.toString(),
                user_name: `${user_details.first_name} ${user_details.last_name}`,
                creator_name: `${creator_details.first_name} ${creator_details.last_name}`,
                message_from: "user",
                createdAt:`${new Date(conversation_details.createdAt).toISOString() }`,
                updatedAt: `${new Date(conversation_details.updatedAt).toISOString()}`,
                user_profile_image: random_user_profile(),
            },
          }  
        console.log("formatted_notification_payload", notifyData);
        const notify = await firebase_notify(notifyData);
        console.log("---Inside send_notification_to_creator_for_message", notify)
        if (notify) {
            return true
        } else {
            return false
        }
    } catch (error) {
        console.log("Error in send_notification_to_creator_for_message", error)
    }
}


module.exports.send_notification_to_creator_for_ai_message = async (user_details, creator_details, conversation_details) => {
    try {
        const formatted_notification_payload = await send_notification_to_creator_for_ai_message_message_formatter(
            user_details, creator_details, conversation_details
        );
        console.log("formatted_notification_payload", formatted_notification_payload);
        const notify = await firebase_notify(formatted_notification_payload);
        console.log("---Inside send_notification_to_creator_for_ai_message_message_formatter", notify)
        if (notify) {
            return true
        } else {
            return false
        }
    } catch (error) {
        console.log("Error in send_notification_to_creator_for_ai_message_message_formatter", error)
    }
}


module.exports.send_notification_to_creator_for_call_declined_by_user = async (creator_details, conversation_details, type) => {
    try {
        const formatted_notification_payload = await send_notification_to_creator_for_call_cancellation(
            creator_details, conversation_details, type
        );
        console.log("formatted_notification_payload", formatted_notification_payload);
        const notify = await pushy_notify(formatted_notification_payload);
        console.log("---Inside send_notification_to_creator_for_ai_message_message_formatter", notify)
        if (notify) {
            return true
        } else {
            return false
        }
    } catch (error) {
        console.log("Error in send_notification_to_creator_for_ai_message_message_formatter", error)
    }
}