const { generateAgoraToken } = require("../../../services/generateAgoraToken");
const { random_user_profile } = require("../../../utilities/random_profile_images");
module.exports.send_notification_to_creator_for_audio_call_message_formatter_pushy =
  async (creator_details, user_details, connectivity_details) => {
    try {
      const token = await generateAgoraToken(connectivity_details.channel_room);  
      return {
        data: {
          "type": "voice_call",
          "appId": process.env.AGORA_APP_ID,
          "voice_token": token,
          "channel_room": connectivity_details.channel_room,
          "user_id": user_details.id,
          "audio_id": connectivity_details.audio_id,
          "username": `${user_details.first_name} ${user_details.last_name}`,
          "user_profile_image": random_user_profile(),
        },
        "to": creator_details.pushy_device_id,
        "options": {
          time_to_live: 15,
          priority:"high",
          ttl:0,
        },
      };
    } catch (error) {
      console.log(
        "Error in send_notification_to_creator_for_audio_call_message_formatter",
        error
      );
    }
  };


  module.exports.send_notification_to_creator_for_video_call_message_formatter_pushy =
  async (creator_details,user_details,connectivity_details) => {
    try {
      const token = await generateAgoraToken(connectivity_details.channel_room);
      return {
        data: {
          type: "video_call",
          appId: process.env.AGORA_APP_ID,
          video_token: token,
          channel_room: connectivity_details.channel_room,
          user_id: user_details._id,
          video_id: connectivity_details.video_id,
          username: `${user_details.first_name} ${user_details.last_name}`,
          user_wallet: connectivity_details.user_wallet.toString(),
          "user_profile_image": random_user_profile(),
        },
        to: creator_details.pushy_device_id,
        options: {
          time_to_live: 15,
          priority:"high",
          ttl:0,
        },
      };
    } catch (error) {
      console.log(
        "Error in send_notification_to_creator_for_audio_call_message_formatter",
        error
      );
    }
  };


  module.exports.send_notification_to_creator_for_call_cancellation =
  async (creator_details,connectivity_details,type) => {
    try {
      return {
        data: {
          id : connectivity_details.id,
          type: "call_declined_by_user",
          call_type : type,
        },
        to: creator_details.pushy_device_id,
        options: {
          time_to_live: 5,
          priority:"high",
          ttl:0,
        },
      };
    } catch (error) {
      console.log(
        "Error in send_notification_to_creator_for_audio_call_message_formatter",
        error
      );
    }
  };