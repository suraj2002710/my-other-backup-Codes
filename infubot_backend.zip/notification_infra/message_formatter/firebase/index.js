require('dotenv').config()
const { generateAgoraToken } = require("../../../services/generateAgoraToken");
const { random_user_profile } = require("../../../utilities/random_profile_images");
module.exports.send_notification_to_creator_for_audio_call_message_formatter = async(creator_details,user_details,connectivity_details) => {
    try {
      const token = await generateAgoraToken(connectivity_details.channel_room)
      return {
        token: creator_details?.fcm_token,
        data: {
          type: "voice_call",
          appId: process.env.AGORA_APP_ID,
          voice_token: token,
          channel_room: connectivity_details.channel_room,
          user_id: user_details.id,
          audio_id: connectivity_details.audio_id,
          username: `${user_details.first_name} ${user_details.last_name}`,
        },
      }  
    } catch (error) {
     console.log("Error in send_notification_to_creator_for_audio_call_message_formatter", error)
    }
}


module.exports.send_notification_to_creator_for_video_call_message_formatter = async(creator_details,user_details,connectivity_details) => {
    try {
      const token = await generateAgoraToken(connectivity_details.channel_room)
      return {
        token: creator_details?.fcm_token,
        data: {
          type: "video_call",
          appId: process.env.AGORA_APP_ID,
          video_token: token,
          channel_room: connectivity_details.channel_room,
          user_id: user_details.id,
          video_id: connectivity_details.video_id,
          username: `${user_details.first_name} ${user_details.last_name}`,
          "user_profile_image": random_user_profile(),
        },
      };  
    } catch (error) {
     console.log("Error in send_notification_to_creator_for_video_call_message_formatter", error)
    }
}


module.exports.send_notification_to_creator_for_ai_message_message_formatter = async(user_details,creator_details,conversation_details) => {
    try {
      return {
        notification: {
          title: `AI Live!`,
          body: "Your AI is now interacting with users.",
        },
        token: creator_details.fcm_token,
        data: {
          type: "ai_mode_chat",
          creatorId: creator_details.id.toString(),
          creatorName: `${creator_details.first_name} ${creator_details.last_name}`,
          userId: user_details.id.toString(),
          userName: `${user_details.first_name} ${user_details.last_name}`,
          conversationId: conversation_details.conversation_id,
          "user_profile_image": random_user_profile(),
        },
      }  
    } catch (error) {
     console.log("Error in send_notification_to_creator_for_audio_call", error)
    }
}


module.exports.send_notification_to_creator_for_message_message_formatter = async(user_details,creator_details,conversation_details) => {
    try {
      console.log("---Pay",user_details,creator_details,conversation_details)
      return {
        notification: {
          title: `${user_details.first_name} ${user_details.last_name}`,
          body: conversation_details.text,
        },
        token: creator_details.fcm_token,
        data: {
          type: "chat",
          creatorId: creator_details.id,
          creatorName: `${creator_details.first_name} ${creator_details.last_name}`,
          userId: user_details.id,
          userName: `${user_details.first_name} ${user_details.last_name}`,
          conversationId: conversation_details.conversation_id,
        },
      }
    } catch (error) {
     console.log("Error in send_notification_to_creator_for_audio_call", error)
    }
}