const admin = require("firebase-admin");

module.exports.firebase_notify = async (message_payload) => {
    try {
        console.log("--->", message_payload);
        const response = await admin.messaging().send(message_payload);
        console.log("---firebase_notify response", response);
        return true;
    } catch (error) {
        console.log("---firebase_notify error", error);
        return false;
    }
};
