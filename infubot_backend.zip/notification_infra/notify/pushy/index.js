const Pushy = require('pushy');
const pushy = new Pushy('f5c1d94240392edb88ca25efbe96ca346381701834e77cee0a2a99ff0fd41209');
const colors = require('colors');

module.exports.pushy_notify = async (message_payload) => {
    try {
        // console.log("--->", message_payload);
        let {data,to,options} = message_payload
        // console.log("Pushy Data".green,data);
        // console.log("Pushy To".red, to);
        // console.log("Pushy Options",options)
        return new Promise((resolve, reject) => {
            pushy.sendPushNotification(data, to, options, function (err, result) {
                if (err) {
                    console.error(false);
                    reject(err);
                } else {
                    console.log('Push sent successfully! (ID: ' + result.id + ')');
                    resolve(true);
                }
            });
        });
    } catch (error) {
        console.log("---pushy_notify error", error);
        return false;
    }
};