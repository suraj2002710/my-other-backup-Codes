const axios = require("axios");
const subscriptionKey = process.env.SubscriptionKey;

module.exports.congnitiveLanguageService = async (query) => {
  try {
    const projectName = process.env.ProjectName;
    const deploymentName = process.env.DeploymentName;
    const endpoint = process.env.Endpoint;
    const api_version = process.env.ApiVersion;

    const url = `${endpoint}/language/:analyze-conversations?api-version=${api_version}`;

    const body = {
      kind: "Conversation",
      analysisInput: {
        conversationItem: {
          id: "1",
          participantId: "1",
          text: query,
        },
      },
      parameters: {
        projectName: projectName,
        deploymentName: deploymentName,
        stringIndexType: "TextElement_V8",
      },
    };

    const headers = {
      headers: {
        "Ocp-Apim-Subscription-Key": subscriptionKey,
      },
    };

    res = await axios.post(url, body, headers);

    return res.data;
  } catch (error) {
    return null;
  }
};
