module.exports.payment_gateway_configuration = {
    test : {
        phonepe: {
            postUrl: "http://localhost:8080/gateways/phonepe-post",
            redirectMode: "POST",
            redirectUrl: "http://localhost:8080/gateways/phonepe-result/",
    
            phonePePayUrl: "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay",
            saltKey: "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399",
            saltIndex: 1,
            merchantId: "MERCHANTUAT",
            callbackUrl: "http://localhost:8080/gateways/phonepe-result/"
          },
    }
}