require("dotenv").config();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const logger = require("winston");

const checkIfCustomerExist = async (email) => {
  try {
    // Search for existing customers with the provided email
    const customers = await stripe.customers.list({
      email: email,
      limit: 1,
    });

    // If a customer exists, return the existing customer
    if (customers.data.length > 0) {
      return {
        status: true,
        data: customers.data[0],
      };
    } else {
      return {
        status: false,
        data: null,
      };
    }
  } catch (error) {
    console.error("Error in checkIfCustomerExist:", error);
    throw error;
  }
};

const createCustomer = async (user_details) => {
  const checkIfAlreadyExist = await checkIfCustomerExist(user_details?.email);
  console.log("--->>", checkIfAlreadyExist);
  if (checkIfAlreadyExist.status == true) {
    return {
      status: true,
      data: checkIfAlreadyExist,
    };
  } else {
    return await stripe.customers.create({
      email: user_details?.email,
      name: user_details?.name,
      address: {
        line1: "A-1, Shanti Path, Tilak Nagar",
        city: "Jaipur",
        state: "Rajasthan",
        country: "IN",
        postal_code: "302004",
      },
    });
  }
};

const generateStripePaymentLink = async (order_details, user_details) => {
  try {

    const price = await stripe.prices.create({
      currency: 'inr',
      unit_amount: order_details?.gross_amount,
      product_data: {
        name: 'Wallet Recharge',
      },
    });



    const paymentLink = await stripe.paymentLinks.create({
      line_items: [
        {
          price: price.id,
          quantity: 1,
        },
      ],
    });


    return paymentLink?.url;
  } catch (error) {
    console.error("Error in Stripe session setup:", error);
  }
};

module.exports = {
  checkIfCustomerExist,
  createCustomer,
  generateStripePaymentLink,
};
