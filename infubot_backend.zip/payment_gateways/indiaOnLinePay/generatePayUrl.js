const { User } = require("../../models/Users");const { BaseRates } = require("../../models/BaseRate");
const { Transaction } = require("../../models/Transaction");
const { v4: uuidv4 } = require("uuid");
const { createHash } = require("crypto");
const axios = require("axios");
const dotenv = require("dotenv");
dotenv.config();
const moment = require("moment-timezone");

function generateInvoiceNumber() {
   const randomNumber = Math.floor(Math.random() * 900000) + 100000;
   const randomString = randomNumber.toString();
   const invoiceNumber = "INV" + randomString.padStart(6, "0");
   return invoiceNumber;
}


module.exports.generatePayUrlForIndiaOnly = async (req, res) => {
   try {
      if (req.user && req.user.id && req.body.amount) {
         console.log("api called....");
         let user = await User.findById(req.user.id);
         if (user) {
            let getBaseRate = await BaseRates.findOne({});
            let finalAmount = (req.body.amount * getBaseRate.gst) / 100 + req.body.amount + req.body.amount * (getBaseRate.platform_fee / 100);
            let transactionId = generateInvoiceNumber();
            let data = JSON.stringify({
               mId: "2sBtimafvm4=RkZGRklVMklYNU9NS00yRA==",
               sType: "wq6gW2Yysqc=Mg==",
               pId: "4",
               amount: finalAmount,
               invno: transactionId,
               fName: user.first_name,
               lName: user.last_name,
               mNo: "9876543210",
               email: user.email,
               add1: "celebgaze media jaipur",
               city: "Jaipur",
               state: "Rajasthan",
               pCode: "303035",
               currency: "INR",
               country: "India",
               uType: "INTENT",
            });

            let config = {
               method: "post",
               maxBodyLength: Infinity,
               url: "https://indiaonlinepay.com/api/iopregisterupiintent",
               headers: {
                  "Content-Type": "application/json",
                  opStatus: "1",
                  Cookie: "Path=/",
               },
               data: data,
            };

            try {
               let getIntentUrl = await axios.request(config);
               if (getIntentUrl) {
                  let parsedData = getIntentUrl;
                  console.log(parsedData.data.orderId);   
                  if (parsedData.data.status === "SUCCESS") {
                     const paymentDate = moment().tz("Asia/Kolkata").toDate();
                     let transactionRecord = await Transaction.create({
                        user_id: user._id,
                        user_email: user.email,
                        creator_id: null,
                        creator_email: null,
                        type: "Wallet Recharge",
                        amount: Math.round(req.body.amount),
                        total_amount: finalAmount,
                        gst: Math.round((req.body.amount * getBaseRate.gst) / 100),
                        platform_fee: req.body.amount * (getBaseRate.platform_fee / 100),
                        transaction_id: parsedData.data.orderId,
                        payment_received_from: "India-Online-Pay",
                        payment_date: paymentDate,
                        status: "pending",
                     });
                     if (transactionRecord) {
                        return res.status(200).json({ message: "success", data: parsedData.data.intent });
                     }
                  }
               }
            } catch (error) {
               return res.status(400).json({ statusCode: 200, message: "try after sometime.", error: error.message });
            }

            return res.status(500).json({ message: "failed to create encryption" });
         }
         return res.status(400).json({ message: "user not found" });
      }
      return res.status(500).json({ message: "invalid request data" });
   } catch (error) {
      console.error(`-------------generatePayUrl API response error------------:- ${error}`);
      return res.status(500).json({ message: error.message });
   }
};
