let {generatePayUrlForIndiaOnly}=require('./generatePayUrl')
let {successHandlerForIndiaOnlinePay}=require('./successHandler')
module.exports = {
    generatePayUrlForIndiaOnly,
    successHandlerForIndiaOnlinePay
}