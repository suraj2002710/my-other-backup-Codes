require("dotenv").config();
const axios = require("axios");
const logger = require("winston");

const BASE_URL = "https://sandbox.cashfree.com/pg";
const CLIENT_ID = "TEST10107934bffa4df87653783fabc143970101";
const CLIENT_SECRET = "cfsk_ma_test_3b37891f4d2435dadd043edb8838b618_113e0d55";

const CASHFREE_API_HANDLER = "CASHFREE_API_HANDLER";

const generatePaymentLink = async (order_details, user_details) => {
  try {
    console.log(order_details, user_details);
    const data = {
      customer_details: {
        customer_email: user_details.email,
        customer_phone: "9957588243",
      },
      link_amount: parseInt(order_details.gross_amount),
      link_currency: "INR",
      link_expiry_time: "2024-02-39T15:04:05+05:30",
      link_id: order_details.order_id,
      link_meta: {
        notify_url: "https://ee08e626ecd88c61c85f5c69c0418cb5.m.pipedream.net",
        return_url:
          `${process.env.REACT_CHECKOUT_PAGE_REDIRECT_URL}?order_id=${order_details.order_id}`,
        upi_intent: false,
      },
      link_notify: {
        send_email: true,
        send_sms: false,
      },
      link_purpose: "Wallet Recharge",
    };

    let config = {
      method: "post",
      data: data,
      maxBodyLength: Infinity,
      url: `${BASE_URL}/links`,
      headers: {
        "Content-Type": "application/json",
        "x-client-id": CLIENT_ID,
        "x-client-secret": CLIENT_SECRET,
        "x-api-version": "2021-05-21",
      },
    };

    const response = await axios(config);
    //   console.log("Response", response)
    if (response.data) {
      console.log("Response", JSON.stringify(response.data));
      logger.info(
        `[${CASHFREE_API_HANDLER}] generatePaymentLink API response success`
      );
      return response.data.link_url;
    }
  } catch (error) {
    console.log("Error", error);
    logger.error(
      `[${CASHFREE_API_HANDLER} generatePaymentLink API response error:- ${error.message}`
    );
  }
};

const getOrderStatus = async (order_id) => {
  try {
    console.log(order_id);

    let config = {
      method: "get",
      maxBodyLength: Infinity,
      url: `${BASE_URL}/orders/${order_id}`,
      headers: {
        "Content-Type": "application/json",
        "x-client-id": CLIENT_ID,
        "x-client-secret": CLIENT_SECRET,
        "x-api-version": "2021-05-21",
      },
    };

    const response = await axios(config);
    //   console.log("Response", response)
    if (response.data) {
      console.log("Response", JSON.stringify(response.data));
      logger.info(
        `[${CASHFREE_API_HANDLER}] generatePaymentLink API response success`
      );
      return response.data;
    }
  } catch (error) {
    console.log("Error", error);
    logger.error(
      `[${CASHFREE_API_HANDLER} generatePaymentLink API response error:- ${error.message}`
    );
  }
};

module.exports = {
  generatePaymentLink,
  getOrderStatus
};
