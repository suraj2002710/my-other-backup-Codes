const router = require("express").Router();
const { Orders } = require("../../models/Orders");
const { User } = require("../../models/Users");

const { generatePaymentLink } = require("../../payment_gateways/cashfree");

router.get("/", async (req, res) => {
  const { gross_amount, creator_username } = req.query;
  const fetch_user_details = await User.findById("65b72f1ad3ca71041357f952");

  if (fetch_user_details) {
    console.log("Cookies", req.cookies);
    if (!req.cookies.user_id) {
      console.log("Setting Cookie");
      // Set a cookie with the user_id, expires in 24 hours
      res.cookie("user_id", fetch_user_details.id, { maxAge: 86400000, httpOnly: false});
      console.log("Cookies", req.cookies)
    } else {
      console.log("Cookie Exists");
    }

    return res.render('orders', {
      gross_amount: gross_amount,
      user_id: fetch_user_details.id,
      creator_username: creator_username,
      fullname: fetch_user_details.first_name,
      email: fetch_user_details.email,
      submit_url: "https://1dba-2405-201-5c09-5ac5-dc6a-1d87-5c68-357d.ngrok-free.app/cookie/handler"
    });
  }
});

router.post("/handler", async (req, res) => {
  console.log("---", req.cookies)


  // if (userId) {
  //   const fetch_user_details = await User.findById(userId);
  //   if (fetch_user_details) {
  //     const new_order = {
  //       gross_amount: req.body.gross_amount,
  //       creator_username: req.body.creator_username,
  //       order_id: "abcd123444", // This should be uniquely generated for each order
  //       user_id: fetch_user_details.id,
  //       payment_gateway: "cashfree"
  //     };

  //     const payment_link = await generatePaymentLink(new_order, fetch_user_details);
  //     return res.redirect(payment_link);
  //   } else {
  //     return res.status(404).send("User not found.");
  //   }
  // } else {
  //   return res.status(403).json({
  //     message: "Unauthorized access"
  //   });
  // }
});

module.exports = router;
