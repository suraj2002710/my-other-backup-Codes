const crypto = require("crypto");const { User } = require("../../models/Users");
const { BaseRates } = require("../../models/BaseRate");
const { Transaction } = require("../../models/Transaction");
let axios = require("axios");
const moment = require('moment-timezone');

function generateMerchantTransactionId() {
   const currentDate = new Date();
   const year = currentDate.getFullYear().toString().substr(2);
   const month = String(currentDate.getMonth() + 1).padStart(2, "0");
   const day = String(currentDate.getDate()).padStart(2, "0");
   const timestamp = currentDate.getTime().toString().substr(-5);
   const randomNum = Math.floor(Math.random() * 90000) + 10000;
   return `MT${year}${month}${day}${timestamp}${randomNum}`;
}

function generateMerchantUserId() {
   const randomNum = Math.floor(Math.random() * 900) + 100;
   return `MUID${randomNum}`;
}

let createHash = (amount, redirectUrl) => {
   const payload = {
      merchantId: "M22XYTJITZB4H",
      merchantTransactionId: generateMerchantTransactionId(),
      merchantUserId: generateMerchantUserId(),
      amount: parseInt(amount) * 100,
      redirectUrl: redirectUrl,
      redirectMode: "REDIRECT",
      callbackUrl: "https://backend.influbot.ai/api/payment-gateway/phone-pay/web-hook",
      mobileNumber: "9876543210",
      paymentInstrument: {
         type: "PAY_PAGE",
      },
   };

   const encodedPayload = Buffer.from(JSON.stringify(payload)).toString("base64");
   const saltKey = "1e0343fa-8bfe-4edd-b079-389a1408bcb1";
   const saltIndex = 1;
   const concatenatedString = `${encodedPayload}/pg/v1/pay${saltKey}`;
   // Calculate SHA256 hash
   const hash = crypto.createHash("sha256").update(concatenatedString).digest("hex");
   // Append "###" followed by the salt index
   const xVerifyHeader = `${hash}###${saltIndex}`;

   return {
      xVerifyHeader,
      encodedPayload,
      transactionId: payload.merchantTransactionId,
   };
};

module.exports.pgPayUrl = async (req, res) => {
   try {
      let user = await User.findById(req.user.id);
      if (user) {
        const paymentDate = moment().tz('Asia/Kolkata').toDate();
         let getBaseRate = await BaseRates.findOne({});
         let finalAmount = (req.body.amount * getBaseRate.gst) / 100 + req.body.amount + req.body.amount * (getBaseRate.platform_fee / 100);
         let isHashCreated = createHash(finalAmount, req.body.redirectUrl);
         let apiData = {
            apiUrl: "https://api.phonepe.com/apis/hermes/pg/v1/pay",
            headers: {
               "Content-Type": "application/json",
               "X-Verify": isHashCreated.xVerifyHeader,
            },
            body: {
               request: isHashCreated.encodedPayload,
            },
         };

         try {
            let isURLGenerated = await axios.post(apiData.apiUrl, apiData.body, { headers: apiData.headers });
            if (isURLGenerated) {
                let transactionRecord = await Transaction.create({
                    user_id: user._id,
                    user_email: user.email,
                    creator_id: null,
                    creator_email: null,
                    type: "Wallet Recharge",
                    amount: Math.round(req.body.amount),
                    total_amount: finalAmount,
                    gst: Math.round((req.body.amount * getBaseRate.gst) / 100),
                    platform_fee: req.body.amount * (getBaseRate.platform_fee / 100),
                    transaction_id:isHashCreated.transactionId,
                    payment_received_from: "Phone-Pay",
                    payment_date:paymentDate,
                    status: "pending",
                 });
                 if(transactionRecord){
                    return res.status(200).json({
                        statusCode: 200,
                        message: "success",
                        data: isURLGenerated.data.data.instrumentResponse.redirectInfo.url,
                     });
                 }
            
            }
           
         } catch (error) {
            console.log(error.message);

            return res.status(400).json({ statusCode: 400, message: error.message });
         }
      }
      return res.status(400).json({ statusCode: 400, message: "user not found." });
   } catch (error) {
      console.log(error);
      return res.status(400).json({ statusCode: 400, message: error.message });
   }
};
