let {pgPayUrl}=require('./pgPayUrl')
let {successHandler}=require('./successHandler')
module.exports = {
    pgPayUrl,
    pgSuccessHandler:successHandler
}