
const { User } = require("../../models/Users");
const { Wallet } = require("../../models/Wallet");
const { Transaction } =require("../../models/Transaction");
const {getIoInstance} =require('../../socket_chat_infra/index');

module.exports.successHandler = async(req,res)=>{
  try{
    console.log("................success handler called from phone pay/.........................");

    const decodedResponse = Buffer.from(req.body.response, 'base64').toString('utf-8');
    const responseObject = JSON.parse(decodedResponse);
 
    if(responseObject.success==true&& responseObject.code ==="PAYMENT_SUCCESS"){
        console.log(responseObject)
         if(responseObject.data.state==="COMPLETED"){
            console.log("Payment successful");

            let updateTransaction = await Transaction.findOneAndUpdate(
                { transaction_id: responseObject.data.merchantTransactionId, status: "pending" },
                {
                   status: "success",
                },
                { new: true },
             );
         
             if(updateTransaction){
                let isWalletUpdated = await Wallet.findOneAndUpdate({ user_email: updateTransaction.user_email }, { $inc: { wallet_balance: Math.round(updateTransaction.amount) } }, { new: true });
                if (isWalletUpdated) {
                    const io = getIoInstance();
                    if (!io) {
                       console.error("Socket.IO instance is not initialized.");
                    }
     
                    io.to(`${isWalletUpdated.user_id}`).emit("fetched_user_wallet_balance", {
                       message: "User Balance Fetched Successfully",
                       wallet_balance: isWalletUpdated.wallet_balance,
                    });
     
                    console.log("---------------------wallet balance updated--------------");
                 } else {
                    console.log("----wallet balance not updated----");
                 }
             }
         }else{
            console.log("not completed.........")
         }
       

    }else{
         console.log(responseObject)
        console.log("Payment not successful");
        const deletedTransaction = await Transaction.findOneAndDelete({
            transaction_id: responseObject.data.merchantTransactionId,
            status: "pending",
         }).exec();
    }
           
  }catch(error){
    console.error("ERROR IN PG PHONE PAY SUCCESS HANDLER-------------",error);
  }
}