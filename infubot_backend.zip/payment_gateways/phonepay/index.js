const axios = require("axios");
const {payment_gateway_configuration} = require("../config");
const logger = require("winston");
const { createHash } = require("crypto");
const PHONEPAY_API_HANDLER = "PHONEPAY_API_HANDLER";

const config = payment_gateway_configuration["test"]


const generatePhonePayPaymentLink = async (order_details, user_details) => {
    try {
        const merchant_transaction_id = order_details.order_id.replace(/-/g, "_");
        let payload = {
            merchantId: config.phonepe.merchantId,
            merchantTransactionId: merchant_transaction_id,
            merchantUserId: Math.random().toString(36).substring(2, 12),
            amount: parseInt(order_details.gross_amount) * 100,
            redirectUrl: config.phonepe.redirectUrl,
            redirectMode: config.phonepe.redirectMode,
            callbackUrl: config.phonepe.callbackUrl,
            mobileNumber: "9957588243",
            paymentInstrument: {
              type: "PAY_PAGE",
            },
          };
          console.log(payload);
         let buff = Buffer(JSON.stringify(payload)).toString("base64");
         let salt_key = config.phonepe.saltKey;
         let salt_index = config.phonepe.saltIndex;
         let request = { request: buff };
         let hash = Buffer.from(
            createHash("sha256")
              .update(buff + "/pg/v1/pay" + salt_key)
              .digest("hex")
          ); //
          let x_verify = hash + "###" + salt_index;
          axios
          .post(config.phonepe.phonePePayUrl, request, {
            headers: {
              "Content-Type": " application/json",
              accept: "application/json",
              "X-VERIFY": x_verify,
            },
          })
          .then(async function (response) {      
            console.log(response.data);
            return true1
          })
          .catch(function (error) {
            console.log(error);
            return false
          });
    }catch(error){
        logger.error(
            `[${PHONEPAY_API_HANDLER} generatePhonePayPaymentLink API response error:- ${error.message}`
          );
    }
  };


  module.exports = {
    generatePhonePayPaymentLink
  }