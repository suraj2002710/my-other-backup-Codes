const { User } = require("../../models/Users");
const { Wallet } = require("../../models/Wallet");
const { Transaction } =require("../../models/Transaction");
const {getIoInstance} =require('../../socket_chat_infra/index');
module.exports.successHandler = async (req, res) => {
   try {
      console.log("indic Pay----------", req.body);
      if (req.body && req.body.status === "SUCCESS") {
         let updateTransaction = await Transaction.findOneAndUpdate(
            { transaction_id: req.body.txnid, status: "pending" },
            {
               status: "success",
            },
            { new: true },
         );
         if (updateTransaction) {
            let isWalletUpdated = await Wallet.findOneAndUpdate({ user_email: updateTransaction.user_email }, { $inc: { wallet_balance: Math.round(updateTransaction.amount) } }, { new: true });
            if (isWalletUpdated) {
               const io = getIoInstance();
               if (!io) {
                  console.error("Socket.IO instance is not initialized.");
               }

               io.to(`${isWalletUpdated.user_id}`).emit("fetched_user_wallet_balance", {
                  message: "User Balance Fetched Successfully",
                  wallet_balance: isWalletUpdated.wallet_balance,
               });

               console.log("---------------------wallet balance updated--------------");
            } else {
               console.log("----wallet balance not updated----");
            }
         } else {
            console.log("---transaction not found---");
         }
      } else {
         // const deletedTransaction = await Transaction.findOneAndDelete({
         //    transaction_id: req.body.txnid,
         //    status: "pending",
         // }).exec();
      }
   } catch (error) {
      console.error(`-------------indicPay successHandler API response error------------:- ${error.message}`);
   }
};
