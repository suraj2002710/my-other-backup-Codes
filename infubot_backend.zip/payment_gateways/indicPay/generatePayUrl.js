const { User } = require("../../models/Users");
const { BaseRates } = require("../../models/BaseRate");
const { Transaction } = require("../../models/Transaction");
const { v4: uuidv4 } = require("uuid");
const { createHash } = require("crypto");
const axios = require("axios");
const dotenv = require("dotenv");
dotenv.config();
const moment = require('moment-timezone');

function generateTransactionId() {
   const uniqueId = uuidv4();
   const currentTime = Math.floor(Date.now() / 1000).toString();
   const randomChars = Math.random().toString(36).substring(7);
   const concatenatedString = uniqueId + currentTime + randomChars;
   const hashedString = createHash("sha256").update(concatenatedString).digest("hex");
   const transactionId = "T0" + hashedString.substring(0, 15).toLocaleUpperCase();
   return transactionId;
}

function generateBase64({ utxnid, token, mid, amount }) {
   const base64 = Buffer.from(JSON.stringify({ utxnid, token, mid, amount })).toString("base64");
   return base64;
}

async function createEncryption(base64) {
   try {
      let apiData = {
         apiUrl: "https://indicpay.in/api/encryption",
         headers: {
            "Content-Type": "application/json",
         },
         body: {
            base64encodedata: base64,
            mid: process.env.INDICPAY_MID,
            iv: 9999888888878890,
         },
      };

      let response = await axios.post(apiData.apiUrl, apiData.body, { headers: apiData.headers });
      if (response.data) {
         return response.data;
      }
   } catch (error) {
      return null;
   }
}

async function getPaymentBase64(encryption) {
   try {
      let apiData = {
         apiUrl: "https://indicpay.in/api/upi/get_dynamic_qr",
         headers: {
            Token: process.env.INDICPAY_TOKEN,
            iv: 9999888888878890,
            "Content-Type": "application/json",
         },
         body: {
            body: encryption,
            hash: process.env.INDICPAY_HASH_OF_TOKEN_MID,
         },
      };

      let response = await axios.post(apiData.apiUrl, apiData.body, { headers: apiData.headers });
      if (response.data) {
         return response.data;
      }
   } catch (error) {
      return null;
   }
}

module.exports.generatePayUrl = async (req, res) => {
   try {
      if (req.user && req.user.id && req.body.amount) {
         let user = await User.findById(req.user.id);
         if (user) {
            let getBaseRate = await BaseRates.findOne({});
            let finalAmount = (req.body.amount * getBaseRate.gst) / 100 + req.body.amount + req.body.amount * (getBaseRate.platform_fee / 100);
            let transactionId = generateTransactionId();
            let base64 = generateBase64({ utxnid: transactionId, token: process.env.INDICPAY_TOKEN, mid: process.env.INDICPAY_MID, amount: finalAmount });
            let encryption = await createEncryption(base64);
            let getPaymentBase = await getPaymentBase64(encryption);
               console.log("----getPaymentBase------", getPaymentBase);
               const paymentDate = moment().tz('Asia/Kolkata').toDate();
               if (getPaymentBase != null) {
                let transactionRecord = await Transaction.create({
                    user_id: user._id,
                    user_email: user.email,
                    creator_id: null,
                    creator_email: null,
                    type: "Wallet Recharge",
                    amount: Math.round(req.body.amount),
                    total_amount: finalAmount,
                    gst: Math.round((req.body.amount * getBaseRate.gst) / 100),
                    platform_fee: req.body.amount * (getBaseRate.platform_fee / 100),
                    transaction_id: transactionId,
                    payment_received_from: "IndicPay",
                    payment_date:paymentDate,
                    status: "pending",
                 });
                 if(transactionRecord){
                     return res.status(200).json({ message: "success", data: getPaymentBase.qr });
                 }
               }
             return res.status(500).json({ message: "failed to create encryption" });
         }
         return res.status(400).json({ message: "user not found" });
      }
      return res.status(500).json({ message: "invalid request data" });
   } catch (error) {
      console.error(`-------------generatePayUrl API response error------------:- ${error.message}`);
      return res.status(500).json({ message: error.message });
   }
};
