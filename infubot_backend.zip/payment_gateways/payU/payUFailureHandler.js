const {Transaction} = require('../../models/Transaction');
module.exports.payUFailureHandler = async (req,res) => {
    try {
        console.log('payUFailureHandler API called',req.body);
        if(req.body&&req.body.status!=='success'){
            // let deleteRecord = await Transaction.findOneAndDelete({
            //     transaction_id: req.body.txnid,
            //     status: 'pending'
            // });
            // if(deleteRecord){
            //     console.log('---transaction deleted---');
            // }else{
            //     console.log('---transaction not deleted---');
            
            // }
        }
    
    } catch (error) {
        console.error(`-------------payUFailureHandler API response error------------:- ${error.message}`); 
    }
 };