const { User } = require("../../models/Users");
const { v4: uuidv4 } = require("uuid");
const { createHash } = require("crypto");
const { BaseRates } = require("../../models/BaseRate");
const { Transaction } = require("../../models/Transaction");
const dotenv = require("dotenv");
dotenv.config();
const moment = require('moment-timezone');


function calculateHash(key, txnid, amount, productinfo, firstname, email, salt, udf1 = "", udf2 = "", udf3 = "", udf4 = "", udf5 = "") {
   const hashString = `${key}|${txnid}|${amount}|${productinfo}|${firstname}|${email}|${udf1}|${udf2}|${udf3}|${udf4}|${udf5}||||||${salt}`;
   const hash = createHash("sha512").update(hashString).digest("hex");
   return hash;
}

function generateTransactionId() {
   const uniqueId = uuidv4();
   const currentTime = Math.floor(Date.now() / 1000).toString();
   const randomChars = Math.random().toString(36).substring(7);
   const concatenatedString = uniqueId + currentTime + randomChars;
   const hashedString = createHash("sha256").update(concatenatedString).digest("hex");
   const transactionId = "T0" + hashedString.substring(0, 15).toLocaleUpperCase();
   return transactionId;
}

module.exports.payUForm = async (req, res) => {
   try {
      console.log("getPayUForm API called");
      if (req.user && req.user.id && req.body.amount) {
         let user = await User.findById(req.user.id);
         if (user) {
            let getBaseRate = await BaseRates.findOne({});
            let finalAmount = (req.body.amount * getBaseRate.gst) / 100 + req.body.amount + req.body.amount * (getBaseRate.platform_fee / 100);
            let transactionId = generateTransactionId();
            let generateHash = calculateHash(process.env.PAYU_MERCHANT_KEY, transactionId, finalAmount, "virtual coin", user.first_name, user.email, process.env.PAYU_MERCHANT_SALT);
            const paymentDate = moment().tz('Asia/Kolkata').toDate();
            let transactionRecord = await Transaction.create({
               user_id: user._id,
               user_email: user.email,
               creator_id: null,
               creator_email: null,
               type: "Wallet Recharge",
               amount: Math.round(req.body.amount),
               total_amount: finalAmount,
               gst: Math.round((req.body.amount * getBaseRate.gst) / 100),
               platform_fee: req.body.amount * (getBaseRate.platform_fee / 100),
               transaction_id: transactionId,
               payment_received_from: "PayU",
               payment_date:paymentDate,
               status: "pending",
            });

            if (generateHash && transactionRecord) {
               return res.status(200).json({ key: process.env.PAYU_MERCHANT_KEY, transactionId, hash: generateHash, amount: finalAmount, productInfo: "virtual coin", firstname: user.first_name, email: user.email, salt: process.env.PAYU_MERCHANT_SALT });
            }

            return res.status(500).json({ message: "hash generation failed" });
         }
         return res.status(400).json({ message: "user not found" });
      }
      return res.status(500).json({ message: "invalid request data" });
   } catch (error) {
      console.error(`-------------getPayUForm API response error------------:- ${error.message}`);
      return res.status(500).json({ message: error.message });
   }
};
