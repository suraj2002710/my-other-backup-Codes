const { User } = require("../../models/Users");
const { Wallet } = require("../../models/Wallet");
const { Transaction } = require("../../models/Transaction");
const {getIoInstance} = require('../../socket_chat_infra/index');

module.exports.payUSuccessHandler = async (req, res) => {
   try {
      console.log("payUSuccessHandler API called");
      if (req.body && req.body.status === "success") {
         let isUserExist = await User.findOne({ email: req.body.email });
         if (isUserExist) {
            let updateTransaction = await Transaction.findOneAndUpdate(
               { transaction_id: req.body.txnid, status: "pending" },
               {
                  status: "success",
               },
               { new: true },
            );
            if (updateTransaction) {
               console.log("---transaction updated---", updateTransaction.amount);
               let isWalletUpdated = await Wallet.findOneAndUpdate({ user_email: isUserExist.email }, { $inc: { wallet_balance: Math.round(updateTransaction.amount) } }, { new: true });
               if (isWalletUpdated) {
   
                  console.log("---------------------wallet balance updated--------------");
                  console.log(isWalletUpdated);
               } else {
                  console.log("----wallet balance not updated----");
               }
            } else {
               console.log("---transaction not updated---");
            }
            console.log("---task end----");
         }
      } else {
         console.log("----payment status failed---");
      }
   } catch (error) {
      console.error(`-------------payUSuccessHandler API response error------------:- ${error.message}`);
   }
};
