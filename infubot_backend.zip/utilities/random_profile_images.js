// const random_user_profile = () => {
//    let image =  process.env.BASE_URL_FOR_CREATOR + `/public/user_dummies/Male/dummy_${Math.floor(Math.random() * 48) + 1}.png`
//    return image
// }


const random_user_profile = (gender = 'Male') => {
    const basePath = process.env.BASE_URL_FOR_CREATOR + `/public/user_dummies/${gender}/`;
    const image = `${basePath}dummy_${Math.floor(Math.random() * 48) + 1}.png`;
    return image;
}


module.exports = {
    random_user_profile
}