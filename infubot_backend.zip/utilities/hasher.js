const crypto = require('crypto');

module.exports.generateRandomHash = () => {
    const randomValue = crypto.randomBytes(16).toString('hex');
    const algorithm = 'sha256';
    const hash = crypto.createHash(algorithm).update(randomValue).digest('hex');
    return hash;
}

