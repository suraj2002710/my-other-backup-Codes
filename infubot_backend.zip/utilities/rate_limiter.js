const rateLimit = require("express-rate-limit");
const userController = require("../controllers/userControllers");
const { User } = require("../models/Users");
const { Creator } = require("../models/Creator");
const { UserHolded } = require("../models/UserHolded");
const {
  notifyAboutCreatorMultipeLogin,
  notifyAboutUserMultipeLogin,
} = require("../mailing_service");

const user_login_rate_limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 2, // limit each IP to 10 requests per windowMs
  // message: "Too many requests from this IP, please try again later",
  handler: async function (req, res, next) {
    const { email } = req.body;
    const check_if_user_exist = await User.findOne({
      email,
    });
    if (check_if_user_exist) {
      const ipAddress =
        req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
      check_if_user_exist.user_holded = true;
      check_if_user_exist.user_holded_at = new Date().toISOString();
      const add_hold_reason = await UserHolded.create({
        id: check_if_user_exist.id,
        ip: ip,
        email: check_if_user_exist.email,
        name:
          check_if_user_exist.first_name + "" + check_if_user_exist.last_name,
        reason: "Login multiple times",
        type: "user",
      });
     await check_if_user_exist.save();
      if (add_hold_reason) {
        await notifyAboutUserMultipeLogin(process.env.ADMIN_EMAIL, {
          id: check_if_user_exist.id,
          email: check_if_user_exist.email,
          name:
            check_if_user_exist.first_name +
            " " +
            check_if_user_exist.last_name,
        });
        res.status(200).json({
          error: `Too many requests from this IP, you have been holded for ${process.env.HOLD_DURATION} minute`,
        });
      }
    }
  },
});

const creator_login_rate_limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 2, // limit each IP to 10 requests per windowMs
  // message: "Too many requests from this IP, please try again later",
  handler: async function (req, res, next) {
    const { email } = req.body;
    const check_if_creator_exist = await Creator.findOne({
      email,
    });
    if (check_if_creator_exist) {
      const ipAddress =
        req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
      await notifyAboutCreatorMultipeLogin(process.env.ADMIN_EMAIL, {
        id: check_if_creator_exist.id,
        email: check_if_creator_exist.email,
        name:
          check_if_creator_exist.first_name +
          " " +
          check_if_creator_exist.last_name,
      });
      res.status(200).json({
        error: `Too many requests from this IP`,
      });
    }
  },
});

const user_wallet_recharge_rate_limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 1, // limit each IP to 10 requests per windowMs
  // message: "Too many requests from this IP, please try again later",
  handler: async function (req, res, next) {
    console.log("User Details", req.user);
    return res.status(200).json({
      error: `Too many requests from this IP`,
    });
    // const {email} = req.body;
    // const check_if_creator_exist = await Creator.findOne({
    //     email
    // })
    // if(check_if_creator_exist){
    //     const ipAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    //     const ip = ipAddress ? ipAddress.split(',')[0].trim() : '';
    //         await notifyAboutCreatorMultipeLogin(process.env.ADMIN_EMAIL,{
    //             id : check_if_creator_exist.id,
    //             email : check_if_creator_exist.email,
    //             name : check_if_creator_exist.first_name + " " + check_if_creator_exist.last_name
    //         })
    //         res.status(200).json({
    //             error : `Too many requests from this IP`
    //         })
    // }
  },
});

module.exports.rateLimiter = {
  user_login_rate_limiter: user_login_rate_limiter,
  creator_login_rate_limiter: creator_login_rate_limiter,
};
