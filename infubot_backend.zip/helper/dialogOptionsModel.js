class DialogOptions {
  constructor() {
    this.hasOption = false;
    this.forCLU = false;
    this.userQuery = null;
    this.hasChildDialog = false;
  }
}

module.exports = {
  DialogOptions,
};
