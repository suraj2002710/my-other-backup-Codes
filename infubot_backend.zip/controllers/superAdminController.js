const { SuperAdmin } = require("../models/SuperAdmin");const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { CreatorRevenueHistory } = require("../models/CreatorRevenueHistory");
const { CreatorKYC } = require("../models/CreatorKYC");
const VideoConnectivty = require("../models/VideoConnection");
const AudioConnectivty = require("../models/AudioConnection");
const { CreatorBillingDetails } = require("../models/CreatorBillingDetails");
const { CreatorBankDetails } = require("../models/CreatorBankDetails");
const { CreatorAIPersonality } = require("../models/creatorAIPersonality");
const { User } = require("../models/Users");
const { InterestedCreator } = require("../models/interestedCreator");
const { sendConversionNotificationMailToCreator } = require("../services/creatorConversionMail");
const { Transaction } = require("../models/Transaction");
const { CreatorEarning } = require("../models/creatorEarning");
const { CreatorWithdrawHistory } = require("../models/creatorWithdrawHistory");
const logger = require("winston");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const _ = require("lodash");
const { Wallet } = require("../models/Wallet");
const { Creator } = require("../models/Creator");
const { SOMETHING_WENT_WRONG } = require("../constant");
const moment = require("moment");

const SuperAdminController = "SUPER_ADMIN_CONTROLLER";

module.exports.getAllSuperAdmins = async (req, res, next) => {
   try {
      const super_admins = await SuperAdmin.find({});
      logger.info(`[${SuperAdminController} getAllSuperAdmins API response success]`);
      res.send({
         statusCode: 200,
         data: super_admins,
         message: "Super Admin list captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getAllSuperAdmins API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.deleteAllSuperAdmins = async (req, res, next) => {
   try {
      if (req.super_admin.id) {
         const super_admins = await SuperAdmin.deleteMany({});
         logger.info(`[${SuperAdminController} getAllSuperAdmins API response success]`);
         res.send({
            statusCode: 200,
            data: super_admins,
            message: "Super Admin list deleted successfully",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${SuperAdminController} getAllSuperAdmins API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.deleteSuperAdminById = async (req, res, next) => {
   try {
      const { super_admin_id } = req.params;
      if (req.super_admin.id) {
         const super_admins = await SuperAdmin.deleteOne({
            _id: super_admin_id,
         });
         logger.info(`[${SuperAdminController} getAllSuperAdmins API response success]`);
         res.send({
            statusCode: 200,
            data: super_admins,
            message: "Super Admin deleted successfully",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${SuperAdminController} getAllSuperAdmins API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getSuperAdminByEmail = async (req, res, next) => {
   try {
      const super_admins = await SuperAdmin.findOne({ email: req.body.email });
      logger.info(`[${SuperAdminController} getSuperAdminByEmail API response success]`);
      res.send({
         statusCode: 200,
         data: super_admins,
         message: "Super Admin list captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getSuperAdminByEmail API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getSuperAdminProfile = async (req, res, next) => {
   try {
      const super_admin = await SuperAdmin.findById(req.super_admin.id);
      logger.info(`[${SuperAdminController} getSuperAdminProfile API response success]`);
      res.send({
         statusCode: 200,
         data: super_admin,
         message: "Super Admin profile captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} Super Admin profile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getSuperAdminDetailsByPhone = async (req, res, next) => {
   try {
      const { phone_number } = req.body;

      // Check if phone number is provided
      if (!phone_number) {
         return res.status(400).send({
            statusCode: 400,
            data: null,
            message: "Phone number is required",
            error: null,
         });
      }

      // Find the super admin by phone number
      const super_admin = await SuperAdmin.findOne({ phone_number });

      if (!super_admin) {
         // Super admin not found
         return res.status(404).send({
            statusCode: 404,
            data: null,
            message: `No Super Admin exists with phone number ${phone_number}`,
            error: null,
         });
      }

      // Generate a token for the super admin
      const token = jwt.sign({ id: super_admin.id, email: super_admin.email, role: "super_admin" }, process.env.SuperAdminSecretKey);

      // Respond with the super admin details
      res.send({
         statusCode: 200,
         data: super_admin,
         message: "Super Admin profile captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} Super Admin profile API response error:- ${error.message}]`);
      res.status(500).send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.createSuperAdmin = async (req, res, next) => {
   try {
      const requiredFields = {
         email: "Email",
         phone_number: "Phone number",
         first_name: "First Name",
         last_name: "Last Name",
      };

      const missingFields = Object.entries(requiredFields)
         .filter(([field, label]) => req.body[field] === undefined)
         .map(([field, label]) => label);

      if (missingFields.length > 0) {
         return res.status(500).send({
            statusCode: 500,
            data: null,
            message: null,
            error: `${missingFields.join(" and ")} ${missingFields.length > 1 ? "are" : "is"} required.`,
         });
      }

      const checkIfSameUsernameExist = await SuperAdmin.findOne({
         phone_number: req.body.phone_number,
      });
      if (checkIfSameUsernameExist) {
         return res.send({
            statusCode: 200,
            // data: super_admin,
            message: `Super Admin with Phone Number ${req.body.phone_number} already exist. Try different user name`,
            error: null,
         });
      }

      let super_admin = await SuperAdmin.create(req.body);
      const salt = await bcrypt.genSalt(10);
      super_admin.password = await bcrypt.hash(super_admin.password, salt);
      await super_admin.save();

      const token = jwt.sign({ id: super_admin.id, email: super_admin.email, role: "super_admin" }, process.env.UserSecretKey);

      super_admin = _.pick(super_admin, ["id", "first_name", "last_name", "email", "phone_number", "username"]);

      super_admin.token = token;

      logger.info(`[${SuperAdminController} createSuperAdmin API response success]`);
      res.send({
         statusCode: 200,
         data: super_admin,
         message: "Super Admin created successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} createUser API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.loginSuperAdmin = async (req, res, next) => {
   try {
      let super_admin = await SuperAdmin.findOne({
         phone_number: req.body.phone_number,
      });
      if (!super_admin) {
         logger.info(`[${SuperAdminController} loginSuperAdmin API response message :- Super Admin with ${req.body.phone_number} not found]`);
         return res.send({
            statusCode: 404,
            data: null,
            message: null,
            error: "Super Admin not found!",
         });
      }

      let validatePassword = await bcrypt.compare(req.body.password, super_admin.password);
      if (!validatePassword) {
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Invalid Password",
         });
      }

      const token = jwt.sign({ id: super_admin.id, email: super_admin.email, role: "super_admin" }, process.env.SuperAdminSecretKey);

      super_admin = _.pick(super_admin, ["id", "first_name", "last_name", "email", "phone_number", "username"]);

      super_admin.token = token;
      logger.info(`[${SuperAdminController} loginSuperAdmin API response success]`);
      return res.send({
         statusCode: 200,
         data: super_admin,
         message: "Super Admin logged In successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} loginUser API response error:- ${error.message}]`);
      res.status(500).send({ error: error.message });
   }
};

module.exports.updateSuperAdminDetails = async (req, res, next) => {
   try {
      let updateSuperAdmin = req.body;
      if (updateSuperAdmin?.password) {
         delete updateUser.password;
      }
      const user = await SuperAdmin.update({ _id: req.super_admin.id }, { $set: updateUser });
      logger.info(`[${SuperAdminController} updateSuperAdminDetails API response success]`);
      res.send({
         statusCode: 200,
         data: user,
         message: "Super Amin updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateSuperAdminDetails API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.resetPassword = async (req, res, next) => {
   try {
      let updateSuperAdmin = req.body;
      const { password, confirm_password } = updateSuperAdmin;

      // Check if the password and confirm password match
      if (password !== confirm_password) {
         return res.status(400).send({
            statusCode: 400,
            data: null,
            message: "Password & Confirm Password doesn't match",
            error: null,
         });
      }

      // Hash the new password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      // console.log("hashed", hashedPassword);

      // Update the super admin's password
      const result = await SuperAdmin.updateOne({ _id: req.body.id }, { $set: { password: hashedPassword } });

      // Check if the update was successful
      if (result.matchedCount === 0) {
         return res.status(404).send({
            statusCode: 404,
            data: null,
            message: "Super Admin not found",
            error: null,
         });
      }

      if (result.modifiedCount === 0) {
         return res.status(400).send({
            statusCode: 400,
            data: null,
            message: "Password was not updated",
            error: null,
         });
      }

      logger.info(`[${SuperAdminController} updateSuperAdminDetails API response success]`);
      res.send({
         statusCode: 200,
         data: null,
         message: "Super Admin Password updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateSuperAdminDetails API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorProfileForSuperAdmin = async (req, res, next) => {
   try {
      const { id } = req.params;
      if (!id) {
         res.send({
            statusCode: 400,
            data: null,
            message: "Creator id is required",
            error: null,
         });
      }
      let creator = await Creator.findById(id);

      if (!creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      creator = creator.toObject();
      creator.profile_pic = creator.profile_pic ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic : "";
      creator.bot_link = process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;

      const get_creator_audio_call_details = await AudioConnectivty.find({
         creator_id: creator.email,
      });
      const get_creator_video_call_details = await VideoConnectivty.find({
         creator_id: creator.email,
      });

      creator.insights = {};
      creator.insights.audio_call = get_creator_audio_call_details.length;
      creator.insights.video_call = get_creator_video_call_details.length;

      logger.info(`[${SuperAdminController} getCreatorProfileForSuperAdmin API response success]`);
      res.send({
         statusCode: 200,
         data: creator,
         message: "Creator profile captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorProfileForSuperAdmin = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      if (updateCreator?.password) {
         delete updateCreator.password;
      }
      if (updateCreator?.creator_status) {
         delete updateCreator.creator_status;
      }

      // console.log("Body", updateCreator, req.params.id);

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await Creator.findOneAndUpdate({ _id: req.params.id }, { $set: updateCreator }, { new: true });

      // console.log("creator", creator);

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorBotInformation = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      // if (updateCreator?.password) {
      //   delete updateCreator.password;
      // }
      // if(updateCreator?.creator_status){
      //     delete updateCreator.creator_status;
      // }

      // console.log("Body", updateCreator, req.params.id)

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await CreatorBotSetting.findOneAndUpdate({ creator_id: req.params.id }, { $set: updateCreator }, { new: true });

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator Bot Settings updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorKYCInformation = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      // if (updateCreator?.password) {
      //   delete updateCreator.password;
      // }
      // if(updateCreator?.creator_status){
      //     delete updateCreator.creator_status;
      // }

      // console.log("Body", updateCreator, req.params.id)

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await CreatorKYC.findOneAndUpdate({ creator_id: req.params.id }, { $set: updateCreator }, { new: true });

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator KYC Details updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorBillingInformation = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      // if (updateCreator?.password) {
      //   delete updateCreator.password;
      // }
      // if(updateCreator?.creator_status){
      //     delete updateCreator.creator_status;
      // }

      // console.log("Body", updateCreator, req.params.id)

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await CreatorBillingDetails.findOneAndUpdate({ creator_id: req.params.id }, { $set: updateCreator }, { new: true });

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator Billing Details updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorBankInformation = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      // if (updateCreator?.password) {
      //   delete updateCreator.password;
      // }
      // if(updateCreator?.creator_status){
      //     delete updateCreator.creator_status;
      // }

      // console.log("Body", updateCreator, req.params.id)

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await CreatorBankDetails.findOneAndUpdate({ creator_id: req.params.id }, { $set: updateCreator }, { new: true });

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator Bank Details updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorAIPersonality = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let updateCreator = req.body;

      // if (updateCreator?.password) {
      //   delete updateCreator.password;
      // }
      // if(updateCreator?.creator_status){
      //     delete updateCreator.creator_status;
      // }

      // console.log("Body", updateCreator, req.params.id)

      // if (req.file) {
      //   let { originalname, destination } = req.file;

      //   renameImage(req.file);

      //   image = destination + "/" + originalname;
      // }
      // if (req.file) {
      //   updateCreator.profile_pic = image;
      // }

      const creator = await CreatorAIPersonality.findOneAndUpdate({ creator_id: req.params.id }, { $set: updateCreator }, { new: true });

      logger.info(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response success]`);

      return res.send({
         statusCode: 200,
         data: creator,
         message: "Creator AI Details updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} updateCreatorProfileForSuperAdmin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorBotSettingDetails = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      const creator_bot_setting = await CreatorBotSetting.findOne({
         creator_id: req.params.id,
      });
      logger.info(`[${SuperAdminController} getCreatorBotSettingDetails API response success]`);
      res.send({
         statusCode: 200,
         data: creator_bot_setting,
         message: "Creator Bot details captured sucessfully!",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getCreatorBotSettingDetails API response error:- ${error.message}`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorRevenueDetails = async (req, res, next) => {
   try {
      const creator = await Creator.findById(req.params.id);

      if (!creator) {
         return res.status(404).send({
            statusCode: 400,
            message: `Creator with id ${req.params.id} doesn't exist`,
            error: null,
            data: null,
         });
      }

      const revenueData = await CreatorRevenueHistory.aggregate([
         {
            $match: { creator_email: creator.email },
         },
         {
            $group: {
               _id: "$type",
               totalAmount: { $sum: "$amount" },
               totalCount: { $sum: 1 },
            },
         },
         {
            $project: {
               _id: 0,
               type: "$_id",
               totalAmount: 1,
               totalCount: 1,
            },
         },
      ]);

      let formattedResult = {
         creator_name: creator.name,
         chat_amount: 0,
         video_amount: 0,
         audio_amount: 0,
         ai_amount: 0, // If applicable
         total_amount: 0,
         chat_count: 0,
         video_count: 0,
         audio_count: 0,
         ai_count: 0, // If applicable
         total_transactions: 0,
      };

      revenueData.forEach((item) => {
         const { type, totalAmount, totalCount } = item;
         formattedResult[`${type}_amount`] = Math.round(totalAmount);
         formattedResult[`${type}_count`] = totalCount;
         formattedResult.total_amount += Math.round(totalAmount);
         formattedResult.total_transactions += totalCount;
      });

      res.status(200).send({
         statusCode: 200,
         error: null,
         message: "Creator Bot details captured successfully!",
         data: formattedResult,
      });
   } catch (error) {
      logger.error(`[getCreatorBotSettingDetails API response error: ${error.message}]`);
      res.status(500).send({
         message: "An error occurred while fetching creator bot details",
         error: error.message,
      });
   }
};

module.exports.getCreatorCallLogsDetails = async (req, res, next) => {
   try {
      const get_creator_details_by_id = await Creator.findById(req.params.id);
      if (!get_creator_details_by_id) {
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Creator Doesn't exist",
         });
      }

      // Fetch audio connectivity logs
      let audio_connectivity = await AudioConnectivty.find({
         creator_id: get_creator_details_by_id.email,
         // connection: { $in: ["cancelled", "complete"] }
      });

      // Fetch video connectivity logs
      let video_connectivity = await VideoConnectivty.find({
         creator_id: get_creator_details_by_id.email,
         // connection: { $in: ["cancelled", "complete"] }
      });

      // Function to calculate duration and format it as HH:MM:SS
      const calculateDuration = (call) => {
         const startTime = new Date(call.start_time);
         const endTime = new Date(call.updatedAt);

         if (isNaN(startTime.getTime()) || isNaN(endTime.getTime())) {
            return "00:00:00";
         }

         let durationInSeconds = (endTime - startTime) / 1000;

         if (isNaN(durationInSeconds) || durationInSeconds < 0) {
            return "00:00:00";
         }

         const hours = Math.floor(durationInSeconds / 3600);
         durationInSeconds %= 3600;
         const minutes = Math.floor(durationInSeconds / 60);
         const seconds = durationInSeconds % 60;

         return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toFixed(0).padStart(2, "0")}`;
      };

      // Process audio logs
      let audioLogs = audio_connectivity.map((call) => ({
         ...call.toObject(),
         duration: calculateDuration(call),
      }));

      // Process video logs
      let videoLogs = video_connectivity.map((call) => ({
         ...call.toObject(),
         duration: calculateDuration(call),
      }));

      // const addUserNameToLogs = async (logs) => {
      //   return Promise.all(logs.map(async (call) => {
      //     const user = await User.findOne({
      //       email : call.user_id
      //     }); // Fetch user details
      //     const userName = user ? user.first_name +" "+ user.last_name  : "Unknown"; // Get user name or a default value
      //     return {
      //       ...call.toObject(),
      //       user_name : userName, // Add user name to the log
      //       duration: calculateDuration(call)
      //     };
      //   }));
      // };

      // const addCreatorNameToLogs = async (logs) => {
      //   return Promise.all(logs.map(async (call) => {
      //     const creator = await Creator.findOne({
      //       email : call.creator_id
      //     }); // Fetch creator details
      //     console.log("Creator", creator)
      //     const creatorName = creator ? creator.first_name +" "+ creator.last_name  : "Unknown"; // Get user name or a default value
      //     return {
      //       ...call.toObject(),
      //       user_name : creatorName, // Add user name to the log
      //       duration: calculateDuration(call)
      //     };
      //   }));
      // };

      const addEntityNamesToLogs = async (logs) => {
         return Promise.all(
            logs.map(async (call) => {
               const user = await User.findOne({ email: call.user_id });
               const creator = await Creator.findOne({ email: call.creator_id });

               const userName = user ? user.first_name + " " + user.last_name : "Unknown";
               const creatorName = creator ? creator.first_name + " " + creator.last_name : "Unknown";

               return {
                  ...call.toObject(),
                  user_name: userName,
                  creator_name: creatorName,
                  duration: calculateDuration(call),
               };
            }),
         );
      };

      // Example usage

      const formatRelativeDate = (date) => {
         return moment(date).calendar(null, {
            sameDay: "[Today]",
            nextDay: "[Tomorrow]",
            nextWeek: "dddd",
            lastDay: "[Yesterday]",
            lastWeek: "[Last] dddd",
            sameElse: "DD/MM/YYYY",
         });
      };

      audioLogs = await addEntityNamesToLogs(audio_connectivity);
      videoLogs = await addEntityNamesToLogs(video_connectivity);

      // audioLogs = await addUserNameToLogs(audio_connectivity);
      // videoLogs = await addUserNameToLogs(video_connectivity);

      audioLogs = audioLogs.map((log) => ({
         ...log,
         displayDate: formatRelativeDate(log.createdAt),
         type: "audio",
      }));
      videoLogs = videoLogs.map((log) => ({
         ...log,
         displayDate: formatRelativeDate(log.createdAt),
         type: "video",
      }));

      return res.send({
         statusCode: 200,
         data: [...audioLogs, ...videoLogs],
         message: "Combined audio and video call logs fetched successfully",
         error: null,
      });
   } catch (error) {
      return res.send({
         statusCode: 400,
         data: null,
         message: null,
         error: error.toString(),
      });
   }
};

module.exports.getCreatorKYCDetails = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      let creator_kyc_details = await CreatorKYC.findOne({
         creator_id: req.params.id,
      });
      logger.info(`[${SuperAdminController} getCreatorBotSettingDetails API response success]`);
      res.send({
         statusCode: 200,
         data: creator_kyc_details,
         message: "Creator KYC details captured successfully!",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getCreatorBotSettingDetails API response error:- ${error.message}`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorBillingDetails = async (req, res, next) => {
   try {
      let check_creator = await Creator.findById(req.params.id);

      if (!check_creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      const creator_bank_details = await CreatorBillingDetails.find({
         creator_id: req.params.id,
      });
      logger.info(`[${SuperAdminController} getCreatorBillingDetails API response success]`);
      res.send({
         statusCode: 200,
         data: creator_bank_details,
         message: "Creator Billing details captured successfully!",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getCreatorBillingDetails API response error:- ${error.message}`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorBankDetails = async (req, res, next) => {
   try {
      const creator_bank_details = await CreatorBankDetails.findOne({
         creator_id: req.params.id,
      });
      logger.info(`[${SuperAdminController} getCreatorBillingDetails API response success]`);
      res.send({
         statusCode: 200,
         data: creator_bank_details,
         message: "Creator Bank details captured successfully!",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getCreatorBillingDetails API response error:- ${error.message}`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

   module.exports.getCreatorAIDetails = async (req, res, next) => {
      try {
         let check_creator = await Creator.findById(req.params.id);

         if (!check_creator) {
            return res.send({
               statusCode: 200,
               data: null,
               message: "Creator Doesn't Exist",
               error: null,
            });
         }

         const creator_ai_personality = await CreatorAIPersonality.findOne({
            creator_id: req.params.id,
         });
         logger.info(`[${SuperAdminController} getCreatorBillingDetails API response success]`);
         res.send({
            statusCode: 200,
            data: creator_ai_personality,
            message: "Creator AI details fetched successfully!",
            error: null,
         });
      } catch (error) {
         logger.error(`[${SuperAdminController} getCreatorBillingDetails API response error:- ${error.message}`);
         res.send({
            statusCode: 500,
            data: null,
            message: null,
            error: error.message,
         });
      }
   };

// module.exports.getAllCreatorAIDetails = async (req, res, next) => {
//   try {
//     const creator_ai_personality = await CreatorAIPersonality.find({});
//     logger.info(
//       `[${SuperAdminController} getCreatorBillingDetails API response success]`
//     );
//     res.send({
//       statusCode: 200,
//       data: creator_ai_personality,
//       message: "All Creator AI details fetched successfully!",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${SuperAdminController} getCreatorBillingDetails API response error:- ${error.message}`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.getAllCreatorAIDetails = async (req, res, next) => {
   try {
      const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not specified
      const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page if not specified
      const skip = (page - 1) * limit;

      const totalAIDetails = await CreatorAIPersonality.countDocuments({});
      const creator_ai_personality = await CreatorAIPersonality.find({}).skip(skip).limit(limit);

      logger.info(`[${SuperAdminController} getAllCreatorAIDetails API response success]`);

      // Determine if there's a next page
      const hasNextPage = page * limit < totalAIDetails;
      const nextPageUrl = hasNextPage ? `${req.protocol}://${req.get("host")}${req.baseUrl}${req.path}?page=${page + 1}&limit=${limit}` : null;

      res.send({
         statusCode: 200,
         data: creator_ai_personality,
         nextPage: nextPageUrl,
         message: "All Creator AI details fetched successfully!",
         error: null,
      });
   } catch (error) {
      logger.error(`[${SuperAdminController} getAllCreatorAIDetails API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateInterestedCreatorStatus = async (req, res, next) => {
   try {
      console.log("-----", req.params.id);
      let check_if_interested_creator_exist = await InterestedCreator.findById(req.params.id);
      console.log("-----", check_if_interested_creator_exist, req.params);

      if (!check_if_interested_creator_exist)
         return res.send({
            statusCode: 404,
            data: null,
            message: null,
            error: `Request with ${req.params.id} doesn't exist`,
         });

      const status = req.body.status;
      if (status == "InProgress" || status == "Under Review" || status == "Document Processing" || status == "Complete") {
         if (status == "Under Review") {
            //send mail to creator with creds
            await sendConversionNotificationMailToCreator(check_if_interested_creator_exist.email, check_if_interested_creator_exist.fullname, "1234");
         }
         check_if_interested_creator_exist.processing_stage = status;
         await check_if_interested_creator_exist.save();
         return res.send({
            statusCode: 200,
            data: null,
            message: "Status Updated Successfully",
            error: null,
         });
      } else {
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: `Invalid Status ${status}`,
         });
      }
   } catch (error) {
      logger.error(`[${SuperAdminController} interestedCreatorSignup API response error:- ${error.message}]`);
      res.send({
         statusCode: 201,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getAllTransactionDetails = async (req, res) => {
   try {
      const startDate = new Date(`${req.query.date}T00:00:00.000+05:30`);
      const endDate = new Date(`${req.query.date}T23:59:59.999+05:30`);

      let fromIndicPay = await Transaction.find({
         createdAt: { $gte: startDate.toISOString(), $lte: endDate.toISOString() },
         status: "success",
         payment_received_from: "India-Online-Pay",
      });

      let totalAmountIndicPay = 0;
      let totalGstIndicPay = 0;
      let totalPlatformFeeIndicPay = 0;

      if(fromIndicPay.length>0){
         fromIndicPay.forEach((transaction) => {
            totalAmountIndicPay += transaction.amount;
            totalGstIndicPay += transaction.gst;
            totalPlatformFeeIndicPay += transaction.platform_fee;
         });
      }


      // let fromIndiaOnlinePay=await Transaction.find({
      //    createdAt: { $gte: startDate.toISOString(), $lte: endDate.toISOString() },
      //    status: "success",
      //    payment_received_from: "India-Online-Pay",
      // });

      let fromPayU = await Transaction.find({
         createdAt: { $gte: startDate.toISOString(), $lte: endDate.toISOString() },
         status: "success",
         payment_received_from: "PayU",
      });



      let totalAmountPayU = 0;
      let totalGstPayU = 0;
      let totalPlatformFeePayU = 0;

      if (fromPayU.length > 0) {
        
         fromPayU.forEach((transaction) => {
            totalAmountPayU += transaction.amount;
            totalGstPayU += transaction.gst;
            totalPlatformFeePayU += transaction.platform_fee;
         });
      }

      return res.status(200).json({
         message: "success",
         data: [
            {
               userAmount: totalAmountIndicPay,
               gst: totalGstIndicPay,
               platform: totalPlatformFeeIndicPay,
               amount: totalAmountIndicPay + totalGstIndicPay + totalPlatformFeeIndicPay,
               from: "India-Online-Pay",
            },
            {
               userAmount: totalAmountPayU,
               gst: totalGstPayU,
               platform: totalPlatformFeePayU,
               amount: totalAmountPayU + totalGstPayU + totalPlatformFeePayU,
               from: "PayU",
            },
         ],
      });
      //5662  -09
      //136   -08
      //2720  -07
      //2856 -06

      // return res.status(200).json({
      //    message: "success",
      //    data: {
      //       amount: 0,
      //       gst: 0,
      //       platform: 0,
      //    },
      // });
   } catch (error) {
      console.log("error", error);
      return res.status(400).json({ message: "error", data: null, error: error.message });
   }
};

module.exports.createWithdrawalRequest = async (req, res) => {
   try {
      let isCreatorExists = await CreatorEarning.findOne({ creator_id: req.body.creator_id });
      if (isCreatorExists) {
      
         let totalWithdrawAmount = req.body.withdraw_from_video + req.body.withdraw_from_chat + req.body.withdraw_from_ai;
         let creatorTotalAmount=isCreatorExists.earn_by_video_call+isCreatorExists.earn_by_message+isCreatorExists.earn_by_ai_message;
         let finalAmount = isCreatorExists.creator_earning - totalWithdrawAmount;
        if(totalWithdrawAmount>creatorTotalAmount){
          return res.status(400).json({ message: "error", data: null, error: "Insufficient Funds" });
        }else if(req.body.withdraw_from_video>isCreatorExists.earn_by_video_call){
          return res.status(400).json({ message: "withdraw_from_video can be only "+isCreatorExists.earn_by_video_call, data: null, error: "Insufficient Funds" });
        }else if(req.body.withdraw_from_chat>isCreatorExists.earn_by_message){
         return res.status(400).json({ message: "withdraw_from_chat can be only "+isCreatorExists.earn_by_message, data: null, error: "Insufficient Funds" });
        }else if(req.body.withdraw_from_ai>isCreatorExists.earn_by_ai_message){
         return res.status(400).json({ message: "withdraw_from_ai can be only "+isCreatorExists.earn_by_ai_message, data: null, error: "Insufficient Funds" });
        }else{
         let createWithdrawHistoryData = {
            creator_id: isCreatorExists.creator_id,
            withdraw_by_video_call: req.body.withdraw_from_video,
            withdraw_by_message: req.body.withdraw_from_chat,
            withdraw_by_ai_message: req.body.withdraw_from_ai,
            total_withdraw: req.body.withdraw_from_video + req.body.withdraw_from_chat + req.body.withdraw_from_ai - req.body.security_amount,
            total_security_amount: req.body.security_amount,
         };

         let createWithdrawHistory = CreatorWithdrawHistory.create(createWithdrawHistoryData);
         if (createWithdrawHistory) {
            let updateCreatorEarnings = await CreatorEarning.findOneAndUpdate(
               {
                  creator_id: isCreatorExists.creator_id,
               },
               {
                  $set: {
                     creator_earning: finalAmount,
                     earn_by_video_call: isCreatorExists.earn_by_video_call - req.body.withdraw_from_video,
                     earn_by_message: isCreatorExists.earn_by_message - req.body.withdraw_from_chat,
                     earn_by_ai_message: isCreatorExists.earn_by_ai_message - req.body.withdraw_from_ai,
                     total_security_amount_left: req.body.security_amount,
                     total_withdraw: 0,
                  },
               },
               {
                  new: true,
               },
            );

            if (updateCreatorEarnings) {
               return res.status(200).json({ statusCode: 200, message: "withdrawal request created successfully" });
            }
         }
         return res.status(400).json({ statusCode: 400, message: "failed to create withdrawal request" });
        }
      
      }
      return res.status(400).json({
         statusCode: 400,
         message: "no creator found to withdraw",
      });
   } catch (error) {
      console.log("error", error);
      return res.status(400).json({ message: "error", data: null, error: error.message });
   }
};
