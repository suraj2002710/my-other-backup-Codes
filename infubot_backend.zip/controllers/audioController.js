const AudioConnectivty = require("../models/AudioConnection");
const { Creator } = require("../models/Creator");
const VideoConnectivty = require("../models/VideoConnection");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { User } = require("../models/Users");
const { Wallet } = require("../models/Wallet");
const moment = require("moment");

const { storeCallNotification } = require("../services/notificationStore");

const logger = require("winston");

const AudioController = "AUDIO_CONTROLLER";

const admin = require("firebase-admin");
const { generateAgoraToken } = require("../services/generateAgoraToken");
const { v4: uuidv4 } = require("uuid");
const { random_user_profile } = require("../utilities/random_profile_images");
const {
  send_notification_to_creator_for_call_declined_by_user,
} = require("../notification_infra");

// const { config } = require("../queue_infra/redis_config");
// const io_redis = require("ioredis");
// const publisher = new io_redis();
// const redis_client = new io_redis();


/**
 * Handles user requests for audio connectivity with a creator.
 *
 * This function manages the process of a user requesting to connect with a creator via audio. It first
 * verifies the user's details and checks their wallet balance to ensure they have sufficient funds to
 * make the call based on the creator's set rate for audio calls. If the balance is sufficient, it generates
 * an Agora token for the audio call and creates an entry in the AudioConnectivity collection to track the
 * call status. It then sends a notification to the creator informing them of the incoming call request.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the user has insufficient balance, it sends a 400 status code with a message indicating
 *     insufficient balance.
 *   - If the notification is sent successfully to the creator, it sends a 200 status code with
 *     the Agora token and other call details.
 *   - If there is an error in sending the notification or during any other part of the process,
 *     it sends a 400 status code with the error message.
 *
 * @note
 *   The function assumes the presence of User, Wallet, Creator, CreatorBotSetting, and AudioConnectivity
 *   models. It also relies on external services like Agora for generating the audio call token and Firebase
 *   for sending notifications.
 */
module.exports.userRequestToAudioConnectivity = async (req, res, next) => {
  try {
    // console.log("Body", req.body)
    const get_creator_details_by_id = await Creator.findOne({
      email: req.body.creator_id,
    });

    if (!get_creator_details_by_id.is_logged_in) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator is not online",
        error: null,
      });
    }

    if (get_creator_details_by_id?.dnd_mode) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator do not disturb mode is on",
        error: null,
      });
    }

    const fetch_user_details = await User.findOne({
      email: req.body.user_id,
    });

    if (fetch_user_details) {
      const fetch_user_walet_balance = await Wallet.findOne({
        user_id: fetch_user_details.id,
      });

      if (fetch_user_walet_balance) {
        const fetch_creator_details = await Creator.findOne({
          email: req.body.creator_id,
        });
        const fetch_creator_bot_details = await CreatorBotSetting.findOne({
          creator_id: fetch_creator_details.id,
        });

        if (fetch_creator_bot_details) {
          if (
            fetch_user_walet_balance?.wallet_balance <
            fetch_creator_bot_details?.cost_audio_per_min
          ) {
            return res.status(400).json({
              statusCode: 400,
              data: null,
              message: "Insufficient Balance",
              error: "Insufficient Balance",
            });
          } else {
            let token = await generateAgoraToken(
              req.body.channel_room,
              req.body.uid,
              req.body.userAccount
            );

            let audio_connectivity = await AudioConnectivty.create({
              user_id: req.body.user_id,
              creator_id: req.body.creator_id,
              channel_room: req.body.channel_room,
              connection: "waiting",
            });

            // let creator = await Creator.findOne({ email: req.body.creator_id });
            const message = {
              // notification: {
              //   title: "Hey, Someone is calling you",
              //   body: "Hey, Someone is calling you",
              // },
              token: get_creator_details_by_id?.fcm_token,
              data: {
                type: "voice_call",
                appId: process.env.AGORA_APP_ID,
                uid: req.body.uid.toString(),
                voice_token: token,
                channel_room: req.body.channel_room,
                user_id: req.body.user_id,
                audio_id: audio_connectivity._id.toString(),
                username: req.body.user_name,
              },
            };

            // console.log("Message", message)

            admin
              .messaging()
              .send(message)
              .then((response) => {
                logger.info(
                  `[${AudioController}] userRequestToAudioConnectivity API response success`
                );
                storeCallNotification(
                  req.body.creator_id,
                  message?.data?.user_id,
                  get_creator_details_by_id?.id,
                  message?.data?.type,
                  message?.data?.username,
                  message?.data?.audio_id
                );
                return res.status(200).json({
                  statusCode: 200,
                  data: {
                    appId: process.env.AGORA_APP_ID,
                    uid: req.body.uid,
                    token: token,
                    channel_room: req.body.channel_room,
                  },
                  message: "Notification send successfully creator!",
                  error: null,
                });
              })
              .catch((error) => {
                return res.status(400).json({
                  statusCode: 400,
                  data: null,
                  message: null,
                  error: error,
                });
              });
          }
        }
      }
    }
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};

/**
 * Manages creator responses to audio call requests.
 *
 * This function handles the updates to the audio call status based on the creator's response to an audio call
 * request. It updates the AudioConnectivity collection with the creator's response, which includes the status
 * of the call (e.g., accepted, rejected, etc.) and the start time if the call is accepted. This information
 * is used to track and manage ongoing audio calls between users and creators.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the update is successful, it sends a 200 status code with a message indicating that
 *     the audio call response was received successfully.
 *   - If there is an error during the update process, it sends a 400 status code with the error message.
 *
 * @note
 *   The function assumes the presence of an AudioConnectivity model to track and manage audio calls.
 *   The function is typically triggered by a creator's action in response to an incoming audio call request.
 */

module.exports.creatorRespondToAudioCall = async (req, res, next) => {
  try {
    let updatedBody = req.body;

    if (!updatedBody?.connection) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Connection name missing",
        error: null,
      });
    }

    const connection_status = [
      "ongoing",
      "cancelled",
      "not_answered",
      "complete",
      "declined",
    ];

    if (!connection_status.includes(updatedBody?.connection)) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Invalid Connection Name",
        error: null,
      });
    }

    const find_audio_call_details = await AudioConnectivty.findById(
      req.body.id
    );
    find_audio_call_details.connection = updatedBody.connection;
    find_audio_call_details.start_time = updatedBody.start_time;
   await find_audio_call_details.save();

    return res.status(200).json({
      statusCode: 200,
      data: null,
      message: "Audio call response received",
      error: null,
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};

/**
 * Deletes all audio call logs for a specific creator.
 *
 * This function is responsible for deleting all audio call logs associated with a particular creator.
 * It first retrieves the details of the creator making the request and then proceeds to delete all
 * entries in the AudioConnectivity collection that are linked to this creator. This action is useful
 * for managing and clearing historical call data, particularly for privacy or data management purposes.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If all call logs are successfully deleted, it sends a 200 status code with a message indicating
 *     that all audio call logs were deleted successfully, along with the details of the deleted records.
 *   - If there is an error during the deletion process, it sends a 400 status code with the error message.
 *
 * @note
 *   The function assumes the presence of an AudioConnectivity model for tracking audio call logs.
 *   This action is irreversible, and caution should be exercised before deleting all call logs.
 */

module.exports.deleteAllCallLogs = async (req, res, next) => {
  try {
    const get_creator_details_by_id = await Creator.findById(req.creator.id);
    const delete_all_call_logs = await AudioConnectivty.deleteMany({
      creator_id: get_creator_details_by_id.email,
    });
    return res.status(200).json({
      statusCode: 200,
      data: delete_all_call_logs,
      message: "All Audio call logs deleted successfully",
      error: null,
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};

function calculateDuration(call) {
  const startTime = new Date(call.start_time);
  const endTime = new Date(call.updatedAt);

  if (isNaN(startTime.getTime()) || isNaN(endTime.getTime())) {
    return "00:00:00";
  }

  let durationInSeconds = (endTime - startTime) / 1000;

  if (isNaN(durationInSeconds) || durationInSeconds < 0) {
    return "00:00:00";
  }

  const hours = Math.floor(durationInSeconds / 3600);
  durationInSeconds %= 3600;
  const minutes = Math.floor(durationInSeconds / 60);
  const seconds = durationInSeconds % 60;

  return `${hours.toString().padStart(2, "0")}:${minutes
    .toString()
    .padStart(2, "0")}:${seconds.toFixed(0).padStart(2, "0")}`;
}

function formatRelativeDate(date) {
  return moment(date).calendar(null, {
    sameDay: "[Today]",
    nextDay: "[Tomorrow]",
    nextWeek: "dddd",
    lastDay: "[Yesterday]",
    lastWeek: "[Last] dddd",
    sameElse: "DD/MM/YYYY",
  });
}

/**
 * Retrieves combined audio and video call logs for a specific creator.
 *
 * This function fetches the call logs for both audio and video calls associated with a creator.
 * It first verifies the existence of the creator using the provided creator ID. If the creator is
 * found, it proceeds to fetch audio and video connectivity logs from the AudioConnectivity and
 * VideoConnectivity collections, respectively. The function also calculates the duration of each
 * call and formats it into a human-readable format (HH:MM:SS). It also fetches the name of the
 * user involved in each call and formats the date of the call for display purposes.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator exists and call logs are fetched successfully, it sends a 200 status code
 *     with the combined list of audio and video call logs.
 *   - If the creator does not exist, it sends a 400 status code with an error message indicating
 *     that the creator doesn't exist.
 *   - In case of an error during the process of fetching call logs, it sends a 400 status code
 *     with the error message.
 *
 * @note
 *   This function assumes the presence of AudioConnectivity and VideoConnectivity models for
 *   tracking call logs. It also uses moment.js for date formatting.
 */

module.exports.creatorCallLogs = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const creator = await Creator.findById(req.creator.id);
    if (!creator) {
      return res.status(400).send({ message: "Creator doesn't exist" });
    }

    // Aggregation pipeline for audio logs, removing the 'connection: "waiting"' filter to get all logs
    const audioLogsAggregation = AudioConnectivty.aggregate([
      { $match: { creator_id: creator.id } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: "$user_id",
          latestLog: { $first: "$$ROOT" },
          callCount: { $sum: 1 },
        },
      },
      { $skip: skip },
      { $limit: limit },
    ]);

    // Aggregation pipeline for video logs, similarly removing the 'connection: "waiting"' filter
    const videoLogsAggregation = VideoConnectivty.aggregate([
      { $match: { creator_id: creator.id } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: "$user_id",
          latestLog: { $first: "$$ROOT" },
          callCount: { $sum: 1 },
        },
      },
      { $skip: skip },
      { $limit: limit },
    ]);

    // Execute aggregations in parallel
    const [audioLogs, videoLogs] = await Promise.all([
      audioLogsAggregation,
      videoLogsAggregation,
    ]);

    // Combine logs by selecting the latest log per user across both audio and video
    const combinedLogsMap = {};
    [...audioLogs, ...videoLogs].forEach((log) => {
      if (
        !combinedLogsMap[log._id] ||
        combinedLogsMap[log._id].latestLog.createdAt < log.latestLog.createdAt
      ) {
        combinedLogsMap[log._id] = log;
      }
    });

    const combinedLogs = Object.values(combinedLogsMap);

    // Fetch user details
    const uniqueUserIds = combinedLogs.map((log) => log._id);
    const users = await User.find({ _id: { $in: uniqueUserIds } });
    const userMap = users.reduce((acc, user) => {
      acc[user.id] = `${user.first_name} ${user.last_name}`;
      return acc;
    }, {});

    // Map the logs to include user names and call counts
    const processedLogs = combinedLogs.map((log) => ({
      ...log.latestLog,
      user_profile_image: random_user_profile(),
      user_name: `${userMap[log.latestLog.user_id]} (${log.callCount})`,
      type: log.latestLog.hasOwnProperty("audio") ? "audio" : "video", // Adjust based on actual log structure
      duration: calculateDuration(log.latestLog),
      displayDate: formatRelativeDate(log.latestLog.createdAt),
    }));

    // Calculate if there's a next page
    const totalLogsCount = await Promise.all([
      AudioConnectivty.countDocuments({ creator_id: creator.id }),
      VideoConnectivty.countDocuments({ creator_id: creator.id }),
    ]);
    const totalLogs = totalLogsCount.reduce((acc, count) => acc + count, 0);
    const hasNextPage = page * limit < totalLogs;

    return res.status(200).json({
      statusCode: 200,
      data: processedLogs,
      nextPage: hasNextPage
        ? `${process.env.BASE_URL_FOR_IMAGES}api/creator-call-logs?page=${page + 1
        }&limit=${limit}`
        : null,
      message: "Combined audio and video call logs fetched successfully",
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      message: "Error fetching call logs",
      error: error.toString(),
    });
  }
};

module.exports.allCallLogsOfSpecificUser = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const creator = await Creator.findById(req.creator.id);
    if (!creator) {
      return res.status(400).json({
        message: "Creator doesn't exist",
      });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(400).json({
        message: "User doesn't exist",
      });
    }

    // Prepare queries for both collections
    const queries = [{ creator_id: creator.id, user_id: user.id }];

    // Define a function to perform the aggregation for a given collection
    const performAggregation = async (model, query, skip, limit) => {
      return model.aggregate([
        { $match: query },
        { $sort: { createdAt: -1 } },
        { $skip: skip },
        { $limit: limit },
      ]);
    };

    // Execute aggregations in parallel for both collections
    const audioLogsPromise = performAggregation(
      AudioConnectivty,
      queries[0],
      skip,
      limit
    );
    const videoLogsPromise = performAggregation(
      VideoConnectivty,
      queries[0],
      skip,
      limit
    );
    const [audioLogs, videoLogs] = await Promise.all([
      audioLogsPromise,
      videoLogsPromise,
    ]);

    // Combine the results
    const combinedLogs = [...audioLogs, ...videoLogs].sort(
      (a, b) => b.createdAt - a.createdAt
    );

    // Prepare the response
    const responseData = combinedLogs.map((log) => ({
      ...log,
      user_profile_image: random_user_profile(),
      user_name: `${user.first_name} ${user.last_name}`, // Use fetched user details
      type: "audio" in log ? "audio" : "video", // Distinguish based on log content
      duration: calculateDuration(log),
      displayDate: formatRelativeDate(log.createdAt),
    }));

    // Calculate hasNextPage (this assumes knowledge of the total number of logs, which requires an additional count query)
    const totalAudioLogsPromise = AudioConnectivty.countDocuments(queries[0]);
    const totalVideoLogsPromise = VideoConnectivty.countDocuments(queries[0]);
    const [totalAudioLogs, totalVideoLogs] = await Promise.all([
      totalAudioLogsPromise,
      totalVideoLogsPromise,
    ]);
    const totalLogs = totalAudioLogs + totalVideoLogs;
    const hasNextPage = page * limit < totalLogs;

    return res.status(200).json({
      statusCode: 200,
      data: responseData,
      nextPage: hasNextPage
        ? `${req.protocol}://${req.get("host")}${req.baseUrl}${req.path}?page=${page + 1
        }&limit=${limit}`
        : null,
      message: "Latest missed call logs fetched successfully",
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      message: "Error fetching missed call logs",
      error: error.toString(),
    });
  }
};

/**
 * Retrieves missed audio and video call logs for a specific creator.
 *
 * This function fetches the call logs for both audio and video calls that are marked as 'waiting',
 * indicating that they were missed by the creator. Initially, the existence of the creator is
 * verified using the provided creator ID. If the creator is found, the function then proceeds to
 * fetch missed call logs from AudioConnectivity and VideoConnectivity collections.
 *
 * The function also calculates the duration of each call and formats it into a human-readable
 * format (HH:MM:SS). Additionally, it fetches the name of the user involved in each call. The
 * date of the call is also formatted for display purposes.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator exists and missed call logs are fetched successfully, it sends a 200 status
 *     code with the combined list of audio and video call logs.
 *   - If the creator does not exist, it sends a 400 status code with an error message indicating
 *     that the creator doesn't exist.
 *   - In case of an error during the process of fetching call logs, it sends a 400 status code
 *     with the error message.
 *
 * @note
 *   This function assumes the presence of AudioConnectivity and VideoConnectivity models for
 *   tracking call logs. It also uses moment.js for date formatting.
 */

module.exports.missedCallLogs = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const creator = await Creator.findById(req.creator.id);
    if (!creator) {
      return res.status(400).send({
        message: "Creator doesn't exist",
      });
    }

    // Aggregation pipeline for audio logs
    const audioLogsAggregation = AudioConnectivty.aggregate([
      { $match: { creator_id: creator.id, connection: "waiting" } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: "$user_id",
          latestLog: { $first: "$$ROOT" },
          callCount: { $sum: 1 },
        },
      },
      { $skip: skip },
      { $limit: limit },
    ]);

    // Aggregation pipeline for video logs
    const videoLogsAggregation = VideoConnectivty.aggregate([
      { $match: { creator_id: creator.id, connection: "waiting" } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: "$user_id",
          latestLog: { $first: "$$ROOT" },
          callCount: { $sum: 1 },
        },
      },
      { $skip: skip },
      { $limit: limit },
    ]);

    // Execute aggregations in parallel
    const [audioLogs, videoLogs] = await Promise.all([
      audioLogsAggregation,
      videoLogsAggregation,
    ]);

    // Combine and deduplicate logs based on the latest call per user across both audio and video
    const combinedLogsMap = {};
    [...audioLogs, ...videoLogs].forEach((log) => {
      if (
        !combinedLogsMap[log._id] ||
        combinedLogsMap[log._id].latestLog.createdAt < log.latestLog.createdAt
      ) {
        combinedLogsMap[log._id] = log;
      }
    });

    const combinedLogs = Object.values(combinedLogsMap);

    // Fetch user details
    const uniqueUserIds = combinedLogs.map((log) => log._id);
    const users = await User.find({ _id: { $in: uniqueUserIds } });
    const userMap = users.reduce((acc, user) => {
      acc[user.id] = user.first_name + " " + user.last_name;
      return acc;
    }, {});

    // Map the logs to include user names and call counts
    const processedLogs = combinedLogs.map((log) => ({
      ...log.latestLog,
      user_profile_image: random_user_profile(),
      user_name: `${userMap[log.latestLog.user_id]} (${log.callCount})`,
      type: log.latestLog.connectionType, // Assuming there's a field to distinguish between audio/video
      duration: calculateDuration(log.latestLog),
      displayDate: formatRelativeDate(log.latestLog.createdAt),
    }));

    // Adjust totalLogsCount based on unique users, not total documents
    const totalUniqueUsers = combinedLogs.length;
    const hasNextPage = page * limit < totalUniqueUsers;

    return res.status(200).json({
      statusCode: 200,
      data: processedLogs,
      nextPage: hasNextPage
        ? `${process.env.BASE_URL_FOR_IMAGES}api/missed-call-logs?page=${page + 1
        }&limit=${limit}`
        : null,
      message: "Latest missed call logs fetched successfully",
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      message: "Error fetching missed call logs",
      error: error.toString(),
    });
  }
};

module.exports.missedCallLogsOfSpecificUser = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const creator = await Creator.findById(req.creator.id);
    if (!creator) {
      return res.status(400).send({
        message: "Creator doesn't exist",
      });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(400).send({
        message: "User doesn't exist",
      });
    }

    // Prepare queries for both collections
    const queries = [
      { creator_id: creator.id, user_id: user.id, connection: "waiting" },
    ];

    // Define a function to perform the aggregation for a given collection
    const performAggregation = async (model, query, skip, limit) => {
      return model.aggregate([
        { $match: query },
        { $sort: { createdAt: -1 } },
        { $skip: skip },
        { $limit: limit },
      ]);
    };

    // Execute aggregations in parallel for both collections
    const audioLogsPromise = performAggregation(
      AudioConnectivty,
      queries[0],
      skip,
      limit
    );
    const videoLogsPromise = performAggregation(
      VideoConnectivty,
      queries[0],
      skip,
      limit
    );
    const [audioLogs, videoLogs] = await Promise.all([
      audioLogsPromise,
      videoLogsPromise,
    ]);

    console.log("---->", audioLogs, videoLogs);

    // Combine the results
    const combinedLogs = [...audioLogs, ...videoLogs].sort(
      (a, b) => b.createdAt - a.createdAt
    );

    // Prepare the response
    const randomNumber = Math.floor(Math.random() * 30) + 1;
    const responseData = combinedLogs.map((log) => ({
      ...log,
      user_profile_image: random_user_profile(),
      user_name: `${user.first_name} ${user.last_name}`, // Use fetched user details
      type: "audio" in log ? "audio" : "video", // Distinguish based on log content
      duration: calculateDuration(log),
      displayDate: formatRelativeDate(log.createdAt),
    }));

    // Calculate hasNextPage (this assumes knowledge of the total number of logs, which requires an additional count query)
    const totalAudioLogsPromise = AudioConnectivty.countDocuments(queries[0]);
    const totalVideoLogsPromise = VideoConnectivty.countDocuments(queries[0]);
    const [totalAudioLogs, totalVideoLogs] = await Promise.all([
      totalAudioLogsPromise,
      totalVideoLogsPromise,
    ]);
    const totalLogs = totalAudioLogs + totalVideoLogs;
    const hasNextPage = page * limit < totalLogs;

    return res.status(200).json({
      statusCode: 200,
      data: responseData,
      nextPage: hasNextPage
        ? `${req.protocol}://${req.get("host")}${req.baseUrl}${req.path}?page=${page + 1
        }&limit=${limit}`
        : null,
      message: "Latest missed call logs fetched successfully",
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      message: "Error fetching missed call logs",
      error: error.toString(),
    });
  }
};

module.exports.creatorDeclineCall = async (req, res, next) => {
  try {
    console.log("---- Inside creatorDeclineCall", req.body);
    const { id, type } = req.body;

    if (!id) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Connection ID (connection_id) is required",
        error: null,
      });
    }

    if (!type == "audio" || !type == "video") {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Invalid Connection Type. Supported Types (audio/video)",
        error: null,
      });
    }

    if (type == "audio") {
      const find_audio_call_details = await AudioConnectivty.findById(id);

      console.log("Audio Call Details", find_audio_call_details);

      if (!find_audio_call_details) {
        return res.status(400).json({
          statusCode: 400,
          data: null,
          message: "Audio call not found",
          error: null,
        });
      }

      find_audio_call_details.connection = "declined";
      find_audio_call_details.declined_by = "creator";
     await find_audio_call_details.save();

      const creator_id = find_audio_call_details.creator_id
      // console.log("------- SETTING CREATOR AS AVAILABLE IN REDIS", `creator:${creator_id}:call_status`)
      // const set_creator_as_busy = await redis_client.set(`creator:${creator_id}:call_status`, 'available');
      // console.log("--------------------------------------------------------")

      // publisher.publish(
      //   "creator_declined_the_call_sub",
      //   JSON.stringify({
      //     data: req.body,
      //     connectivity: find_audio_call_details,
      //   })
      // );

      return res.status(200).json({
        statusCode: 200,
        data: null,
        message: "Call Declined Successfully by Creator",
        error: null,
      });
    } else if (type == "video") {
      const find_video_call_details = await VideoConnectivty.findById(id);

      console.log("Video Call Details", find_video_call_details);

      if (!find_video_call_details) {
        return res.status(400).json({
          statusCode: 400,
          data: null,
          message: "Audio call not found",
          error: null,
        });
      }

      find_video_call_details.connection = "declined";
      find_video_call_details.declined_by = "creator";
      await find_video_call_details.save();

      // const creator_id = find_video_call_details.creator_id
      // console.log("------- SETTING CREATOR AS AVAILABLE IN REDIS", `creator:${creator_id}:call_status`)
      // const set_creator_as_busy = await redis_client.set(`creator:${creator_id}:call_status`, 'available');
      // console.log("--------------------------------------------------------")

      // publisher.publish(
      //   "creator_declined_the_call_sub",
      //   JSON.stringify({
      //     data: req.body,
      //     connectivity: find_video_call_details,
      //   })
      // );

      return res.status(200).json({
        statusCode: 200,
        data: null,
        message: "Call Declined Successfully by Creator",
        error: null,
      });
    }
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};

module.exports.userDeclinedCall = async (req, res, next) => {
  try {
    const { id, type } = req.body;

    if (!id) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Connection ID (connection_id) is required",
        error: null,
      });
    }

    if (!type == "audio" || !type == "video") {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Invalid Connection Type. Supported Types (audio/video)",
        error: null,
      });
    }

    if (type == "audio") {
      const find_audio_call_details = await AudioConnectivty.findById(id);
      if (!find_audio_call_details) {
        return res.status(400).json({
          statusCode: 400,
          data: null,
          message: "Audio call not found",
          error: null,
        });
      }

      find_audio_call_details.connection = "declined";
      find_audio_call_details.declined_by = "user";
      await find_audio_call_details.save();

      const fetch_creator_details = await Creator.findOne({
        _id: find_audio_call_details.creator_id,
      });

      if (fetch_creator_details) {
        const notify =
          await send_notification_to_creator_for_call_declined_by_user(
            fetch_creator_details,
            find_audio_call_details,
            "audio"
          );
        if (notify) {
          return res.status(200).json({
            statusCode: 200,
            data: find_audio_call_details,
            message: "Audio Call Declined Successfully by User",
            error: null,
          });
        } else {
          return res.status(400).json({
            statusCode: 400,
            data: find_audio_call_details,
            message: "Unable to decline audio call",
            error: null,
          });
        }
      }
    } else if (type == "video") {
      const find_video_call_details = await VideoConnectivty.findById(id);

      if (!find_video_call_details) {
        return res.status(400).json({
          statusCode: 400,
          data: null,
          message: "Audio call not found",
          error: null,
        });
      }

      find_video_call_details.connection = "declined";
      find_video_call_details.declined_by = "user";
     await find_video_call_details.save();

      const fetch_creator_details = await Creator.findOne({
        _id: find_video_call_details.creator_id,
      });

      if (fetch_creator_details) {
        const notify =
          await send_notification_to_creator_for_call_declined_by_user(
            fetch_creator_details,
            find_video_call_details,
            "audio"
          );
        if (notify) {
          return res.status(200).json({
            statusCode: 200,
            data: find_video_call_details,
            message: "Video Call Declined Successfully by User",
            error: null,
          });
        } else {
          return res.status(400).json({
            statusCode: 400,
            data: find_video_call_details,
            message: "Unable to decline video call",
            error: null,
          });
        }
      }
    }
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};
