const VideoConnectivty = require("../models/VideoConnection");
const { Creator } = require("../models/Creator");
const { User } = require("../models/Users");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { Wallet } = require("../models/Wallet");
const { storeCallNotification } = require("../services/notificationStore")


const admin = require("firebase-admin");
const { generateAgoraToken } = require("../services/generateAgoraToken");



/**
 * Initiates a request for video connectivity between a user and a creator.
 *
 * This function handles the process of initiating a video call between a user and a creator. It takes the user's ID,
 * creator's ID, channel room name, and start time as input. The function then creates a record for the video connectivity
 * request and generates a token for the Agora service to facilitate the video call. Additionally, it sends a notification
 * to the creator indicating that a user is attempting to connect via video call.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the notification is successfully sent and the video call setup is initiated, it sends a 200 status code with the Agora
 *     app ID, user ID (uid), token, and channel room name, along with a success message.
 *   - If there is a failure in sending the notification or generating the token, it sends a 400 status code with an error message.
 *   - If there is any other error during the process, it sends a 400 status code with the error message.
 *
 * @note
 *   The function assumes the use of Agora for video call services. The generation of an Agora token is crucial for the video call
 *   connectivity. The success of this function is key for enabling real-time video communication between users and creators, making
 *   it an essential feature of the application. The notification sent to the creator plays a critical role in alerting them about
 *   the incoming video call request.
 */

module.exports.userRequestToVideoConnectivity = async (req, res, next) => {
  try {

    const get_creator_details_by_id = await Creator.findOne({
      email : req.body.creator_id
    });

      
    if(!get_creator_details_by_id.is_logged_in){
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator is not online",
        error: null,
      });
    }


    if(get_creator_details_by_id?.dnd_mode){
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator do not disturb mode is on",
        error: null,
      });
    }


    const fetch_user_details = await User.findOne({
      email : req.body.user_id
    });

    if(fetch_user_details){
      const fetch_user_walet_balance = await Wallet.findOne({
        user_id : fetch_user_details.id
      })

      if(fetch_user_walet_balance){
        const fetch_creator_details = await Creator.findOne({
          email : req.body.creator_id
        })
        const fetch_creator_bot_details = await CreatorBotSetting.findOne({
          creator_id : fetch_creator_details.id
        });

        if(fetch_creator_bot_details){
          if(fetch_user_walet_balance?.wallet_balance < fetch_creator_bot_details?.cost_video_per_min){
            return res.status(400).json({
              statusCode: 400,
              data: null,
              message: "Insufficient Balance",
              error: "Insufficient Balance",
            });
          } else{
            let video_connectivity = await VideoConnectivty.create({
              user_id: req.body.user_id,
              creator_id: req.body.creator_id,
              channel_room: req.body.channel_room,
              connection: "waiting",
              start_time: req.body.start_time,
            });
        
            let token = await generateAgoraToken(req.body.channel_room, req.body.uid);

            const message = {
              // notification: {
              //   title: "Hey, Someone is calling you",
              //   body: "Hey, Someone is calling you",
              // },
              token: get_creator_details_by_id.fcm_token,
              data: {
                type: "video_call",
                appId: process.env.AGORA_APP_ID,
                uid: req.body.uid.toString(),
                video_token: token,
                channel_room: req.body.channel_room,
                user_id: req.body.user_id,
                video_id: video_connectivity._id.toString(),
                username: req.body.user_name,
              },
            };

            // console.log("Video Message", message)
        
            admin
              .messaging()
              .send(message)
              .then((response) => {
                // console.log("Response", response)
                storeCallNotification(req.body.creator_id, message?.data?.user_id, get_creator_details_by_id?.id, message?.data?.type, message?.data?.username,message?.data?.video_id)
        
                return res.status(200).json({
                  statusCode: 200,
                  data: {
                    appId: process.env.AGORA_APP_ID,
                    uid: req.body.uid,
                    token: token,
                    channel_room: req.body.channel_room,
                  },
                  message: "Notification send successfully!",
                  error: null,
                });
              })
              .catch((error) => {
                return res.status(400).json({
                  statusCode: 400,
                  data: null,
                  message: null,
                  error: error,
                });
              });
          }
        }
      }
    } 
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};

/**
 * Handles a creator's response to a video call request.
 *
 * This function processes the response of a creator to an incoming video call request. It takes the video call request ID,
 * the creator's response (accept or reject), and the start time of the call (if accepted) as input. The function then updates
 * the video call request details in the database according to the creator's response.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the video call response is successfully recorded, it sends a 200 status code with a message indicating that the video
 *     call response was received successfully.
 *   - If there is an error during the process, it sends a 400 status code with the error message.
 *
 * @note
 *   This function is critical for updating the status of a video call request based on the creator's decision to accept or reject
 *   the call. The proper handling of this response is essential for facilitating the communication process between the user and
 *   the creator, thereby enhancing the user experience by providing real-time interaction capabilities.
 */

module.exports.creatorRespondToVideoCall = async (req, res, next) => {
  try {
    let updatedBody = req.body;

    const find_video_call_details = await VideoConnectivty.findById(req.body.id);
    find_video_call_details.connection = updatedBody.connection;
    find_video_call_details.start_time = updatedBody.start_time;
    await find_video_call_details.save()

    return res.status(200).json({
      statusCode: 200,
      data: null,
      message: "Video call response recieved",
      error: null,
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};


/**
 * Retrieves the video call logs of a creator.
 *
 * This function fetches the history of video calls made by a specific creator. It uses the creator's ID to retrieve all related
 * video call records. The function calculates the duration of each call and formats it in the HH:MM:SS format. The call logs
 * include details such as start time, end time, and duration of each call.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the video call logs are successfully retrieved, it sends a 200 status code with the call logs data.
 *   - If the creator does not exist or there is an error during the process, it sends a 400 status code with the error message.
 *
 * @note
 *   This function is crucial for providing creators with insights into their video call history, enabling them to track their
 *   interactions and manage their time more effectively. It enhances the transparency and accountability of the video calling
 *   feature on the platform.
 */

module.exports.creatorVideoLogs = async (req, res, next) => {
  try {
    const get_creator_details_by_id = await Creator.findById(req.creator.id);
    if (!get_creator_details_by_id) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: null,
        error: "Creator Doesn't exist",
      });
    }

    let video_connectivity = await VideoConnectivty.find({
      creator_id: get_creator_details_by_id.email
    });

    // Calculate the duration for each call and format it as HH:MM:SS
    const updatedData = video_connectivity.map(call => {
      const startTime = new Date(call.start_time);
      const endTime = new Date(call.updatedAt);
      let durationInSeconds = (endTime - startTime) / 1000;
      
      const hours = Math.floor(durationInSeconds / 3600);
      durationInSeconds %= 3600;
      const minutes = Math.floor(durationInSeconds / 60);
      const seconds = durationInSeconds % 60;

      const formattedDuration = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toFixed(0).padStart(2, '0')}`;

      return {
        ...call.toObject(), // Convert Mongoose document to a plain object
        duration: formattedDuration // Add the formatted duration to the call object
      };
    });

    return res.status(200).json({
      statusCode: 200,
      data: updatedData,
      message: "Video call logs fetched successfully",
      error: null,
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error.toString(),
    });
  }
};




module.exports.deleteAllVideoLogs = async (req, res, next) => {
  try {
    const delete_all_call_logs = await VideoConnectivty.deleteMany({})
    return res.status(200).json({
      statusCode: 200,
      data: null,
      message: "All Video call logs deleted successfully",
      error: null,
    });
  } catch (error) {
    return res.status(400).json({
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    });
  }
};
