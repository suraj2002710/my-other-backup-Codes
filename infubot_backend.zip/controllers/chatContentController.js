const logger = require("winston");
const { Creator } = require("../models/Creator");
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const ChatContentController = "CHAT_CONTENT_CONTROLLER";



const s3 = new S3Client({
  region: process.env.AWS_S3_REGION,
  credentials: {
    accessKeyId: process.env.AWS_KEY,
    secretAccessKey: process.env.AWS_SECRET,
  },
});

async function generate_presigned_url(key) {
  const params = {
    Bucket: "influbot",
    Key: key,
    ResponseContentDisposition: "inline",
  };

  try {
    const command = new GetObjectCommand(params);
    return await getSignedUrl(s3, command, { expiresIn: 60 * 720 });
  } catch (error) {
    throw error;
  }
}

module.exports.uploadVoiceMessage = async (req, res) => {
  try {
    console.log("Voice File", req.file);
    if (!req.file) {
      // If no file is uploaded, send a 400 Bad Request response
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "No voice message uploaded.",
        error: "Bad Request",
      });
    }

    let creator = await Creator.findById(req.creator.id);

    if (!creator) {
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    // If a file is uploaded successfully
    const { key } = req.file;
    logger.info(`[${ChatContentController}] Voice message uploaded successfully, File Key: ${key}`);
    res.status(200).json({
      statusCode: 200,
      data: {
        id: key,
      },
      message: "Voice message uploaded successfully.",
      error: null,
    });
  } catch (error) {
    // Log the error and send a 500 Internal Server Error response
    logger.error(`[${ChatContentController}] Upload voice message error: ${error.message}`);
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: SOMETHING_WENT_WRONG, // Use a constant for the message
      error: error.message,
    });
  }
};

module.exports.uploadChatImage = async (req, res) => {
  try {
    console.log("Image File", req.file);
    if (!req.file) {
      // If no file is uploaded, send a 400 Bad Request response
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "No image uploaded.",
        error: "Bad Request",
      });
    }

    let creator = await Creator.findById(req.creator.id);

    if (!creator) {
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    // If a file is uploaded successfully
    const { key } = req.file;
    logger.info(`[${ChatContentController}] Image uploaded successfully, File Key: ${key}`);
    res.status(200).json({
      statusCode: 200,
      data: {
        id: key,
      },
      message: "Image uploaded successfully.",
      error: null,
    });
  } catch (error) {
    // Log the error and send a 500 Internal Server Error response
    logger.error(`[${ChatContentController}] Upload image error: ${error.message}`);
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: SOMETHING_WENT_WRONG, // Use a constant for the message
      error: error.message,
    });
  }
};

module.exports.uploadChatVideo = async (req, res) => {
  try {
    console.log("Video File", req.file);
    if (!req.file) {
      // If no file is uploaded, send a 400 Bad Request response
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "No video uploaded.",
        error: "Bad Request",
      });
    }

    let creator = await Creator.findById(req.creator.id);

    if (!creator) {
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    // If a file is uploaded successfully
    const { key } = req.file;
    logger.info(`[${ChatContentController}] Video uploaded successfully, File Key: ${key}`);
    res.status(200).json({
      statusCode: 200,
      data: {
        id: key,
      },
      message: "Video uploaded successfully.",
      error: null,
    });
  } catch (error) {
    // Log the error and send a 500 Internal Server Error response
    logger.error(`[${ChatContentController}] Upload video error: ${error.message}`);
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: SOMETHING_WENT_WRONG, // Use a constant for the message
      error: error.message,
    });
  }
};


module.exports.generatePresignedUrlForImage = async (req, res, next) => {
  try {

    const {key} = req.body;

    let creator = await Creator.findById(req.creator.id);

    if (!creator) {
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    const presigned_url = await generate_presigned_url(key);
    if(presigned_url){
      res.status(200).json({
        statusCode: 200,
        data: {
          id: presigned_url,
        },
        message: "Presigned URL Generated Successfully",
        error: null,
      });
    }else{
      res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Presigned URL Generation Failed",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${ChatContentController} getCreatorContentGallery API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};