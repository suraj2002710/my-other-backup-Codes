const { SOMETHING_WENT_WRONG } = require("../constant");
const { Orders } = require("../models/Orders");
const { BaseRates } = require("../models/BaseRate");
const { Creator } = require("../models/Creator");
const { User } = require("../models/Users");
const {
  generatePaymentLink,
  getOrderStatus,
} = require("../payment_gateways/cashfree");
const { generateStripePaymentLink } = require("../payment_gateways/stripe");
const { generatePhonePayPaymentLink } = require("../payment_gateways/phonepay");
const { isNumber } = require("lodash");
// const redis = require("../queue_infra/redis_connection");

const logger = require("winston");
const orderController = "ORDER_CONTROLLER";

module.exports.createOrder = async (req, res, next) => {
  try {
    const { gross_amount, creator_username, gateway } = req.body;
    // console.log("Body", req.body)

    if (!gross_amount && !creator_username) {
      return res.send({
        statusCode: 400,
        data: null,
        message: "Required field is missing",
        error: null,
      });
    }

    if (!gross_amount > 0 && isNumber(gross_amount)) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Please enter balance properly",
        error: true,
      });
    }

    const user_id = req.user.id;
    const fetchUser = await User.findOne({ _id: req.user.id });

    if (!fetchUser) {
      return res.send({
        statusCode: 400,
        data: null,
        message: `User doesn't exist with id ${req.user.id}`,
        error: null,
      });
    }

    // console.log("User Details", fetchUser, req.user.id)
    const creator_details = await Creator.findOne({
      username: creator_username,
    });

    if (!creator_details) {
      return res.send({
        statusCode: 400,
        data: null,
        message: `Creator doesn't exist with id ${creator_username}`,
        error: null,
      });
    }

    const timestamp = Date.now().toString();

    const order_id =
      "influbot" + "-" + timestamp + "-" + fetchUser.last_name.substring(1);

    console.log("order_id",order_id)

    // const supported_gateways = ["payu", "stripe"];
    // if (supported_gateways.includes(gateway)) {
      const order = await Orders.create({
        gross_amount: gross_amount,
        creator_id: creator_details.id,
        creator_username: creator_username,
        order_id: order_id,
        user_id: user_id,
        payment_gateway: "cashfree",
      });
      logger.info(`[${orderController} Create Order  API response success]`);
      res.send({
        statusCode: 201,
        data: order,
        message: "Order  created successfully",
        error: null,
      });
    // } else {
    //   return res.send({
    //     statusCode: 200,
    //     data: null,
    //     message: `Payment Gateway ${gateway} is not supported`,
    //     error: null,
    //   });
    // }

    // let new_order;

    // if(supported_gateways.includes(gateway)){
    //   if(gateway == "cashfree"){
    //       new_order = {
    //         gross_amount: gross_amount,
    //         creator_id: creator_details.id,
    //         creator_username: creator_username,
    //         order_id: order_id,
    //         user_id: user_id,
    //         payment_gateway : "cashfree"
    //       };
    //       const order = await Orders.create(new_order);
    //       order.save();
    //       payment_link = await generatePaymentLink(new_order,fetchUser);
    //       new_order.payment_link = payment_link
    //     }else if(gateway == "stripe"){
    //       new_order = {
    //         gross_amount: gross_amount,
    //         creator_id: creator_details.id,
    //         creator_username: creator_username,
    //         order_id: order_id,
    //         user_id: user_id,
    //         payment_gateway : "stripe"
    //       };
    //       payment_link = await generateStripePaymentLink(new_order,fetchUser);
    //       // console.log("Payment Link", payment_link)
    //       new_order.payment_link = payment_link
    //     }else if(gateway == "phonepay"){
    //       new_order = {
    //         gross_amount: gross_amount,
    //         creator_id: creator_details.id,
    //         creator_username: creator_username,
    //         order_id: order_id,
    //         user_id: user_id,
    //         payment_gateway : "phonepay"
    //       };
    //       payment_link = await generatePhonePayPaymentLink(new_order,fetchUser);
    //       // console.log("Payment Link", payment_link)
    //       new_order.payment_link = payment_link
    //     }
    // }else{
    //   return res.send({
    //         statusCode: 200,
    //         data: null,
    //         message: `Payment Gateway ${gateway} is not supported`,
    //         error: null,
    //       });
    // }

    // let payment_link;
    // if(gateway == "cashfree"){
    //   const new_order = {
    //     gross_amount: gross_amount,
    //     creator_id: creator_details._id,
    //     creator_username: creator_username,
    //     order_id: order_id,
    //     user_id: user_id,
    //     payment_gateway : "cashfree"
    //   };
    //   const order = await Orders.create(new_order);
    //   order.save();
    //   payment_link = await generatePaymentLink(new_order,fetchUser);
    //   new_order.payment_link = payment_link
    // }else{
    //   return res.send({
    //     statusCode: 200,
    //     data: null,
    //     message: `Payment Gateway ${gateway} is not supported`,
    //     error: null,
    //   });
    // }

  } catch (error) {
    logger.error(
      `[${orderController} Create Order API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.deleteOrderHistory = async (req, res, next) => {
  try {
    const fetch_user_details = await User.findById(req.user.id);
    if (!fetch_user_details) {
      res.send({
        statusCode: 400,
        data: null,
        message: null,
        error: "User doesn't exist",
      });
    }
    let order = await Orders.deleteMany({ user_id: req.user.id });
    logger.info(
      `[${orderController} deleteOrderHistory  API response success]`
    );
    res.send({
      statusCode: 201,
      data: order,
      message: "Order History Cleared successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${orderController} getOrderHistory API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.generateOrderAmount = async (req, res, next) => {
  try {
    // console.log("Payload", req.body)
    const { gross_amount, creator_username, gateway } = req.body;

    if (gross_amount < 0 && !isNumber(gross_amount)) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Please enter balance properly",
        error: true,
      });
    }

    const fetch_base_rates = await BaseRates.find({});
    const rates = fetch_base_rates[0];

    const platform_fees = gross_amount * (rates.platform_fee / 100);
    const gst = gross_amount * (rates.gst / 100);
    const total_fee = gross_amount + platform_fees + gst;

    // console.log("--",platform_fees,gst)

    const response_data = {
      ...req.body,
      platform_fees,
      gst,
      total_fee,
    };

    res.send({
      statusCode: 200,
      data: response_data,
      message: "Order Amount Generated Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${orderController} generateOrderAmount API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getOrderHistory = async (req, res, next) => {
  try {
    const user_id = req.user.id;
    const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not specified
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page if not specified
    const skip = (page - 1) * limit;

    const totalOrders = await Orders.countDocuments({ user_id });
    const orders = await Orders.find({ user_id }).skip(skip).limit(limit);

    // Determine if there's a next page
    const hasNextPage = page * limit < totalOrders;
    const nextPageUrl = hasNextPage
      ? `${req.protocol}://${req.get('host')}${req.baseUrl}${req.path}?page=${page + 1}&limit=${limit}`
      : null;

    logger.info(`[${orderController} getOrderHistory API response success]`);
    res.send({
      statusCode: 200,
      data: orders,
      nextPage: nextPageUrl,
      message: "Order history fetched successfully!",
      error: null,
    });
  } catch (error) {
    logger.error(`[${orderController} getOrderHistory API response error:- ${error.message}]`);
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

// //With Redis Caching
// module.exports.getOrderHistory = async (req, res, next) => {
//   try {
//     const user_id = req.user.id;
//     const page = parseInt(req.query.page, 10) || 1;
//     const limit = parseInt(req.query.limit, 10) || 10;
//     const skip = (page - 1) * limit;

//     const redisKey = `orderHistory:${user_id}:page:${page}:limit:${limit}`;

//     // Attempt to retrieve cached order history
//     const cachedOrders = await redis.get(redisKey);
//     if (cachedOrders) {
//       const { orders, nextPageUrl } = JSON.parse(cachedOrders);
//       return res.send({
//         statusCode: 200,
//         data: orders,
//         nextPage: nextPageUrl,
//         message: "Order history fetched successfully from cache!",
//         error: null,
//       });
//     }

//     const totalOrders = await Orders.countDocuments({ user_id });
//     const orders = await Orders.find({ user_id }).skip(skip).limit(limit);

//     // Determine if there's a next page
//     const hasNextPage = page * limit < totalOrders;
//     const nextPageUrl = hasNextPage
//       ? `${req.protocol}://${req.get("host")}${req.baseUrl}${req.path}?page=${
//           page + 1
//         }&limit=${limit}`
//       : null;

//     // Cache the fetched order history along with the next page URL
//     const cacheValue = { orders, nextPageUrl };
//     await redis.set(redisKey, JSON.stringify(cacheValue), "EX", 600); // Cache for 10 minutes

//     logger.info(`[getOrderHistory API response success]`);
//     res.send({
//       statusCode: 200,
//       data: orders,
//       nextPage: nextPageUrl,
//       message: "Order history fetched successfully!",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[getOrderHistory API response error:- ${error.message}]`);
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.getCashfreeOrderStatus = async (req, res, next) => {
  try {
    const { order_id } = req.params;
    const check_order_status = await Orders.findOne({
      order_id,
    });
    // console.log("Order Status", check_order_status);
    res.send({
      statusCode: 200,
      data: check_order_status,
      message: "Order Status Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${orderController} getOrderStatus API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
