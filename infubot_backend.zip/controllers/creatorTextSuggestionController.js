const { CreatorTextSuggestion } = require("../models/CreatorTextSuggestion");

const logger = require("winston");

const CreatorTextSuggestionController = "CREATOR_TEXT_SUGGESTION_CONTROLLER";

module.exports.getCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion = await CreatorTextSuggestion.find({});
    logger.info(
      `[${CreatorTextSuggestionController} getCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_text_suggestion,
      message: "Get all creator text suggestion succssully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} getCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getActiveCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion = await CreatorTextSuggestion.find({
      is_active: true,
    });
    logger.info(
      `[${CreatorTextSuggestionController} getActiveCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_text_suggestion,
      message: "Active creator text suggestions captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} getActiveCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion = await CreatorTextSuggestion.create(
      req.body
    );
    logger.info(
      `[${CreatorTextSuggestionController} addCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_text_suggestion,
      message: "Creator text suggestion created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} addCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.bulkAdditionCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion = await CreatorTextSuggestion.insertMany(
      req.body
    );
    logger.info(
      `[${CreatorTextSuggestionController} bulkAdditionCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_text_suggestion,
      message: "Creator text suggestion created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} bulkAdditionCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.updateCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion =
      await CreatorTextSuggestion.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });
    logger.info(
      `[${CreatorTextSuggestionController} updateCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_text_suggestion,
      message: "Creator text suggestion updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} updateCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.deleteCreatorTextSuggestion = async (req, res, next) => {
  try {
    const creator_text_suggestion =
      await CreatorTextSuggestion.findByIdAndRemove(req.params.id);
    logger.info(
      `[${CreatorTextSuggestionController} deleteCreatorTextSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_text_suggestion,
      message: "Creator text suggestion deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorTextSuggestionController} deleteCreatorTextSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: "Creator Link suggestion deleted successfully",
    });
  }
};
