const { CreatorAIIndexer } = require("../models/creatorIndexer");
const { Creator } = require("../models/Creator");
const {indexCreatorDocument} = require("../ai_infra/indexer");

const logger = require("winston");

const CreatorAIDocumentIndexer = "CREATOR_AI_DOCUMENT_INDEXER";

/**
 * Retrieves all documents related to creators.
 *
 * This function fetches all the documents from the CreatorAIIndexer collection. 
 * It is designed to retrieve and return every document associated with creators, 
 * which includes their details and indexed data for AI processing.
 *
 * @returns {void}
 *   - If the documents are successfully fetched, it sends a 200 status code with the retrieved document data.
 *   - If there is an error during the retrieval process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a CreatorAIIndexer model representing the documents related to creators.
 *   It is used for AI processing and other related functionalities.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.getAllCreatorDocuments = async (req, res, next) => {
  try {
    const creator_document_data = await CreatorAIIndexer.find({});
    logger.info(
      `[${CreatorAIDocumentIndexer} getAllCreatorDocuments API response success]`
    );
    return res.send({
        statusCode: 200,
        data: creator_document_data,
        message: "All Creator Document Data Fetched Successfully",
        error: null,
      });
  } catch (error) {
    logger.error(
      `[${CreatorAIDocumentIndexer} getAllCreatorDocuments API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};




/**
 * Handles the indexing of a document for a creator.
 *
 * This function is responsible for processing the indexing of a document uploaded by a creator. 
 * It verifies the existence of the creator, checks if a document has already been indexed for them, 
 * and then proceeds to index the new document. The process includes saving the document's details 
 * in the CreatorAIIndexer collection and initiating the indexing process.
 *
 * @returns {void}
 *   - If the creator does not exist, it returns a 400 status code with a message indicating the issue.
 *   - If the creator already has an indexed document, it returns a 400 status code with a message stating the limitation.
 *   - On successful indexing of the document, it returns a 200 status code with the indexed document details.
 *   - If the creator ID is not provided, it returns a 400 status code with an "Invalid Token" message.
 *   - On failure due to other errors, it returns a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of Creator and CreatorAIIndexer models.
 *   It handles file upload and requires the file and body data to be present in the request.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.indexDocument = async (req, res, next) => {
  try {
    if (req.creator.id && req.file && req.body) {
      // Check if a file is uploaded
      if (req.file) {
        const creator = await Creator.findById(req.creator.id);
        if (!creator) {
          return res.json({
            statusCode: 400,
            data: creator,
            message: `Creator with id ${req.creator.id} doesn't exist`,
            error: null,
          });
        }

        const get_creator_document = await CreatorAIIndexer.findOne({
          creator_id : creator.id
        })


        if(get_creator_document){
          return res.json({
            statusCode: 400,
            data: get_creator_document,
            message: `Creator Document already exist. Allowing only one document for each creator for now`,
            error: null,
          });
        }



        const {document_name, metadata} = req.body;
        const { filename, destination } = req.file;

        const index_document = new CreatorAIIndexer({
          creator_id: req.creator.id,
          document_name,
          document_id: destination + filename,
          metadata
        });

        await index_document.save();

        index_document.document_id = process.env.BASE_URL_FOR_IMAGES + index_document.document_id

        await indexCreatorDocument(
          destination + filename,
          filename,
          req.creator.id
        );
        logger.info(`Document indexing completed for ${filename}`);

        index_document.status = process.env.BASE_URL_FOR_IMAGES + "api/creator-indexer/index/" + index_document.id + "/status"
        res.send({
          statusCode: 200,
          data: index_document,
          message: "Creator Document Indexing Process Completed",
          error: null,
        });

        // Logging success
        logger.info(`[${CreatorAIDocumentIndexer} indexCreatorDocument API response success]`);

        
      }
    } else {
      if (!req.creator.id) {
        res.send({
          statusCode: 400,
          message: "Invalid Token",
          error: null,
        });
      }
    }
  } catch (error) {
    // Logging error
    logger.error(`[${CreatorAIDocumentIndexer} indexCreatorDocument API response error:- ${error.message}]`);
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Handles the deletion of a creator's indexed document.
 *
 * This function is responsible for deleting a document that has been previously indexed for a creator.
 * It first checks the existence of the creator and then proceeds to delete the document from the 
 * CreatorAIIndexer collection if it exists.
 *
 * @returns {void}
 *   - If the creator does not exist or has no indexed document, it returns a 400 status code with a relevant message.
 *   - On successful deletion of the document, it returns a 200 status code with a success message.
 *   - If the creator ID is not provided, it returns a 400 status code with an "Invalid Token" message.
 *   - On failure due to other errors, it returns a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of Creator and CreatorAIIndexer models.
 *   It requires the creator's ID to be present in the request.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.deleteCreatorDocument = async (req, res, next) => {
  try {

    if (!req.creator.id) {
      // Check if a file is uploaded
        const creator = await Creator.findById(req.creator.id);
        if (!creator) {
          return res.json({
            statusCode: 400,
            data: creator,
            message: `No Documents Exist`,
            error: null,
          });
        }

        const index_document = await CreatorAIIndexer.deleteOne({
          creator_id: req.creator.id,
        });

        return res.send({
          statusCode: 200,
          message: "Creator Document Deleted Successfully",
          error: null,
        });
    }
  } catch (error) {
    // Logging error
    logger.error(
      `[${CreatorAIDocumentIndexer} updateCreatorProfile API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



/**
 * Retrieves the indexing status of a specific creator's document.
 *
 * This function fetches the status of a document's indexing process for a creator. It uses the document ID
 * to look up the status in the CreatorAIIndexer collection.
 *
 * @returns {void}
 *   - If the document is found, it returns a 200 status code with the document's data and a success message.
 *   - If the document ID is not found or other errors occur, it returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of the CreatorAIIndexer model.
 *   The document ID is expected to be passed as a parameter in the request.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.indexingDocumentStatus = async (req, res, next) => {
  try {
    const {document_id} = req.params;
    const creator_document_data = await CreatorAIIndexer.findById(
      document_id
    );
    logger.info(
      `[${CreatorAIDocumentIndexer} getAllCreatorDocuments API response success]`
    );
    return res.send({
        statusCode: 200,
        data: creator_document_data,
        message: "Creator Document Status Fetched Successfully",
        error: null,
      });
  } catch (error) {
    logger.error(
      `[${CreatorAIDocumentIndexer} getAllCreatorDocuments API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
