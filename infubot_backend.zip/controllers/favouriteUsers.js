const { User } = require("../models/Users");
const {CreatorFavouriteUsers} = require("../models/FavouriteUser")

const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");

const CreatorFavouriteUsersController = "CREATOR_FAVOURITE_USERS_CONTROLLER";



module.exports.getRatesOfFavouriteUsers = async (req, res, next) => {
  try {
    const check_if_user_exist = await User.findById(req.params.id);

    if(!check_if_user_exist){
        res.send({
            statusCode: 400,
            data: null,
            message: "User doesnt exist",
            error: null,
          });
    }

    const get_rates_of_user = await CreatorFavouriteUsers.findOne({
        user_id : check_if_user_exist.id,
        creator_id : req.creator.id
    })

    logger.info(
        `[${CreatorFavouriteUsersController} getBaseRates API response success]`
      );

    if(!get_rates_of_user){
       return res.send({
            statusCode: 400,
            data: null,
            message: "The user is not yet a favourite user",
            error: null,
          });
    }else{
        return res.send({
            statusCode: 200,
            data: get_rates_of_user,
            message: "Rates Fetched Successfully",
            error: null,
          });
    }
  } catch (error) {
    logger.error(
      `[${CreatorFavouriteUsersController} getBaseRates API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



module.exports.changeBaseRates = async (req, res, next) => {
    try {

    const check_if_user_exist = await User.findById(req.params.id);

    if(!check_if_user_exist){
        res.send({
            statusCode: 400,
            data: null,
            message: "User doesnt exist",
            error: null,
          });
    }

    
    const get_rates_of_user = await CreatorFavouriteUsers.findOne({
        user_id : check_if_user_exist.id,
        creator_id : req.creator.id
    })

  
      if (get_rates_of_user) {
        // Update existing base rates
        await CreatorFavouriteUsers.updateOne({}, req.body);
        baseRates = await CreatorFavouriteUsers.findOne({
            user_id : check_if_user_exist.id,
            creator_id : req.creator.id
        })
        logger.info('[BaseRateController changeBaseRates] Base rates updated successfully');
      } else {
        // Create new base rates
        baseRates = await CreatorFavouriteUsers.create(req.body);
        logger.info('[BaseRateController changeBaseRates] Base rates created successfully');
      }
  
      res.send({
        statusCode: 200,
        data: baseRates,
        message: `Rates ${baseRates ? 'updated' : 'created'} successfully`,
        error: null,
      });
    } catch (error) {
        logger.error(
            `[${CreatorFavouriteUsersController} changeBaseRates API response error:- ${error.message}]`
          );
      res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: error.message,
      });
    }
  };