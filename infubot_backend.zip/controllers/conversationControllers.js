const { Conversation } = require("../models/Conversation");
const {createConversation} = require("../services/common");

const logger = require("winston");

const ConversationController = "CONVERSATION_CONTROLLER";

/**
 * Retrieves the list of conversations for a specific user.
 *
 * This function fetches the conversation history for a user specified by the `user_id` in the request body. 
 * It searches the Conversation collection for all conversations involving the given user. The function returns 
 * an array of conversation objects where each object contains details about a single conversation.
 *
 * @returns {void}
 *   - On successful retrieval of the conversation list, returns the array of conversations.
 *   - On failure due to an error, returns a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a Conversation model representing conversation records.
 *   It uses the `find` method to retrieve all conversations associated with the specified `user_id`.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.getUserConversationList = async (req, res, next) => {
  try {
    const conversation = await Conversation.find({ user_id: req.body.user_id });
    logger.info(
      `[${ConversationController} getUserConversationList API response success]`
    );
    res.send(conversation);
  } catch (error) {
    logger.error(
      `[${ConversationController} getUserConversationList API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};


/**
 * Adds a new conversation for a user.
 *
 * This function handles the creation of a new conversation entry in the Conversation collection. 
 * It uses the request body to create a new conversation record. The request body should contain 
 * all the necessary information required to create a conversation entry, such as user_id and 
 * conversation details.
 *
 * @returns {void}
 *   - On successful creation of the conversation, returns a 200 status code with the created conversation object.
 *   - On failure due to an error, returns a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a Conversation model to handle the conversation data.
 *   It uses the `create` method to add a new conversation based on the provided request body data.
 *   The function also uses a logger for logging information and errors.
 */
module.exports.addUserConversation = async (req, res, next) => {
  try {
    let conversation = await Conversation.create(req.body);
   await conversation.save();

    logger.info(
      `[${ConversationController}] addUserConversation API response success`
    );
    res.send(200, conversation);
  } catch (error) {
    logger.error(
      `[${ConversationController} addUserConversation API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};



module.exports.createUserConversation = async (req, res, next) => {
  try {
    let conversation = await createConversation();
    return res.status(200).json({
      statusCode: 200,
      data : conversation,
      message: "User Conversation Created Successfully",
      error: null,
    });
    logger.info(
      `[${ConversationController}] addUserConversation API response success`
    );
  } catch (error) {
    logger.error(
      `[${ConversationController} addUserConversation API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
