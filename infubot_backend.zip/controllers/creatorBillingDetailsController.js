const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBillingDetails } = require("../models/CreatorBillingDetails");

const logger = require("winston");
const { CreatorKYC } = require("../models/CreatorKYC");
const { CreatorBankDetails } = require("../models/CreatorBankDetails");
const { Creator } = require("../models/Creator");

const CreatorBillingDetailsController = "CREATOR_Billing_DETAILS_CONTROLLER";

/**
 * Retrieves the billing details for a specific creator.
 *
 * This function fetches the billing details associated with a creator from the CreatorBillingDetails
 * collection using the creator's ID. It is designed to return the billing information that includes
 * details like address, tax information, etc., associated with the creator for billing purposes.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the billing details and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBillingDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */

module.exports.getCreatorBillingDetails = async (req, res, next) => {
  try {
    const checkCreator = await Creator.findById(req.creator.id);
    if (!checkCreator) {
      return res.status(400).send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }



    const creator_billing_details = await CreatorBillingDetails.findOne({
      creator_id: req.creator.id,
    });
    if(creator_billing_details){
      logger.info(
        `[${CreatorBillingDetailsController} getCreatorBillingDetails API response success]`
      );
      res.send({
        statusCode: 200,
        data: creator_billing_details,
        message: "Creator Billing details captured sucessfully!",
        error: null,
      });
    }else{
      res.send({
        statusCode: 200,
        data: null,
        message: "Creator Billing details doesn't exist",
        error: null,
      });
    }

  } catch (error) {
    logger.error(
      `[${CreatorBillingDetailsController} getCreatorBillingDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Adds billing details for a specific creator.
 *
 * This function is responsible for adding billing details for a creator into the CreatorBillingDetails
 * collection. It checks if billing details already exist for the creator; if they do, it returns the
 * existing details. Otherwise, it creates new billing details using the information provided in the request body.
 * The creator's ID is automatically added to the request body based on the authenticated user.
 *
 * @returns {void}
 *   - If billing details for the creator already exist, returns a 201 status code with the existing details and a message indicating that billing details already exist.
 *   - If new billing details are successfully created, returns a 201 status code with the newly created details and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBillingDetails model and expects the billing details to be provided in the request body (req.body).
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */

module.exports.addCreatorBillingDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator_id = req.creator.id;

    const check_creator_billing_details = await CreatorBillingDetails.findOne({
      creator_id: req.creator.id,
    });

    if (check_creator_billing_details) {
      res.send({
        statusCode: 201,
        data: check_creator_billing_details,
        message: "Creator Billing already exist",
        error: null,
      });
    } else {
      const creator_billing_details = await CreatorBillingDetails.create(
        reqBody
      );
      if (creator_billing_details) {
        check_creator_billing_details.payout_setting = true;
       await check_creator_billing_details.save();
      }
      logger.info(
        `[${CreatorBillingDetailsController} addCreatorBillingDetails API response success]`
      );
      res.send({
        statusCode: 201,
        data: creator_billing_details,
        message: "Creator Billing details added successfully",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${CreatorBillingDetailsController} addCreatorBillingDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Updates billing details for a specific creator.
 *
 * This function allows updating the billing details associated with a creator in the CreatorBillingDetails
 * collection. It locates the billing details using the creator's ID and updates them with the new information
 * provided in the request body. The creator's ID is automatically extracted from the authenticated user's request.
 *
 * @returns {void}
 *   - On successful update, returns a 201 status code with the updated billing details and a success message.
 *   - If an error occurs during the update process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBillingDetails model and expects the updated billing details to be provided in the request body (req.body).
 *   The creator's ID is expected to be provided in the request (req.creator.id) and is used to find the existing billing details to update.
 *   The function uses a logger for logging information and errors.
 */

module.exports.updateCreatorBillingDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator = req.creator.id;
    const creator_billing_details = await CreatorBillingDetails.updateOne(
      { creator_id: req.creator.id },
      reqBody
    );
    logger.info(
      `[${CreatorBillingDetailsController} updateCreatorBillingDetails API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_billing_details,
      message: "Creator Billing Details updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBillingDetailsController} updateCreatorBillingDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Adds or updates billing details for a specific creator.
 *
 * This function checks if billing details for a creator already exist in the CreatorBillingDetails
 * collection. If they exist, it updates the existing details with the new information provided in the
 * request body. If they do not exist, it creates new billing details for the creator using the provided
 * information. The creator's ID is automatically added to the request body based on the authenticated user.
 *
 * @returns {void}
 *   - If billing details for the creator are updated, returns a 201 status code with the updated details and a success message.
 *   - If new billing details are created, returns a 201 status code with the newly created details and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBillingDetails model and expects the billing details to be provided in the request body (req.body).
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */

module.exports.changeCreatorBillingDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;

    const check_if_creator_exist = await Creator.findById(req.creator.id)
    if(!check_if_creator_exist){
      return  res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator doesn't exist",
        error: null,
      });
    }


    reqBody.creator_id = req.creator.id;

    const existingCreatorBillingDetails = await CreatorBillingDetails.findOne({
      creator_id: req.creator.id,
    });

    if (existingCreatorBillingDetails) {
      // Update existing billing details
      const updatedCreatorBillingDetails =
        await CreatorBillingDetails.updateOne(
          { creator_id: req.creator.id },
          reqBody
        );
      logger.info(
        `[${CreatorBillingDetailsController} addOrUpdateCreatorBillingDetails API response success (update)]`
      );
      check_if_creator_exist.is_billing_details_added = true;
      await check_if_creator_exist.save()
      res.send({
        statusCode: 201,
        data: updatedCreatorBillingDetails,
        message: "Creator Billing Details updated successfully",
        error: null,
      });
    } else {
      // Create new billing details
      const creatorBillingDetails = await CreatorBillingDetails.create(reqBody);
      logger.info(
        `[${CreatorBillingDetailsController} addOrUpdateCreatorBillingDetails API response success (create)]`
      );
      check_if_creator_exist.is_billing_details_added = true;
      await check_if_creator_exist.save()
      res.send({
        statusCode: 201,
        data: creatorBillingDetails,
        message: "Creator Billing details added successfully",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${CreatorBillingDetailsController} addOrUpdateCreatorBillingDetails API response error:- ${error.message}`
    );



    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Deletes billing details for a specific creator.
 *
 * This function removes the billing details associated with a creator from the CreatorBillingDetails
 * collection. It identifies the billing details to be deleted using the creator's ID, which is extracted
 * from the authenticated user's request. The function then proceeds to delete these details from the database.
 *
 * @returns {void}
 *   - On successful deletion, returns a 200 status code with a success message and no data.
 *   - If an error occurs during the deletion process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBillingDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id) and is used to locate the billing details to delete.
 *   The function uses a logger for logging information and errors.
 */

module.exports.deleteCreatorBillingDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator = req.creator.id;
    const creator_billing_details = await CreatorBillingDetails.deleteOne({
      creator_id: req.creator.id,
    });
    logger.info(
      `[${CreatorBillingDetailsController} updateCreatorBillingDetails API response success]`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: "Creator Billing Details deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBillingDetailsController} updateCreatorBillingDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
