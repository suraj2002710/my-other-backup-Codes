const { ChatHistory } = require("../models/ChatHistory");
const {
  CreatorUserConversationMessage,
} = require("../socket_chat_infra/models/creator_user_conversation_message");

const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");

const ChatHistoryController = "CHAT_HISTORY_CONTROLLER";
const {random_user_profile} = require("../utilities/random_profile_images")
const {generate_presigned_url} = require("../services/generate_presigned_url");


/**
 * Retrieves a list of chat histories for a specific creator.
 *
 * This function fetches the chat history for a given creator by aggregating records from the ChatHistory collection.
 * It performs a match operation to filter chats by the specified creator ID, sorts them by user ID and creation time,
 * and then groups the records by user ID to get the most recent message per user. The function ultimately returns a
 * list of the last messages from each unique user who has interacted with the creator.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the chat history list is successfully fetched, it sends a 200 status code with the list of chat histories.
 *   - If there is an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a ChatHistory model representing the chat records.
 *   The aggregation pipeline used here is optimized for performance but assumes a specific data schema.
 */
// module.exports.getChatHistoryListForCreator = async (req, res, next) => {
//   try {
//     const chat_list_for_creator = await CreatorUserConversationMessage.aggregate([
//       {
//         $match: { creator_id: req.body.creator_id },
//       },
//       {
//         $sort: { user_id: 1, createdAt: -1 },
//       },
//       {
//         $group: {
//           _id: "$user_id",
//           lastMessage: { $first: "$$ROOT" },
//         },
//       },
//       {
//         $replaceRoot: { newRoot: "$lastMessage" },
//       },
//     ]);

//     logger.info(
//       `[${ChatHistoryController} getChatHistoryListForCreator API response success]`
//     );
//     res.status(200).json({
//       statusCode: 200,
//       data: chat_list_for_creator,
//       message: "Chat History list fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${ChatHistoryController} getChatHistoryListForCreator API response error:- ${error.message}]`
//     );
//     res.status(500).json({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

//With Pagination
module.exports.getChatHistoryListForCreator = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;

    // Fetching all relevant chat history first (consider implications on large datasets)
    let chat_list_for_creator = await CreatorUserConversationMessage.aggregate([
      { $match: { creator_id: req.body.creator_id } },
      { $sort: { user_id: 1, createdAt: -1 } },
      { $group: { _id: "$user_id", lastMessage: { $first: "$$ROOT" } } },
      { $replaceRoot: { newRoot: "$lastMessage" } },
      { $sort: { "createdAt": -1 } },
      // Consider adding a stage to sort by some criteria post-grouping if needed
    ]);


    // Client-side Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedItems = chat_list_for_creator.slice(startIndex, endIndex);

    // Construct nextPage URL
    const hasNextPage = endIndex < chat_list_for_creator.length;
    const nextPageUrl = hasNextPage ? `${req.protocol}://${req.get('host')}${req.baseUrl}${req.path}?page=${page + 1}&limit=${limit}` : null;


    // console.log("Paginated", paginatedItems)
    for(let i=0; i<paginatedItems.length;i++){
      const randomNumber = Math.floor(Math.random() * 30) + 1;
      paginatedItems[i] = {
        ...paginatedItems[i],
        user_profile_image: random_user_profile()
      }
    }

    logger.info(`[${ChatHistoryController} getChatHistoryListForCreator API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: paginatedItems,
      nextPage: nextPageUrl,
      message: "Chat History list fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(`[${ChatHistoryController} getChatHistoryListForCreator API response error:- ${error.message}]`);
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Retrieves the chat history between a specific user and a creator.
 *
 * This function fetches the complete chat history between a creator and a user from the ChatHistory collection.
 * It filters the chat records based on both the creator's ID and the user's ID provided in the request body.
 * The function is typically used to display the conversation history between the creator and a particular user
 * for reference or review purposes.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the chat history is successfully fetched, it sends a 200 status code with the chat history data.
 *   - If there is an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a ChatHistory model representing the chat records.
 *   It requires the 'creator_id' and 'user_id' fields in the request body to perform the query.
 */
module.exports.getChatOfUserByIdForCreator = async (req, res, next) => {
  try {
    let user_chat_for_creator = await CreatorUserConversationMessage.find({
      creator_id: req.body.creator_id,
      user_id: req.body.user_id,
    }).sort({ createdAt: -1 })
    .limit(50);

    for(let i = 0; i < user_chat_for_creator.length; i++) {
      if (user_chat_for_creator[i].type == "video" || user_chat_for_creator[i].type == "image" || user_chat_for_creator[i].type == "voice") {
        const attachment_array = [];
        if (user_chat_for_creator[i].attachments.length > 0) {
          for(let j = 0; j < user_chat_for_creator[i].attachments.length; j++) {
            const url = await generate_presigned_url(user_chat_for_creator[i].attachments[j].contentUrl);
            attachment_array.push({
              contentUrl: url
            });
          }
          user_chat_for_creator[i].attachments = attachment_array;
        }
      }
    }

    logger.info(`[getChatOfUserByIdForCreator API response success]`);

    res.send({
      statusCode: 200,
      data: user_chat_for_creator.reverse(), // This will now return all matched documents, sorted with the most recent first.
      message: "User Chat History For Creator fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(`[getChatOfUserByIdForCreator API response error:- ${error.message}]`);
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



// module.exports.getChatOfUserByIdForCreator = async (req, res, next) => {
//   try {
//     const {conversation_id} = req.body;
//     if(!conversation_id){
//       return res.send({
//         statusCode: 500,
//         data: null,
//         message: "Conversation id (conversation_id) is required",
//         error: true,
//       });
//     }
//     const user_chat_for_creator = await CreatorUserConversationMessage.find({user_conversation_id :conversation_id}).limit(50) // Ensure this line is included to sort by 'created_at' in descending order

//     logger.info(`[getChatOfUserByIdForCreator API response success]`);

//     res.send({
//       statusCode: 200,
//       data: user_chat_for_creator, // This will now return all matched documents, sorted with the most recent first.
//       message: "User Chat History For Creator fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[getChatOfUserByIdForCreator API response error:- ${error.message}]`);
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };


/**
 * Deletes the entire chat history between a specific user and a creator.
 *
 * This function is responsible for deleting all chat records from the ChatHistory collection
 * that correspond to a specific creator and user. It uses the creator's ID and the user's ID
 * provided in the request body to identify and remove the relevant chat records. This function
 * is typically used for data management purposes, such as clearing old conversations or
 * maintaining privacy.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the chat history is successfully deleted, it sends a 200 status code with a message
 *     indicating that the user's chat history was deleted successfully.
 *   - If there is an error during the deletion process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a ChatHistory model for storing chat records.
 *   Deletion is based on 'creator_id' and 'user_id' fields provided in the request body.
 *   This action is irreversible, and caution should be exercised before proceeding with deletion.
 */

module.exports.deleteUserEntireChatHistory = async (req, res, next) => {
  try {
    const user_chat_for_creator = await CreatorUserConversationMessage.deleteMany({
      creator_id: req.body.creator_id,
      user_id: req.body.user_id,
    });
    logger.info(
      `[${ChatHistoryController} getChatOfUserByIdForCreator API response success]`
    );
    res.json({
      statusCode: 200,
      message: "User Chat History deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${ChatHistoryController} getChatOfUserByIdForCreator API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
