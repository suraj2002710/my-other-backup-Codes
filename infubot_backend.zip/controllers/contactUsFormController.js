const { ContactUs } = require("../models/ContactUs");
const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");
const ContactUsController = "CONTACT_US_CONTROLLER";






/**

* Retrieves all "Contact Us" requests.
* This function fetches all the requests submitted through the "Contact Us" form. It accesses the ContactUs
* database collection and returns a list of all entries. This feature is primarily used for administrative
* purposes to view and manage user inquiries and feedback.
* @returns {void}
*    On success, returns a 200 status code with a list of all "Contact Us" requests.
*   On failure, returns a 500 status code with an error message.
*/
// module.exports.getAllContactUsRequest = async (req, res, next) => {
//   try {
//     const contact_us = await ContactUs.find({});
//     logger.info(`[${ContactUsController} getAllContactUsRequest API response success]`);
//     res.send({
//       statusCode: 200,
//       data: contact_us,
//       message: "Contact Us Request lists fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${ContactUsController} getAllContactUsRequest API response error:- ${error.message}]`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };



module.exports.getAllContactUsRequest = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not specified
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page if not specified
    const skip = (page - 1) * limit;

    const totalRequests = await ContactUs.countDocuments({});
    const contact_us = await ContactUs.find({}).skip(skip).limit(limit);

    logger.info(`[${ContactUsController} getAllContactUsRequest API response success]`);

    // Determine if there's a next page
    const hasNextPage = page * limit < totalRequests;
    const nextPageUrl = hasNextPage
      ? `${process.env.BASE_URL_FOR_IMAGES}api/contact-us?page=${page + 1}&limit=${limit}`
      : null;

    res.status(200).json({
      statusCode: 200,
      data: contact_us,
      nextPage: nextPageUrl,
      message: "Contact Us Request lists fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${ContactUsController} getAllContactUsRequest API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**

* Handles the submission of the "Contact Us" form.

* This function processes the submission of the "Contact Us" form. It first checks for the presence of required
* fields (Fullname, Email, Instagram Handle, and Message) in the request body. If any required field is missing,
* it returns an error with the missing field(s). If all required fields are present, the function then checks if
* a submission already exists for the provided email. If not, it creates a new entry in the ContactUs database
* collection with the form data and returns a success response.
* @returns {void}
* If any required field is missing, returns a 500 status code with an error message stating the missing fields.
* If a submission already exists for the provided email, returns a 404 status code with an error message.
* On successful form submission, returns a 201 status code with the submitted data and a success message.
* On failure due to other errors, returns a 201 status code with the error message.
* @note
* The function assumes the existence of a ContactUs model for storing form submissions.
* It also uses a logger for logging information and errors.
*/
module.exports.contactUsFormSubmit = async (req, res, next) => {
  try {
    const requiredFields = {
      name: "Fullname",
      email: "Email",
      instagram_handle: "Instagram Handle",
      message: "Message",
    };

    const missingFields = Object.entries(requiredFields)
      .filter(([field, label]) => req.body[field] === undefined)
      .map(([field, label]) => label);

    if (missingFields.length > 0) {
      return res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: `${missingFields.join(" and ")} ${
          missingFields.length > 1 ? "are" : "is"
        } required.`,
      });
    }


    let isContactUsDetailsExistForTheUser = await ContactUs.findOne({ email: req.body.email });
   
    if (isContactUsDetailsExistForTheUser)
      return res.status(400).json({
        statusCode: 404,
        data: null,
        message: null,
        error: `You have already received your request for the email ${isContactUsDetailsExistForTheUser.email}`,
      });

    let submitContactUsForm = await ContactUs.create(req.body);
    await submitContactUsForm.save();
    

    logger.info(`[${ContactUsController} contactUsFormSubmit API response success]`);

    res.status(201).json({
      statusCode: 201,
      data: submitContactUsForm,
      message: "Contact Us Form Submitted. We will get back to you soon",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${ContactUsController} contactUsFormSubmit API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Deletes all "Contact Us" requests.
 *
 * This function handles the deletion of all entries in the ContactUs database collection. It is used to clear 
 * all the existing "Contact Us" requests. This action is irreversible and should be used with caution as it 
 * results in the loss of all "Contact Us" data.
 *
 * @returns {void}
 *   - On successful deletion of all requests, returns a 200 status code with a success message.
 *   - On failure due to an error, returns a 200 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a ContactUs model and uses a logger for logging information and errors.
 *   The deletion is done using the deleteMany method, which removes all documents that match the condition.
 */
module.exports.deleteAllContactUsRequest = async (req, res, next) => {
  try {
    const faq = await ContactUs.deleteMany({});
    logger.info(
      `[${ContactUsController} deleteAllContactUsRequest API response success]`
    );
    res.staus(200).json({
      statusCode: 200,
      data: faq,
      message: "All Contact Us Request Deleted Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${ContactUsController} deleteAllContactUsRequest API response error:- ${error.message}`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
