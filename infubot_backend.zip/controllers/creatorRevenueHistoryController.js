const { CreatorRevenueHistory } = require("../models/CreatorRevenueHistory");
const VideoConnectivty= require("../models/VideoConnection");
const { Creator } = require("../models/Creator");
const { Transaction } = require("../models/Transaction");
const logger = require("winston");
const {CreatorEarning}=require("../models/creatorEarning");

module.exports.getCreatorRevenueList = async (req, res, next) => {
  try {

    console.log("api called...............", )
    let isCreatorExists = await Creator.findById(req.creator.id);
    if(!isCreatorExists){
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }
  
    let formattedResult = {
      chat_amount: 0,
      video_amount: 0,
      audio_amount: 0,
      total_amount: 0,
      ai_amount:0,
      creator_email: req.body.creator_email,
    };

    let creatorEarnings =await CreatorEarning.findOne({creator_id:isCreatorExists._id})
    if(creatorEarnings){
      formattedResult.chat_amount = creatorEarnings.earn_by_message;
      formattedResult.video_amount = creatorEarnings.earn_by_video_call;
      formattedResult.audio_amount = 0;
      formattedResult.total_amount = creatorEarnings.creator_earning+creatorEarnings.total_security_amount_left;
      formattedResult.ai_amount = creatorEarnings.earn_by_ai_message;

    }
    console.log("creatorEarnings...........",creatorEarnings)
    // const result = await CreatorRevenueHistory.aggregate([
    //   {
    //     $match: { creator_email: isCreatorExists.email },
    //   },
    //   {
    //     $group: {
    //       _id: "$type",
    //       totalAmount: { $sum: "$amount" },
    //     },
    //   },
    //   {
    //     $project: {
    //       _id: 0,
    //       type: "$_id",
    //       totalAmount: 1,
    //     },
    //   },
    // ]);

    

    // result.forEach((item) => {
    //   const { type, totalAmount } = item;
    //   switch (type) {
    //     case "chat":
    //       formattedResult.chat_amount = totalAmount;
    //       break;
    //     case "video":
    //       formattedResult.video_amount = totalAmount;
    //       break;
    //     case "audio":
    //       formattedResult.audio_amount = totalAmount;
    //     case "ai":
    //       formattedResult.ai_amount = totalAmount;
    //       break;
    //   }
    //   // Update total_amount
    //   formattedResult.total_amount += totalAmount;
    // });
  
    res.send({
      statusCode: 200,
      data: formattedResult,
      message: "Revenue lists fetched successfully",
      error: null,
    });

  } catch (error) {
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

// module.exports.getCreatorRevenueListv2 = async (req, res, next) => {
//   try {
//     const filters = req.body.filters || {};
//     let matchConditions = { creator_email: req.body.creator_email };

//     // Date range filter
//     if (filters.fromDate && filters.toDate) {
//       matchConditions.created_at = {
//         $gte: new Date(filters.fromDate),
//         $lte: new Date(filters.toDate),
//       };
//     }

//     console.log("Condition", matchConditions)
//     // Additional filters can be added here in a similar way

//     const result = await CreatorRevenueHistory.aggregate([
//       {
//         $match: matchConditions,
//       },
//       {
//         $group: {
//           _id: "$type",
//           totalAmount: { $sum: "$amount" },
//         },
//       },
//       {
//         $project: {
//           _id: 0,
//           type: "$_id",
//           totalAmount: 1,
//         },
//       },
//     ]);

//     let formattedResult = {
//       chat_amount: 0,
//       video_amount: 0,
//       audio_amount: 0,
//       total_amount: 0,
//       creator_email: req.body.creator_email,
//     };

//     result.forEach((item) => {
//       const { type, totalAmount } = item;
//       switch (type) {
//         case "chat":
//           formattedResult.chat_amount = totalAmount;
//           break;
//         case "video":
//           formattedResult.video_amount = totalAmount;
//           break;
//         case "audio":
//           formattedResult.audio_amount = totalAmount;
//           break;
//       }
//       formattedResult.total_amount += totalAmount;
//     });

//     res.send({
//       statusCode: 200,
//       data: formattedResult,
//       message: "Revenue lists fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };


// module.exports.getCreatorRevenueListv2 = async (req, res, next) => {
//   try {
//     let isCreatorExists = await Creator.findById(req.creator.id);
//     if (!isCreatorExists) {
//       return res.send({
//         statusCode: 400,
//         message: "Creator doesn't exist",
//         error: null,
//       });
//     }

//     const result = await CreatorRevenueHistory.aggregate([
//       {
//         $match: { creator_email: isCreatorExists.email },
//       },
//       {
//         $group: {
//           _id: "$type",
//           totalAmount: { $sum: "$amount" },
//           callCount: { $sum: 1 }, // Counting the number of calls for each type
//         },
//       },
//       {
//         $project: {
//           _id: 0,
//           type: "$_id",
//           totalAmount: 1,
//           callCount: 1, // Including call count in the projection
//         },
//       },
//     ]);

//     let formattedResult = {
//       chat_amount: 0,
//       video_amount: 0,
//       audio_amount: 0,
//       ai_amount: 0, // Including AI amount
//       total_amount: 0,
//       creator_email: isCreatorExists.email, // Use the email from the creator object
//       // Including counts for each call type
//       chat_count: 0,
//       video_count: 0,
//       audio_count: 0,
//       ai_count: 0,
//     };

//     result.forEach((item) => {
//       const { type, totalAmount, callCount } = item;
//       switch (type) {
//         case "chat":
//           formattedResult.chat_amount = totalAmount;
//           formattedResult.chat_count = callCount;
//           break;
//         case "video":
//           formattedResult.video_amount = totalAmount;
//           formattedResult.video_count = callCount;
//           break;
//         case "audio":
//           formattedResult.audio_amount = totalAmount;
//           formattedResult.audio_count = callCount;
//           break;
//         case "ai":
//           formattedResult.ai_amount = totalAmount;
//           formattedResult.ai_count = callCount;
//           break;
//       }
//       // Update total_amount
//       formattedResult.total_amount += totalAmount;
//     });

//     res.send({
//       statusCode: 200,
//       data: formattedResult,
//       message: "Revenue lists fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.getCreatorRevenueListv2 = async (req, res, next) => {
  try {
    let isCreatorExists = await Creator.findById(req.creator.id);
    if (!isCreatorExists) {
      return res.send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    const result = await CreatorRevenueHistory.aggregate([
      {
        $match: { creator_email: isCreatorExists.email },
      },
      {
        $sort: { createdAt: -1 }, // Optional, sort by date if needed
      },
      {
        $project: {
          _id: 1,
          type: 1,
          amount: 1,
          user_email: 1,
          user_name: 1,
          createdAt: 1,
        },
      },
    ]);

    if (result.length === 0) {
      return res.send({
        statusCode: 200,
        data: [],
        message: "No revenue records found for this creator.",
        error: null,
      });
    }

    // Post-process the result to group by type and then by user within each type,
    // including total amount spent, total count, and data array for each user.
    let grouped = result.reduce((acc, curr) => {
      // Initialize type if not exists
      if (!acc[curr.type]) {
        acc[curr.type] = {};
      }

      // Initialize user within type if not exists
      if (!acc[curr.type][curr.user_email]) {
        acc[curr.type][curr.user_email] = {
          totalAmount: 0,
          totalCount: 0,
          data: []
        };
      }

      // Aggregate data
      acc[curr.type][curr.user_email].totalAmount += curr.amount;
      acc[curr.type][curr.user_email].totalCount += 1;
      acc[curr.type][curr.user_email].data.push(curr);

      return acc;
    }, {});

    // Convert to desired format
    let formattedData = Object.keys(grouped).reduce((acc, type) => {
      acc[type] = [];
      Object.keys(grouped[type]).forEach(userEmail => {
        acc[type].push({
          userEmail: userEmail,
          totalAmount: grouped[type][userEmail].totalAmount,
          totalCount: grouped[type][userEmail].totalCount,
          data: grouped[type][userEmail].data
        });
      });
      return acc;
    }, {});

    res.send({
      statusCode: 200,
      data: formattedData,
      message: "Revenue records grouped by type and user successfully, with totals and counts.",
      error: null,
    });
  } catch (error) {
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.getUserCostingList = async (req, res, next) => {
  try {
    const result = await CreatorRevenueHistory.aggregate([
      {
        $match: { user_email: req.body.user_email },
      },
      {
        $group: {
          _id: "$type",
          totalAmount: { $sum: "$amount" },
        },
      },
      {
        $project: {
          _id: 0,
          type: "$_id",
          totalAmount: 1,
        },
      },
    ]);

    let formattedResult = {
      chat_amount: 0,
      video_amount: 0,
      audio_amount: 0,
      total_amount: 0,
      user_email: req.body.user_email,
    };
    result.forEach((item) => {
      const { type, totalAmount } = item;
      switch (type) {
        case "chat":
          formattedResult.chat_amount = totalAmount;
          break;
        case "video":
          formattedResult.video_amount = totalAmount;
          break;
        case "audio":
          formattedResult.audio_amount = totalAmount;
          break;
      }
      // Update total_amount
      formattedResult.total_amount += totalAmount;
    });

    res.send({
      statusCode: 200,
      data: formattedResult,
      message: "Revenue lists fetched successfully",
      error: null,
    });
  } catch (error) {
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
