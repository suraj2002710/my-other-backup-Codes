const { SOMETHING_WENT_WRONG } = require("../constant");
const { Wallet } = require("../models/Wallet");
const { User } = require("../models/Users");
const { Orders } = require("../models/Orders");
const {createPaymentLink} = require("../payment_gateways/stripe");
// const redis = require("../queue_infra/redis_connection");


const logger = require("winston");
const { isNumber } = require("lodash");

const walletController = "WALLET_CONTROLLERS";


/**
 * Retrieves the wallet details for a specific user.
 *
 * This function is responsible for fetching the wallet information associated with a given user. It queries
 * the Wallet collection using the user's ID provided in the request parameters. The function is integral
 * to financial operations within the application, allowing for the retrieval of a user's wallet balance,
 * transaction history, or other related financial data.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the wallet information is successfully retrieved, it sends a 200 status code with the wallet data
 *     and a success message.
 *   - If there is an error during the retrieval process, or if the wallet does not exist, it sends a 500 status
 *     code with the error message.
 *
 * @note
 *   The function assumes the presence of a Wallet model representing the user's financial data. It is critical
 *   for maintaining transparency and accessibility of financial information for users. This endpoint can be
 *   used to display wallet balance, transaction history, or other related information in the user interface.
 */

module.exports.getUserWallet = async (req, res, next) => {
  try {
    // console.log("----",req.user.id)
    const check_if_user_exist = await User.findById(req.user.id);
    if(!check_if_user_exist){
      res.status(400).json({
        statusCode: 400,
        data: null,
        message: "User Doesn't Exist",
        error: true
      });
    }

    // if(check_if_user_exist?.has_logged_in_for_first_time){
    //   check_if_user_exist.user.has_logged_in_for_first_time = false
    //   check_if_user_exist.save()
    // }
    const wallet = await Wallet.findOne({ user_id: req.user.id });
    // console.log("Wallet",req.user.id, wallet )
    logger.info(`[${walletController}] getUserWallet API response success`);
    res.status(200).json({
      statusCode: 200,
      data: wallet,
      message: "Wallet fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${walletController} getUserWallet API response error:- ${error.message}`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Updates the wallet balance for a specific user.
 *
 * This function is responsible for modifying the wallet balance of a user. It first verifies the existence
 * of the user's wallet using their user ID. If the wallet exists, the function proceeds to update the wallet
 * balance by adding the specified amount from the request body to the current wallet balance. This function
 * plays a crucial role in handling financial transactions within the application, such as crediting user accounts
 * following certain activities or purchases.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the wallet is successfully updated, it sends a 200 status code with the updated wallet data
 *     and a success message.
 *   - If the user's wallet does not exist, it sends a 200 status code with a message indicating the absence
 *     of the wallet.
 *   - If there is an error during the update process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a Wallet model representing user's financial data. Proper validation
 *   of the balance update amount is crucial to prevent erroneous transactions. This endpoint is important for
 *   maintaining the integrity and accuracy of users' financial data within the application.
 */

// module.exports.updateuserWallet = async (req, res, next) => {
//   try {
//     const wallet = await Wallet.findOne({ user_id: req.user.id });
//     if (!wallet) {
//       return res.status(200).json({
//         statusCode: 200,
//         data: null,
//         message: "User's Wallet does not exists",
//         error: null,
//       });
//     }

//     console.log(req.body.balance)
//     // console.log(isNaN(wallet.wallet_balance))

//     if(req.body.balance > 0 && isNumber(wallet.wallet_balance)){
//       let update_wallet = await Wallet.findOneAndUpdate(
//         { user_id: req.user.id },
//         {
//           wallet_balance: wallet.wallet_balance + req.body.balance,
//         }
//       );
//       logger.info(`[${walletController} updateuserWallet API response success]`);
//       res.status(200).json({
//         statusCode: 200,
//         data: update_wallet,
//         message: "Wallet updated successfully",
//         error: null,
//       });
//     }else{
//       res.status(500).json({
//         statusCode: 500,
//         data: null,
//         message: "Please enter balance properly",
//         error: true,
//       });
//     }
//   } catch (error) {
//     // console.log(error);
//     logger.error(
//       `[${walletController} updateuserWallet API response error:- ${error.message}`
//     );
//     res.status(500).json({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };


/**
 * Updates the wallet balance based on order transaction status.
 *
 * This function processes wallet updates in response to order transaction results. It begins by retrieving
 * the order details using the provided order ID. It then checks if the user associated with the order has
 * a valid wallet. If the transaction status is successful, the function updates the order status to 'success'
 * and increases the user's wallet balance by the specified gross amount from the order. This function is integral
 * for processing financial transactions related to orders and ensuring accurate reflection of these transactions
 * in the user's wallet.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the wallet is successfully updated, it sends a 200 status code with the updated wallet data
 *     and a success message, along with the call URL.
 *   - If the user's wallet does not exist, it sends a 200 status code with a message indicating the absence
 *     of the wallet.
 *   - If there is an error during the update process, it sends a 500 status code with the error message.
 *
 * @note
 *   This function assumes the existence of both Wallet and Orders models. It is crucial for handling 
 *   financial transactions and updates following order completions. The function's effectiveness is key 
 *   to maintaining accurate and up-to-date financial records for users.
 */

// module.exports.updateuserWalletGateway = async (req, res, next) => {
//   try {
//     const orders = await Orders.findOne({ order_id: req.body.order_id });
//     const wallet = await Wallet.findOne({ user_id: orders.user_id.toString() });
//     if (!wallet) {
//       return res.send({
//         statusCode: 200,
//         data: null,
//         message: "User's Wallet does not exists",
//         error: null,
//       });
//     }

//     if (req.body.txn_status == "success") {
//       await Orders.findOneAndUpdate(
//         { order_id: req.body.order_id },
//         { txn_status: "success" }
//       );

//       var update_wallet = await Wallet.findOneAndUpdate(
//         { user_id: orders.user_id.toString() },
//         {
//           wallet_balance:
//             wallet.wallet_balance + parseInt(req.body.gross_amount),
//         }
//       );
//     }

//     logger.info(`[${walletController} updateuserWallet API response success]`);
//     res.send({
//       statusCode: 200,
//       data: {
//         callurl:
//           "https://" +
//           process.env.BASE_URL_FOR_CREATOR +
//           "/" +
//           orders.creator_username,
//       },
//       message: "Wallet updated successfully",
//       error: null,
//     });
//   } catch (error) {
//     // console.log(error);
//     logger.error(
//       `[${walletController} updateuserWallet API response error:- ${error.message}`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };



/**
 * Creates a payment link for a specified user.
 *
 * This function generates a payment link for transactions. It takes the user's email, the type of transaction,
 * and the amount to be transacted as input. The function then calls an external service to create a payment link
 * based on these parameters. The payment link is used to facilitate the transaction process for the user.
 * This function is critical for enabling users to perform financial transactions seamlessly.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the payment link is successfully generated, it sends a 200 status code with the payment link data,
 *     including test card information for sandbox testing, and a success message.
 *   - If the function is unable to generate a payment link, it sends a 200 status code with a message indicating
 *     the failure to generate the link.
 *   - If there is an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the use of an external service to generate the payment link. The success of this function
 *   is vital for facilitating financial transactions, making it an essential component of the payment system. The
 *   presence of test card information in the response is particularly useful for sandbox testing and development purposes.
 */

module.exports.createStripePaymentLink = async (req, res, next) => {
  try {
    const {email,type,amount} = req.body;
    const generate_link = await createPaymentLink({
      email,type,amount
    })
    if (!generate_link) {
      return res.send({
        statusCode: 200,
        data: null,
        message: "Unable to generate payment link",
        error: null,
      });
    }

    if (generate_link.status == true) {
      return res.send({
        statusCode: 200,
        data: generate_link.data,
        test : {
          card : process.env.CARD_NUMBER
        },
        message: "Payment Link Generated Successfully",
        error: null,
      });
    }
  } catch (error) {
    // console.log(error);
    logger.error(
      `[${walletController} updateuserWallet API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.createCashfreePaymentLink = async (req, res, next) => {
  try {
    const {email,type,amount} = req.body;
    const generate_link = await createCashfreeOrder({
      email,type,amount
    })
    if (!generate_link) {
      return res.send({
        statusCode: 200,
        data: null,
        message: "Unable to generate payment link",
        error: null,
      });
    }

    if (generate_link.status == true) {
      return res.send({
        statusCode: 200,
        data: generate_link.data,
        test : {
          card : process.env.CARD_NUMBER
        },
        message: "Payment Link Generated Successfully",
        error: null,
      });
    }
  } catch (error) {
    // console.log(error);
    logger.error(
      `[${walletController} updateuserWallet API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


