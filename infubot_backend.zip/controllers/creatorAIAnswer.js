const logger = require("winston");
const { Creator } = require("../models/Creator");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { CreatorAIPersonality } = require("../models/creatorAIPersonality");
const {
  CreatorAIPersonalityQuestion,
} = require("../models/creatorAIPersonalityQuestions");
const { congnitiveLanguageService } = require("../cognitive_service/language");

const commonControllers = "commonControllers";

const {
  fetchSolution,
  checkIfCreatorIndexedDataExist,
} = require("../ai_infra/query_v2");

module.exports.getAnswer = async (req, res, next) => {
  try {
    const { creator_id, query } = req.body;

    // Validate the presence of creator_id and query
    if (!creator_id || !query) {
      return res.status(400).json({
        statusCode: 400,
        message: "Both creator_id and query are required",
        error: false,
      });
    }

    // Find creator details
    const get_creator_details = await Creator.findOne({ _id: creator_id });
    if (!get_creator_details) {
      return res.status(404).json({
        statusCode: 404,
        message: `No Creator exists with ID ${creator_id}`,
        error: false,
      });
    }

    const fetch_creator_bot_settings = await CreatorBotSetting.findOne({
      creator_id: creator_id,
    });

    // console.log("Bot Settings Details", fetch_creator_bot_settings);

    // const checkDataIndexingOfCreator = await checkIfCreatorIndexedDataExist(
    //   creator_id
    // );
    // if (!checkDataIndexingOfCreator) {
    //   return res.send({
    //     statusCode: 400,
    //     data: null,
    //     message: `No Creator Indexed Data exists for ID ${creator_id}`,
    //     error: null,
    //   });
    // }

    // Check user intention
    // const check_intention = await congnitiveLanguageService(query);
    // console.log("Intentions:", JSON.stringify(check_intention, null, 2));

    // const intent = check_intention?.result?.prediction?.topIntent.toLowerCase();
    // const confidenceScore =
    //   check_intention?.result?.prediction?.intents[0]["confidenceScore"];
    // console.log("Intent", intent, confidenceScore);
    // let run = false;

    let response;
    // Handle specific intents with confidence score check
    if (!get_creator_details?.has_ai_personality) {
      // return res.send("Initializing Payment Option");
      // console.log("Creator has not updated his AI Personality");
      response = await fetchSolution(
        query,
        creator_id,
        get_creator_details,
        {
          tagline: "This is a sample tagline",
          general_description: "You are an AI assistant",
          personality_description: "You are an AI assistant",
          cost_per_audio_call_in_min:
            fetch_creator_bot_settings?.cost_audio_per_min,
          cost_per_video_call_in_min:
            fetch_creator_bot_settings?.cost_video_per_min,
        },
        false
      );
    } else {
      // console.log("Creator has updated his AI Personality");
      const fetch_creator_ai_personality = await CreatorAIPersonality.findOne({
        creator_id: creator_id,
      });
      response = await fetchSolution(
        query,
        creator_id,
        get_creator_details,
        {
          tagline: fetch_creator_ai_personality.tagline,
          general_description: fetch_creator_ai_personality.general_description,
          personality_description:
            fetch_creator_ai_personality.personality_description,
          cost_per_audio_call_in_min:
            fetch_creator_bot_settings?.cost_audio_per_min,
          cost_per_video_call_in_min:
            fetch_creator_bot_settings?.cost_video_per_min,
        },
        true
      );
    }

    if (response) {
      return res.json({
        statusCode: 200,
        data: response,
        message: "Answer Fetched Successfully",
        error: null,
      });
    } else {
      return res.json({
        statusCode: 400,
        data: null,
        message: "Unable to fetch answer",
        error: null,
      });
    }

    // if (fetch_creator_ai_personality) {
    //   // Fetch answer
    //   const fetch_answer = await fetchSolution(
    //     query,
    //     creator_id,
    //     get_creator_details,
    //     {
    //     tagline : fetch_creator_ai_personality.tagline,
    //     general_description : fetch_creator_ai_personality.general_description,
    //     personality_description : fetch_creator_ai_personality.personality_description,
    //     }
    //     // fetch_creator_ai_personality?.tonality ? fetch_creator_ai_personality?.tonality : ["Funny"],
    //     // {
    //     //   profession : fetch_creator_ai_personality?.profession,
    //     //   isFriendly : fetch_creator_ai_personality?.isFriendly,
    //     //   isHumorous : fetch_creator_ai_personality?.isHumorous,
    //     //   isOutgoing : fetch_creator_ai_personality?.isOutgoing,
    //     //   isCreative : fetch_creator_ai_personality?.isCreative,
    //     //   isConfident : fetch_creator_ai_personality?.isConfident,
    //     //   isEmotional :fetch_creator_ai_personality?.isEmotional,
    //     //   isArtistic : fetch_creator_ai_personality?.isArtistic,
    //     //   isEmotional : fetch_creator_ai_personality?.isEmotional,
    //     //   isAdventurous :fetch_creator_ai_personality?.isAdventurous,
    //     //   isActive : fetch_creator_ai_personality?.isActive,
    //     // }
    //   );

    //   if (fetch_answer) {
    //     return res.json({
    //       statusCode: 200,
    //       data: fetch_answer,
    //       message: "Answer Fetched Successfully",
    //       error: null,
    //     });
    //   } else {
    //     return res.status(404).json({
    //       statusCode: 404,
    //       message: "No answer found for the given query",
    //       error: false,
    //     });
    //   }
    // } else {
    //   return res.send({
    //     statusCode: 400,
    //     message: "Creator has not added AI Personality",
    //     error: false,
    //   });
  } catch (error) {
    logger.error(
      `[${commonControllers} getAnswer API response error:- ${error.message}]`
    );
    return res.status(500).json({
      statusCode: 500,
      message: "Internal Server Error",
      error: true,
    });
  }
};

module.exports.addQuestion = async (req, res, next) => {
  try {
    const requiredFields = {
      question: "Question",
      display_question: "Display Question",
      answer: "Answer",
    };

    const missingFields = Object.entries(requiredFields)
      .filter(([field, label]) => req.body[field] === undefined)
      .map(([field, label]) => label);

    if (missingFields.length > 0) {
      return res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: `${missingFields.join(" and ")} ${
          missingFields.length > 1 ? "are" : "is"
        } required.`,
      });
    }

    const add_question = await CreatorAIPersonalityQuestion.create(req.body);
    if (add_question) {
      res.send({
        statusCode: 200,
        data: add_question,
        message: "Question Added Successfully",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${commonControllers} getSystemHealth API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.getAllQuestions = async (req, res, next) => {
  try {
    const get_all_questions = await CreatorAIPersonalityQuestion.find({});
    if (get_all_questions) {
      res.send({
        statusCode: 200,
        data: get_all_questions,
        message: "All Questions Fetched Successfully",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${commonControllers} getSystemHealth API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
