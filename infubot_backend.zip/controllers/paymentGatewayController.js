const { SOMETHING_WENT_WRONG } = require("../constant");
const {PaymentGateways} = require("../models/PaymentGateways")
const path = require("path");
const axios = require("axios");
// const redis = require("../queue_infra/redis_connection");

const logger = require("winston");
const { isNumber } = require("lodash");


const PaymentGatewayController = "PAYMENT_GATEWAY_CONTROLLER";

module.exports.getAllPaymentGateways = async (req, res) => {
  try {
    // const redisKey = 'payment_gateways';

    // Attempt to retrieve cached payment gateways
    // const cachedGateways = await redis.get(redisKey);
    // if (cachedGateways) {
    //   logger.info(`[PaymentGatewayController] Payment Gateways fetched from cache`);
    //   return res.send({
    //     statusCode: 200,
    //     data: JSON.parse(cachedGateways),
    //     message: "All Active Payment Gateways Fetched Successfully from cache",
    //     error: null,
    //   });
    // }

    const get_all_payment_gateways = await PaymentGateways.find({});
    if (get_all_payment_gateways && get_all_payment_gateways.length === 0) {
      return res.send({
        statusCode: 400,
        data: null,
        message: "No Payment Gateway Exist For now",
        error: null,
      });
    }

    // Cache the fetched payment gateways for future requests
    // await redis.set(redisKey, JSON.stringify(get_all_payment_gateways), 'EX', 3600); // Cache for 24 hours

    logger.info(`[PaymentGatewayController] getAllPaymentGateways API response success`);
    res.send({
      statusCode: 200,
      data: get_all_payment_gateways,
      message: "All Active Payment Gateways Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(`[PaymentGatewayController] getAllPaymentGateways API response error:- ${error.message}`);
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addPaymentGateway = async(req,res) => {
  try {
    
  } catch (error) {
    
  }
}