const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBankDetails } = require("../models/CreatorBankDetails");
const { CreatorBillingDetails } = require("../models/CreatorBillingDetails");
const { CreatorKYC } = require("../models/CreatorKYC");
const { Creator } = require("../models/Creator");

const logger = require("winston");

const CreatorKYCController = "CREATOR_KYC_CONTROLLER";

/**
 * Retrieves the Know Your Customer (KYC) details for a specific creator.
 *
 * This function fetches the KYC details of a creator from the CreatorKYC collection using the creator's ID.
 * It constructs the full URL for the document image by appending the base URL for images to the document image path.
 * The KYC details, including the full URL for the document image, are then returned to the client.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the KYC details and a success message.
 *   - If an error occurs during the retrieval process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorKYC model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 *   The BASE_URL_FOR_IMAGES environment variable is used to construct the full URL for the document image.
 */
module.exports.getCreatorKYCDetails = async (req, res, next) => {
  try {
    const checkCreator = await Creator.findById(req.creator.id);
    if (!checkCreator) {
      return res.status(400).send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }


    let creator_kyc_details = await CreatorKYC.findOne({
      creator_id: req.creator.id,
    });
    if(creator_kyc_details){
      logger.info(
        `[${CreatorKYCController} getCreatorKYCDetails API response success]`
      );
      creator_kyc_details.doc_image =
        process.env.BASE_URL_FOR_IMAGES + creator_kyc_details.doc_image;
  
      res.send({
        statusCode: 200,
        data: creator_kyc_details,
        message: "Creator KYC details captured sucessfully!",
        error: null,
      });
    }else{
      res.send({
        statusCode: 200,
        data: null,
        message: "Creator KYC data doesn't exist",
        error: null,
      });
    }

  } catch (error) {
    logger.error(
      `[${CreatorKYCController} getCreatorKYCDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Adds Know Your Customer (KYC) details for a creator.
 *
 * This function allows for the addition of KYC details for a creator. It first checks for the presence of
 * a file in the request (presumably a KYC document), and then verifies whether KYC details for the creator
 * already exist in the CreatorKYC collection. It validates the presence of required fields such as
 * the PAN card number. After validation, it constructs an image path for the uploaded file and
 * creates a new entry in the CreatorKYC collection with the provided details.
 *
 * @returns {void}
 *   - On successful addition, returns a 201 status code with the newly added KYC details and a success message.
 *   - If KYC details for the creator already exist, returns a 400 status code with an appropriate message.
 *   - If required fields are missing or no file is provided, returns a 500 status code with an error message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorKYC model and expects the creator's ID in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 *   The file uploaded in the request is expected to be handled by a middleware that populates req.file with the file's details.
 */
module.exports.addCreatorKYCDetails = async (req, res, next) => {
  try {
    console.log("Req body", req.body);

    if (!req.file) {
      return res.send({
        statusCode: 500,
        data: null,
        message: null,
        error: "Document is required",
      });
    }

    let check_if_creator_kyc_exist = await CreatorKYC.findOne({
      creator_id: req.creator.id,
    });

    if (check_if_creator_kyc_exist) {
      return res.send({
        statusCode: 400,
        data: null,
        message: "Creator KYC already exist",
        error: null,
      });
    }

    let reqBody = req.body;

    const requiredFields = {
      pan_card_number: "Pan Card is required for KYC Setup",
      // adhaar_card_number: "Aadhaar card is required for KYC Setup",
    };

    const missingFields = Object.entries(requiredFields)
      .filter(([field, label]) => req.body[field] === undefined)
      .map(([field, label]) => label);

    if (missingFields.length > 0) {
      return res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: `${missingFields.join(" and ")} ${
          missingFields.length > 1 ? "are" : "is"
        } required.`,
      });
    }

    reqBody.creator_id = req.creator.id;

    const { filename, destination } = req.file;
    let imagePath = destination + filename; // Construct the image path
    // console.log("Path", imagePath)

    reqBody.doc_image = imagePath;
    const creator_kyc_details = await CreatorKYC.create(reqBody);

    // CreatorBankDetails.findOne({ creator_id: req.creator.id }).then(
    //   (bank_details) => {
    //     CreatorBillingDetails.findOne({ creator_id: req.creator.id }).then(
    //       (billing) => {
    //         Creator.findOne({ creator_id: req.creator.id })
    //           .exec()
    //           .then((result) => {
    //             result.payout_setting = true;
    //             result.save();
    //           });
    //       }
    //     );
    //   }
    // );

    logger.info(
      `[${CreatorKYCController} addCreatorKYCDetails API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_kyc_details,
      message: "Creator KYC details added successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorKYCController} addCreatorKYCDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Updates Know Your Customer (KYC) details for a creator.
 *
 * This function updates the existing KYC details for a creator. It checks if there's a new file
 * in the request (presumably an updated KYC document). If a new file is present, it updates the
 * document image path with the new file's path. It then updates the CreatorKYC entry corresponding
 * to the given creator ID with the new data provided in the request body.
 *
 * @returns {void}
 *   - On successful update, returns a 201 status code with the updated KYC details and a success message.
 *   - If a new file is provided, updates the document image with the new file's path.
 *   - If required fields are missing, returns a 500 status code with an error message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorKYC model and expects the creator's ID in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 *   The file uploaded in the request is expected to be handled by a middleware that populates req.file with the file's details.
 *   This function should use `findOneAndUpdate` method instead of `create` to update existing data.
 */

module.exports.updateCreatorKYCDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;

    reqBody.creator_id = req.creator.id;

    let imagePath;
    if (req.file) {
      const { filename, destination } = req.file;
      imagePath = destination + filename;
      reqBody.doc_image = imagePath;
    }

    const creator_kyc_details = await CreatorKYC.create(reqBody);

    logger.info(
      `[${CreatorKYCController} updateCreatorKYCDetails API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_kyc_details,
      message: "Creator KYC details added successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorKYCController} updateCreatorKYCDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Handles the addition or update of Know Your Customer (KYC) details for a creator.
 *
 * This function serves a dual purpose: it either adds new KYC details for a creator
 * or updates the existing ones. It checks if there's a new file in the request, and if so,
 * updates the document image path. Depending on whether the creator already has KYC details
 * in the CreatorKYC collection, it either creates a new entry or updates the existing one.
 * Furthermore, it checks if the creator has both bank and billing details set and, if so,
 * updates the creator's payout setting.
 *
 * @returns {void}
 *   - On successful creation or update, returns a 200 (for update) or 201 (for creation) status code
 *     with the KYC details and a success message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of CreatorKYC, CreatorBankDetails, and CreatorBillingDetails models
 *   and expects the creator's ID in the request (req.creator.id). It uses a logger for logging information
 *   and errors. The file uploaded in the request is expected to be handled by a middleware that populates
 *   req.file with the file's details.
 */

module.exports.changeCreatorKYCDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;

    const creator = await Creator.findById(req.creator.id);
    if (!creator) {
      return res.status(400).json({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    reqBody.creator_id = req.creator.id;


    if (req.file) {
      const { filename, destination } = req.file;
      reqBody.doc_image = destination + filename; // Construct the image path
    }

    let creatorKYC = await CreatorKYC.findOne({ creator_id: req.creator.id });

    if (creatorKYC) {
      // Update existing KYC details
      await CreatorKYC.updateOne({ creator_id: req.creator.id }, reqBody);
      creatorKYC = await CreatorKYC.findOne({ creator_id: req.creator.id });
      logger.info(
        `[${CreatorKYCController} handleCreatorKYCDetails API response success - Details Updated]`
      );
    } else {
      // Create new KYC details
      creatorKYC = await CreatorKYC.create(reqBody);
      logger.info(
        `[${CreatorKYCController} handleCreatorKYCDetails API response success - Details Added]`
      );
      // Update payout setting after KYC, Bank, and Billing details are set
      const bankDetails = await CreatorBankDetails.findOne({
        creator_id: req.creator.id,
      });
      const billingDetails = await CreatorBillingDetails.findOne({
        creator_id: req.creator.id,
      });

      if (bankDetails && billingDetails) {
        const creator = await Creator.findOne({ creator_id: req.creator.id });
        if (creator) {
          creator.payout_setting = true;
          await creator.save();
        }
      }
    }

      creator.is_kyc_added = true;
      await creator.save()

    res.send({
      statusCode: creatorKYC ? 200 : 201,
      data: creatorKYC,
      message: `Creator KYC details ${
        creatorKYC ? "updated" : "added"
      } successfully`,
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorKYCController} handleCreatorKYCDetails API response error:- ${error.message}]`
    );
    return res.status(500).send({
      statusCode: 500,
      error: error.message,
    });
  }
};

/**
 * Deletes Know Your Customer (KYC) details for a specific creator.
 *
 * This function removes the KYC details of a creator from the CreatorKYC collection based on the creator's ID.
 * It performs a deletion operation on the database targeting the KYC details associated with the given creator ID.
 *
 * @returns {void}
 *   - On successful deletion, returns a 201 status code with a success message.
 *   - If an error occurs during the deletion process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorKYC model and expects the creator's ID in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 */

module.exports.deleteCreatorKYCDetails = async (req, res, next) => {
  try {
    const creator_kyc_details = await CreatorKYC.deleteOne({
      creator_id: req.creator.id,
    });
    logger.info(
      `[${CreatorKYCController} updateCreatorKYCDetails API response success]`
    );
    res.send({
      statusCode: 201,
      message: "Creator KYC Details deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorKYCController} updateCreatorKYCDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
