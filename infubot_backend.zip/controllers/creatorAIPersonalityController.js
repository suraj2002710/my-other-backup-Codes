const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorAIPersonality } = require("../models/creatorAIPersonality");
const { Creator } = require("../models/Creator");

const logger = require("winston");


const CreatorAIPersonalityController = "CREATOR_AI_PERSONALITY_CONTROLLER";


/**
 * Retrieves the AI Personality settings for a specific creator.
 *
 * This function fetches the AI Personality settings associated with a creator from the CreatorAIPersonality
 * collection using the creator's ID. It is designed to return the settings that define how the creator's AI
 * interacts or behaves.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the AI Personality data and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorAIPersonality model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */
module.exports.getCreatorAIPersonality = async (req, res, next) => {
  try {
    const creator_ai_personality = await CreatorAIPersonality.findOne({
      creator_id: req.creator.id,
    });
    logger.info(
      `[${CreatorAIPersonalityController} getCreatorAIPersonality API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_ai_personality,
      message: "Creator AI Personality fetched successfully!",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorAIPersonalityController} getCreatorAIPersonality API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Handles the creation of new AI Personality settings for a specific creator.
 *
 * This function adds new AI Personality settings for a creator to the CreatorAIPersonality
 * collection. It first verifies the existence of the creator using the creator's ID. If the creator
 * does not exist, it returns an error. It also checks if AI Personality settings already exist for this
 * creator. If they do, it returns an error. Otherwise, it proceeds to create new AI Personality settings based
 * on the provided request data.
 *
 * @returns {void}
 *   - If the creator does not exist or AI Personality settings already exist, returns a 400 status code with an error message.
 *   - On successful creation of AI Personality settings, returns a 201 status code with the newly created data and a success message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a Creator and CreatorAIPersonality model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 */

module.exports.addCreatorAIPersonality = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator_id = req.creator.id;

    const check_if_creator_exist = await Creator.findById(reqBody.creator_id)
    if(!check_if_creator_exist){
      return  res.send({
        statusCode: 400,
        data: null,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    const check_if_creator_ai_personality_exist = await CreatorAIPersonality.findOne({
      creator_id: req.creator.id,
    });
    if(check_if_creator_ai_personality_exist){
      return  res.send({
        statusCode: 400,
        data: check_if_creator_ai_personality_exist,
        message: "Creator AI Personality Already Exist. Please update if need to be changed",
        error: null,
      });
    }

    const {additional_data} = req.body;

    const add_creator_ai_personality = await CreatorAIPersonality.create({
        creator_id : req.creator.id,
        tonality : req.body.tonality ? req.body.tonality : [],
        profession : req.body.profession ? req.body.profession : ["Model","Actress"],
        ... req.body
    });
    logger.info(
      `[${CreatorAIPersonalityController} addCreatorAIPersonality API response success]`
    );

    res.send({
      statusCode: 201,
      data: add_creator_ai_personality,
      message: "Creator AI Personality Saved Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorAIPersonalityController} addCreatorAIPersonality API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Updates or creates the AI Personality settings for a specific creator.
 *
 * This function handles the updating of AI Personality settings of a creator in the CreatorAIPersonality
 * collection. It first checks if the creator exists and then verifies whether AI Personality settings already exist
 * for this creator. If the settings don't exist, it creates new AI Personality settings. If they do exist, it updates
 * the existing settings based on the provided request data. Additionally, it updates the 'has_ai_personality' flag in
 * the creator's details if needed.
 *
 * @returns {void}
 *   - If new AI Personality settings are created, returns a 201 status code with the new data and a success message.
 *   - If existing AI Personality settings are updated, also returns a 201 status code with the updated data and a success message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a Creator and CreatorAIPersonality model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 *   This function logs the request body and the updated AI Personality settings for debugging purposes.
 */

module.exports.updateCreatorAIPersonality = async (req, res, next) => {
  try {
    // console.log("Body", req.body)


    const check_creator_details = await Creator.findById(req.creator.id);

    const check_if_creator_ai_personality_exist = await CreatorAIPersonality.findOne({
      creator_id: req.creator.id
    });

    if(!check_if_creator_ai_personality_exist){
      const add_creator_ai_personality = await CreatorAIPersonality.create({
        ... req.body,
        creator_id : req.creator.id
      })
      res.send({
        statusCode: 201,
        data: add_creator_ai_personality,
        message: "Creator AI Personality added successfully",
        error: null,
      });

      if(!check_creator_details?.has_ai_personality){
        check_creator_details.has_ai_personality = true;
        await check_creator_details.save()
      }

      logger.info(
        `[${CreatorAIPersonalityController} updateCreatorAIPersonality API response success]`
      );
    }else{
      const updatedCreatorAIPersonality = await CreatorAIPersonality.updateOne(
        { creator_id: req.creator.id },
        { ...req.body },
        { new: true } // This option ensures that the updated document is returned
      );

      const getUpdatedPersonality = await CreatorAIPersonality.findOne(
        { creator_id: req.creator.id },
      );

      if(!check_creator_details?.has_ai_personality){
        check_creator_details.has_ai_personality = true;
       await check_creator_details.save()
      }

      // console.log("updatedCreatorAIPersonality",getUpdatedPersonality)
      
      logger.info(
        `[${CreatorAIPersonalityController} updateCreatorAIPersonality API response success]`
      );
      res.send({
        statusCode: 201,
        data: getUpdatedPersonality,
        message: "Creator AI Personality updated successfully",
        error: null,
      });
    }   
  } catch (error) {
    logger.error(
      `[${CreatorAIPersonalityController} updateCreatorAIPersonality API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



/**
 * Deletes the AI Personality settings for a specific creator.
 *
 * This function is responsible for removing a creator's AI Personality settings from the CreatorAIPersonality 
 * collection. It identifies the AI Personality settings to be deleted using the creator's ID provided in the request.
 * After successful deletion, it logs the information and sends a response indicating success.
 *
 * @returns {void}
 *   - On successful deletion, returns a 200 status code with a message indicating successful deletion.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorAIPersonality model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   It uses a logger for logging information and errors.
 */

module.exports.deleteCreatorAIPersonality = async (req, res, next) => {
  try {
    const creator_bank_details = await CreatorAIPersonality.deleteOne(
      { creator_id: req.creator.id }
    );
    logger.info(
      `[${CreatorAIPersonalityController} deleteCreatorAIPersonality API response success]`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: "Creator AI Personality deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorAIPersonalityController} deleteCreatorAIPersonality API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
