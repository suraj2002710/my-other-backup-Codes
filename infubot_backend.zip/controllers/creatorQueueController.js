const logger = require("winston");
const { Creator } = require("../models/Creator");
// const {load_to_audio_call_notification_queue,pauseWorker, resumeWorker,drainAllJobs,listPendingJobs,getQueueInformation,removeJobById} = require("../queue_infra/bullmq_producer");

const creatorQueueController = "CREATOR_QUEUE_CONTROLLER";

module.exports.getAllWaitingUsersOfTheCreatorInQueue = async (req, res, next) => {
  // try {
  //   let creator = await Creator.findById(req.creator.id);

  //   if (!creator) {
  //     return res.send({
  //       statusCode: 400,
  //       message: "Creator doesn't exist",
  //       error: null,
  //     });
  //   }
  //   const get_waiting_users_list = await listPendingJobs(creator);
  //   logger.info(
  //     `[${creatorQueueController}] getVersionDetails API response success`
  //   );
  //   if(get_waiting_users_list){
  //       res.send({
  //           statusCode: 200,
  //           data: get_waiting_users_list,
  //           message: "Queue Waiting Users List",
  //           error: null,
  //         });
  //   }else{
  //       res.send({
  //           statusCode: 400,
  //           data: null,
  //           message: "Unable to retrieve queue waiting users list",
  //           error: null,
  //         });
  //   }

  // } catch (error) {
  //   logger.error(
  //     `[${creatorQueueController} getVersionDetails API response error:- ${error.message}`
  //   );
  //   res.send({
  //     statusCode: 500,
  //     data: null,
  //     message: null,
  //     error: error.message,
  //   });
  // }
};

module.exports.getCreatorQueueInformation = async (req, res, next) => {
  // try {
  //   let creator = await Creator.findById(req.creator.id);

  //   if (!creator) {
  //     return res.send({
  //       statusCode: 400,
  //       message: "Creator doesn't exist",
  //       error: null,
  //     });
  //   }
  //   const get_queue_information = await getQueueInformation(creator);
  //   logger.info(
  //     `[${creatorQueueController}] getVersionDetails API response success`
  //   );
  //   if(get_queue_information){
  //       res.send({
  //           statusCode: 200,
  //           data: get_queue_information,
  //           message: "Queue Information was successfully retrieved",
  //           error: null,
  //         });
  //   }else{
  //       res.send({
  //           statusCode: 400,
  //           data: null,
  //           message: "Unable to retrieve queue information",
  //           error: null,
  //         });
  //   }

  // } catch (error) {
  //   logger.error(
  //     `[${creatorQueueController} getVersionDetails API response error:- ${error.message}`
  //   );
  //   res.send({
  //     statusCode: 500,
  //     data: null,
  //     message: null,
  //     error: error.message,
  //   });
  // }
};

module.exports.pauseCreatorQueue = async (req, res, next) => {
  // try {
  //   let creator = await Creator.findById(req.creator.id);

  //   if (!creator) {
  //     return res.send({
  //       statusCode: 400,
  //       message: "Creator doesn't exist",
  //       error: null,
  //     });
  //   }
  //   const get_queue_information = await pauseWorker(creator);
  //   logger.info(
  //     `[${creatorQueueController}] getVersionDetails API response success`
  //   );
  //   if(get_queue_information){
  //       res.send({
  //           statusCode: 200,
  //           data: get_queue_information,
  //           message: "Queue Worker Paused successfully",
  //           error: null,
  //         });
  //   }else{
  //       res.send({
  //           statusCode: 400,
  //           data: null,
  //           message: "Unable to pause queue worker",
  //           error: null,
  //         });
  //   }

  // } catch (error) {
  //   logger.error(
  //     `[${creatorQueueController} getVersionDetails API response error:- ${error.message}`
  //   );
  //   res.send({
  //     statusCode: 500,
  //     data: null,
  //     message: null,
  //     error: error.message,
  //   });
  // }
};

module.exports.resumeCreatorQueue = async (req, res, next) => {
  // try {
  //   let creator = await Creator.findById(req.creator.id);

  //   if (!creator) {
  //     return res.send({
  //       statusCode: 400,
  //       message: "Creator doesn't exist",
  //       error: null,
  //     });
  //   }
  //   const get_queue_information = await resumeWorker(creator);
  //   logger.info(
  //     `[${creatorQueueController}] getVersionDetails API response success`
  //   );
  //   if(get_queue_information){
  //       res.send({
  //           statusCode: 200,
  //           data: get_queue_information,
  //           message: "Queue Worker resumed successfully",
  //           error: null,
  //         });
  //   }else{
  //       res.send({
  //           statusCode: 400,
  //           data: null,
  //           message: "Unable to resume queue worker",
  //           error: null,
  //         });
  //   }

  // } catch (error) {
  //   logger.error(
  //     `[${creatorQueueController} getVersionDetails API response error:- ${error.message}`
  //   );
  //   res.send({
  //     statusCode: 500,
  //     data: null,
  //     message: null,
  //     error: error.message,
  //   });
  // }
};

module.exports.removeUserFromQueue = async (req, res, next) => {
  // try {
  //   const {creator_id, job_id} = req.body;

  //   let creator = await Creator.findById(creator_id);

  //   if (!creator) {
  //     return res.send({
  //       statusCode: 400,
  //       message: "Creator doesn't exist",
  //       error: null,
  //     });
  //   }


  //   const get_queue_information = await removeJobById(creator,job_id);
  //   logger.info(
  //     `[${creatorQueueController}] getVersionDetails API response success`
  //   );
  //   if(get_queue_information){
  //       res.send({
  //           statusCode: 200,
  //           data: get_queue_information,
  //           message: "Queue Worker resumed successfully",
  //           error: null,
  //         });
  //   }else{
  //       res.send({
  //           statusCode: 400,
  //           data: null,
  //           message: "Unable to resume queue worker",
  //           error: null,
  //         });
  //   }

  // } catch (error) {
  //   logger.error(
  //     `[${creatorQueueController} getVersionDetails API response error:- ${error.message}`
  //   );
  //   res.send({
  //     statusCode: 500,
  //     data: null,
  //     message: null,
  //     error: error.message,
  //   });
  // }
};
