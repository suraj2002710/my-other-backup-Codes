const { Version } = require("../models/Versions");

const logger = require("winston");

const versionController = "VERSION_CONTROLLERS";

module.exports.getVersionDetails = async (req, res, next) => {
  try {
    const version = await Version.find();
    logger.info(
      `[${versionController}] getVersionDetails API response success`
    );
    res.send({
      statusCode: 200,
      data: version,
      message: "Version fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${versionController} getVersionDetails API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getLatestVersion = async (req, res, next) => {
  try {
    const version = await Version.findOne({}, {}, { sort: { createdAt: -1 } });
    logger.info(`[${versionController}] getLatestVersion API response success`);
    res.send({
      statusCode: 200,
      data: version,
      message: "Latest version fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${versionController} getLatestVersion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addVersion = async (req, res, next) => {
  try {
    const version = await Version.create(req.body);
    logger.info(`[${versionController}] addVersion API response success`);
    res.send({
      statusCode: 200,
      data: version,
      message: "Version added successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${versionController} addVersion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
