const { Creator } = require("../models/Creator");
const { CreatorContentGallery } = require("../models/creatorContentGallery");
const { CreatorFlagger } = require("../models/creatorFlagAndReportHandler");
const { ChatHistory } = require("../models/ChatHistory");
const { Conversation } = require("../models/Conversation");
const VideoConnectivty = require("../models/VideoConnection");
const AudioConnectivty = require("../models/AudioConnection");
const { OTPSecretMapper } = require("../models/OTPSecretMapper");
const { UserVisit } = require("../models/UserVisits");
const { User } = require("../models/Users");
const { sendOTPEmail } = require("../services/emailNotification");
const _ = require("lodash");
const jwt = require("jsonwebtoken");
const admin = require("firebase-admin");
const path = require("path");
const mongoose = require("mongoose");
const { createConversation, sendMessage } = require("../services/common");
const { storeUserConversation } = require("../services/storeUserConversation");

const { getNotificationsByCreatorEmail } = require("../services/notificationStore");

const bcrypt = require("bcryptjs");

const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { Wallet } = require("../models/Wallet");
const { renameImage } = require("../services/renameImage");
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { HashMapper } = require("../models/HashMapper");
const { generateRandomHash } = require("../utilities/hasher");
const { generateHashAndStoreOTP, verifyOTP, generateOTP } = require("../otp_infra");
const { notifyCreatorAboutLoginOTP } = require("../mailing_service");
const { CreatorFineTune } = require("../models/CreatorFineTune");
// const redis = require("../queue_infra/redis_connection");

// const {config} = require("../queue_infra/redis_config");
// const io_redis = require('ioredis');
// const publisher = new io_redis(config);

const { axios } = require("axios");

const fs = require("fs");

const CreatorController = "CREATOR_CONTROLLER";

const s3 = new S3Client({
   region: process.env.AWS_S3_REGION,
   credentials: {
      accessKeyId: process.env.AWS_KEY,
      secretAccessKey: process.env.AWS_SECRET,
   },
});

//kafka instance
const kafkaServiceInstance = require("../kafka/index");
const { getIoInstance } = require("../socket_chat_infra");
const QueueData = require("../models/QueueData");
// const KafkaService = require("../kafka/service/kafkaService");

//AWS Configuration
async function generatePresignedUrl(bucketName, key, expiresInSeconds) {
   const params = {
      Bucket: bucketName,
      Key: key,
      ResponseContentDisposition: "inline",
   };

   try {
      const command = new GetObjectCommand(params);
      return await getSignedUrl(s3, command, { expiresIn: expiresInSeconds });
   } catch (error) {
      throw error;
   }
}
/**
 * API controller to retrieve all creator profiles.
 **/
// module.exports.getAllCreators = async (req, res, next) => {
//   try {
//     const creators = await Creator.find({});
//     logger.info(`[${CreatorController} getAllCreators API response success]`);
//     const updatedCreators = creators.map((creator) => {
//       return {
//         ...creator.toObject(),
//         profile_pic: creator.profile_pic
//           ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic
//           : "",
//       };
//     });
//     res.send({
//       statusCode: 200,
//       data: updatedCreators,
//       message: "Creator lists fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${CreatorController} getAllCreators API response error:- ${error.message}]`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.getAllCreators = async (req, res, next) => {
   try {
      const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not specified
      const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page if not specified
      const skip = (page - 1) * limit;

      const totalCreators = await Creator.countDocuments({}); // Get total count of creators
      const creators = await Creator.find({}).skip(skip).limit(limit);

      logger.info(`[${CreatorController} getAllCreators API response success]`);

      const updatedCreators = creators.map((creator) => ({
         ...creator.toObject(),
         profile_pic: creator.profile_pic ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic : "",
      }));

      // Determine if there's a next page
      const hasNextPage = page * limit < totalCreators;
      const nextPageUrl = hasNextPage ? `${process.env.BASE_URL_FOR_IMAGES}api/creator/all?page=${page + 1}&limit=${limit}` : null;

      res.status(200).json({
         statusCode: 200,
         data: updatedCreators,
         nextPage: nextPageUrl,
         message: "Creator lists fetched successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getAllCreators API response error:- ${error.message}]`);
      res.status(500).json({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * API controller for retrieving detailed information about a specific creator.
 *
 * The endpoint expects the creator's ID to be passed in the request object (req.creator.id).
 * If the creator exists, their details are returned; otherwise, a 400 status code is returned
 * indicating the creator does not exist.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response with the creator's details or an error message.
 *   - On success, it sends a 200 status code with the creator's details.
 *   - If the creator is not found, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */

module.exports.getCreatorDetails = async (req, res, next) => {
   try {
      console.log("apu called///////////", req.params.id);
      const creator = await Creator.findById(req.params.id);
      if (!creator) {
         return res.status(400).json({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }
      logger.info(`[${CreatorController} getCreatorDetails API response success]`);

      let findCreatorBot = await CreatorBotSetting.findOne({ creator_id: req.params.id });
      let creatorFineTuneData = await CreatorFineTune.findOne({ creator_id: req.params.id });
      let creatorData = {
         id: creator.id,
         CID: creator.CID,
         name: creator.first_name + " " + creator.last_name,
         username: creator.username,
         email: creator.email,
         phone: creator.phone,
         dob: creator.dob,
         gender: creator.gender,
         instagram_url: creator.instagram_url,
         email: creator.email,
         bot_name: findCreatorBot.bot_name,
         bot_language: findCreatorBot.bot_language,
         message: findCreatorBot.message,
         cost_per_msg: findCreatorBot.cost_per_msg,
         cost_per_ai_msg: findCreatorBot.cost_per_ai_msg,
         cost_audio_per_min: findCreatorBot.cost_audio_per_min,
         cost_video_per_min: findCreatorBot.cost_video_per_min,
         cosy_of_voice_message_per_minute: findCreatorBot.cosy_of_voice_message_per_minute,
         cost_of_single_image: findCreatorBot.cost_of_single_image,
         cost_of_single_video: findCreatorBot.cost_of_single_video,
         modest: creatorFineTuneData.modest,
         flirty: creatorFineTuneData.flirty,
         friendly: creatorFineTuneData.friendly,
         aggressive: creatorFineTuneData.aggressive,
         quiet: creatorFineTuneData.quiet,
         loud: creatorFineTuneData.loud,
         kind: creatorFineTuneData.kind,
         sarcastic: creatorFineTuneData.sarcastic,
         text_suggestion: findCreatorBot.textSuggestion,
      };

      res.status(200).json({
         statusCode: 200,
         data: { creatorData },
         message: "Creator details fetched successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorDetails API response error:- ${error.message}]`);
      res.status(500).json({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * API controller for creating a new creator profile.
 *
 * This asynchronous function handles a POST request to create a new creator in the database.
 * It validates required fields (phone number, email, and password), hashes the password,
 * checks for existing creator with the same email or phone number, and then creates a new creator.
 * Upon successful creation, it sends a JWT token along with creator details in the response.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response with the newly created creator's details or an error message.
 *   - On successful creation, it sends a 201 status code with the creator's details.
 *   - If required fields are missing, or if the email/phone number already exists, it sends a 404 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.createCreator = async (req, res, next) => {
   try {
      const requiredFields = {
         phone_number: "Phone number",
         email: "Email",
         password: "Password",
      };

      const missingFields = Object.entries(requiredFields)
         .filter(([field, label]) => req.body[field] === undefined)
         .map(([field, label]) => label);

      if (missingFields.length > 0) {
         return res.status(500).send({
            statusCode: 500,
            data: null,
            message: null,
            error: `${missingFields.join(" and ")} ${missingFields.length > 1 ? "are" : "is"} required.`,
         });
      }

      const salt = await bcrypt.genSalt(10);
      req.body.password = await bcrypt.hash(req.body.password, salt);

      let isCreatorExists = await Creator.findOne({ email: req.body.email });
      let isPhoneNumberExixts = await Creator.findOne({
         phone_number: req.body.phone_number,
      });
      if (isCreatorExists)
         return res.status(400).json({
            statusCode: 404,
            data: null,
            message: null,
            error: `Email already exists!`,
         });
      if (isPhoneNumberExixts) {
         return res.status(400).json({
            statusCode: 404,
            data: null,
            message: null,
            error: "Phone Number already exists!",
         });
      }
      function generateUUID() {
         const hexDigits = "0123456789abcdef";
         let uuid = "";

         for (let i = 0; i < 32; i++) {
            if (i === 8 || i === 12 || i === 16 || i === 20) {
               uuid += "-";
            }
            uuid += hexDigits.charAt(Math.floor(Math.random() * 16));
         }

         return uuid;
      }

      const uuid = generateUUID();

      let createCreator = await Creator.create({ ...req.body, CID: uuid });
      await createCreator.save();
      let creatorFineTuneData = await CreatorFineTune.create({ creator_id: createCreator.id });
      await CreatorBotSetting.create({ creator_id: createCreator._id });
      if (createCreator) {
         let apiData = {
            apiUrl: process.env.AI_BASE_URL + "/collected_user_info",
            headers: {
               "content-type": "application/json",
            },
            body: {
               CID: uuid,
               Name: `${createCreator.first_name} ${createCreator.last_name}`,
               "Date of Birth": createCreator.dob,
               Facebook: "https://www.facebook.com/None",
               Instagram: createCreator.instagram_url.split("?")[0],
               Twitter: "https://twitter.com/None",
            },
         };

         console.log("apiData", apiData);
         fetch(apiData.apiUrl, {
            method: "POST",
            headers: {
               "Content-Type": "application/json",
            },
            body: JSON.stringify(apiData.body),
         })
            .then((response) => response.json())
            .then((data) => {
               console.log("--AI api Response-------", data);
            })
            .catch((error) => {
               console.error("----------Error in AI collected_user_info----------:", error);
            });
      }
      // const token = jwt.sign(
      //   { id: createCreator.id, email: createCreator.email, role: "creator" },
      //   process.env.CreatorSecretKey
      // );

      let creator = _.pick(createCreator, ["id", "first_name", "last_name", "email", "phone_number", "username", "instagram_url"]);

      console.log("-------------------------Creator-----------------------", creator);

      // creator.token = token;
      creator.profile_pic = creator.profile_pic ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic : "";

      creator.bot_link = process.env.BASE_URL_FOR_CREATOR + "/" + creator.username; // Assigning to creator.bot_link

      logger.info(`[${CreatorController} createCreator API response success]`);

      // trigger otp to user email for verification
      sendOTPEmail(createCreator.email);

      res.status(201).json({
         statusCode: 201,
         data: creator,
         message: "Creator created successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getAllCreators API response error:- ${error.message}]`);
      res.status(500).json({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * API controller for sending an OTP (One Time Password) email to a creator.
 *
 * This asynchronous function handles a POST request to send an OTP to the provided email address.
 * It checks if the email address is provided in the request body and then triggers the `sendOTPEmail` function
 * to send the OTP email to the specified email address.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response indicating the success or failure of sending the OTP email.
 *   - If the email is sent successfully, it sends a 201 status code with a success message.
 *   - If the email field is missing in the request body, it sends a 504 status code with an error message.
 *   - On server or database errors, it sends a 201 status code with the error message.
 */
module.exports.sendOTPEmailModule = async (req, res, next) => {
   try {
      if (!req.body.email) {
         res.send({
            statusCode: 504,
            data: null,
            message: null,
            error: "email not found",
         });
      }

      // send otp to creator
      sendOTPEmail(req.body.email);

      res.send({
         statusCode: 201,
         data: req.body,
         message: "OTP send to Creator successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} sendOTPEmailModule API response error:- ${error.message}]`);
      res.send({
         statusCode: 201,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * API controller for retrieving the profile of a specific creator.
 *
 * This asynchronous function handles a GET request to fetch the profile of a creator based on their ID.
 * The creator's ID is expected to be passed in the request object (req.creator.id). If the creator exists,
 * their profile details, including a profile picture link and bot link, are returned. If the creator does not exist,
 * a 400 status code is returned with an appropriate message.
 *
 * @returns {void}
 *   The function sends back a JSON response with the creator's profile or an error message.
 *   - On success, it sends a 200 status code with the creator's profile details.
 *   - If the creator is not found, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.getCreatorProfile = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      creator = creator.toObject();
      creator.profile_pic = creator.profile_pic ? creator.profile_pic : "";
      creator.bot_link = process.env.MY_AI_FRONTEND_DEPLOY_URL + creator.username;

      logger.info(`[${CreatorController} createCreator API response success]`);
      res.send({
         statusCode: 200,
         data: creator,
         message: "Creator profile captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorFineTuneData = async (req, res, next) => {
   try {
      console.log("called...", req.creator.id);
      if (req.creator.id) {
         let isFineTuneDataExist = await CreatorFineTune.find({ creator_id: req.creator.id });
         if (isFineTuneDataExist) {
            return res.status(200).json({
               statusCode: 200,
               message: "fetch successfully.",
               data: isFineTuneDataExist,
            });
         }

         return res.status(400).json({
            statusCode: 400,
            message: "failed to get fine tune data.",
            data: [],
         });
      }

      return res.status(400).json({
         statusCode: 400,
         message: "creator id is required.",
      });
   } catch (error) {
      return res.status(400).json({
         statusCode: 400,
         message: error.message,
      });
   }
};

module.exports.updateCreatorFineTuneData = async (req, res) => {
   try {
      console.log("called....", req.creator.id);
      let updateFineTuneData = await CreatorFineTune.findOneAndUpdate({ creator_id: req.creator.id }, req.body, { new: true });
      if (updateFineTuneData) {
         return res.status(200).json({
            statusCode: 200,
            message: "update successfully.",
         });
      }
      return res.status(400).json({
         statusCode: 400,
         message: "failed to update.",
      });
   } catch (error) {
      return res.status(400).json({
         statusCode: 400,
         message: error.message,
      });
   }
};

//With Redis Caching
// module.exports.getCreatorProfile = async (req, res, next) => {
//   try {
//     const redisKey = `creator_profile:${req.creator.id}`;

//     // Attempt to retrieve the creator profile from Redis cache
//     const cachedProfile = await redis.get(redisKey);
//     if (cachedProfile) {
//       logger.info(`[CreatorController] Creator profile fetched from cache`);
//       return res.send({
//         statusCode: 200,
//         data: JSON.parse(cachedProfile),
//         message: "Creator profile captured successfully from cache",
//         error: null,
//       });
//     }

//     let creator = await Creator.findById(req.creator.id);
//     if (!creator) {
//       return res.send({
//         statusCode: 400,
//         message: "Creator doesn't exist",
//         error: null,
//       });
//     }

//     creator = creator.toObject();
//     creator.profile_pic = creator.profile_pic
//       ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic
//       : "";
//     creator.bot_link = process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;

//     // Cache the modified creator profile for future requests
//     await redis.set(redisKey, JSON.stringify(creator), 'EX', 120); // Cache for 24 hours

//     logger.info(`[CreatorController] getCreatorProfile API response success`);
//     res.send({
//       statusCode: 200,
//       data: creator,
//       message: "Creator profile captured successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[CreatorController] getCreatorProfile API response error:- ${error.message}`);
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.checkIfEmailAlreadyExist = async (req, res, next) => {
   try {
      let creator = await Creator.findOne({
         email: req.body.email,
      });
      logger.info(`[${CreatorController} createCreator API response success]`);
      if (creator) {
         return res.send({
            statusCode: 400,
            message: "Email is available",
            error: null,
         });
      } else {
         return res.send({
            statusCode: 400,
            message: "Email is not available",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * API controller for retrieving the profile and bot settings of a specific creator for users.
 *
 * This asynchronous function handles a GET request to fetch the profile and bot settings of a creator based on their username.
 * The creator's username is expected to be passed in the request body (req.body.username). If the creator exists,
 * their profile details along with specific bot settings are returned. If the creator does not exist, a 400 status code
 * is returned with an appropriate message.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response with the creator's profile and bot settings or an error message.
 *   - On success, it sends a 200 status code with the creator's details and bot settings.
 *   - If the creator is not found, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.getCreatorProfileForUser = async (req, res, next) => {
   try {
      if (!req.params.creator_username) {
         return res.status(400).json({
            statusCode: 400,
            data: null,
            message: "Creator username is required in params",
            error: null,
         });
      }
      // const redis_key = `creator_profile:${req.params.creator_username}`
      // const cachedData = await redis.get(redis_key);
      // if (cachedData) {
      //   logger.info(`[${CreatorController} getCreatorProfileForUser API response from cache]`);
      //   return res.send({
      //     statusCode: 200,
      //     data: JSON.parse(cachedData),
      //     message: "Creator details retrieved from cache",
      //     error: null,
      //   });
      // }

      const creator = await Creator.findOne({ username: req.params.creator_username });

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      const creator_bot_setting = await CreatorBotSetting.findOne({
         creator_id: creator.id,
      });

      const creator_details = {
         id: creator.id,
         first_name: creator.first_name,
         last_name: creator.last_name,
         email: "",
         bot_link: process.env.BASE_URL_FOR_CREATOR + "/" + creator.username,
         phone_number: creator.phone_number,
         bot_title: creator_bot_setting?.bot_title,
         bot_language: creator_bot_setting?.bot_language,
         bot_message: creator_bot_setting?.message,
         cost_per_msg: (creator_bot_setting?.cost_per_msg).toString(),
         cost_audio_per_min: (creator_bot_setting?.cost_audio_per_min).toString(),
         cost_video_per_min: (creator_bot_setting?.cost_video_per_min).toString(),
         enable_audio: creator_bot_setting?.enable_audio,
         enable_video: creator_bot_setting?.enable_video,
         bot_color_code: creator_bot_setting?.bot_color_code,
         show_suggestion: creator_bot_setting?.show_suggestion,
         show_link_suggestion: creator_bot_setting?.show_link_suggestion,
         show_welcome_popup: creator_bot_setting?.show_welcome_popup,
         textSuggestion: creator_bot_setting?.textSuggestion,
         showLinkSuggestion: creator_bot_setting?.showLinkSuggestion,
         profile_pic: creator.profile_pic ? creator.profile_pic : "",
      };

      // Store data in Redis cache
      // redis.set(redis_key, JSON.stringify(creator_details),'EX', 60);

      logger.info(`[${CreatorController} getCreatorProfileForUser API response success]`);
      res.send({
         statusCode: 200,
         data: creator_details,
         message: "Creator details captured successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfileForUser API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

//With Redis Caching

/**
 * API controller for updating a creator's profile.
 *
 * This asynchronous function handles a PATCH/PUT request to update the profile of a creator.
 * It checks if the creator exists based on the ID provided in the request object (req.creator.id).
 * If the creator exists, their profile is updated based on the provided request body.
 * If the creator does not exist, a 400 status code is returned with an appropriate message.
 * Additionally, the function handles the upload of a profile picture if provided in the request.
 *
 * @returns {void}
 *   The function sends back a JSON response with the updated creator's profile or an error message.
 *   - On successful update, it sends a 200 status code with the updated creator's details.
 *   - If the creator's status is updated to 'dnd' or 'available', it sends a 200 status code with a specific message regarding AI Mode.
 *   - If the creator is not found, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
// module.exports.updateCreatorProfile = async (req, res, next) => {
//   try {

//     const check_creator = await Creator.findById(req.creator.id);

//     if(!check_creator){
//       return res.send({
//         statusCode: 400,
//         message: "Creator doesn't exist",
//         error: null,
//       });
//     }

//     let updateCreator = req.body;
//     if (updateCreator?.password) {
//       delete updateCreator.password;
//     }

//     if (req.file) {
//       let { originalname, destination } = req.file;

//       renameImage(req.file);

//       image = destination + "/" + originalname;
//     }
//     if (req.file) {
//       updateCreator.profile_pic = image;
//     }

//     const creator = await Creator.findOneAndUpdate(
//       { _id: req.creator.id },
//       { $set: updateCreator }
//     );

//     logger.info(
//       `[${CreatorController} updateCreatorProfile API response success]`
//     );

//     if (
//       updateCreator?.dnd_mode == true
//     ) {
//       return res.send({
//         statusCode: 200,
//         data: creator,
//         message: "DND Mode Turned On Successfully",
//         error: null,
//       });
//     } else if(updateCreator?.dnd_mode == false){
//       return res.send({
//         statusCode: 200,
//         data: creator,
//         message: "DND Mode Turned Off Successfully",
//         error: null,
//       });
//     }else if (
//       updateCreator?.creator_status &&
//       updateCreator?.creator_status === "available"
//     ) {
//       return res.send({
//         statusCode: 200,
//         data: creator,
//         message: "AI Mode Switched Off Successfully",
//         error: null,
//       });
//     }else if (
//       updateCreator?.creator_status &&
//       updateCreator?.creator_status === "ai_mode"
//     ) {
//       return res.send({
//         statusCode: 200,
//         data: creator,
//         message: "AI Mode Turn On Successfully",
//         error: null,
//       });
//     } else {
//       res.send({
//         statusCode: 200,
//         data: creator,
//         message: "Creator updated successfully",
//         error: null,
//       });
//     }
//   } catch (error) {
//     logger.error(
//       `[${CreatorController} updateCreatorProfile API response error:- ${error.message}]`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.updateCreatorProfile = async (req, res, next) => {
   try {
      const creatorId = req.creator.id;
      const updateCreator = { ...req.body };

      // console.log("Body", updateCreator);

      // Check if the creator exists
      const checkCreator = await Creator.findById(creatorId);
      if (!checkCreator) {
         return res.status(400).send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      // Prevent password updates through this API
      if (updateCreator.password) {
         delete updateCreator.password;
      }

      // Handle file upload
      if (req.body.profilePicUrl) {
         console.log("come in profile pic..............");
         // Assuming renameImage function modifies the file name and updates the file path
         // renameImage(req.file);
         updateCreator.profile_pic = req.body.profilePicUrl; // Use the updated file path after rename
      }

      // Update the creator profile
      const updatedCreator = await Creator.findByIdAndUpdate(creatorId, updateCreator, { new: true });

      if (Object.keys(updateCreator).includes("creator_status")) {
         const io = getIoInstance();
         if (!io) {
            console.error("Socket.IO instance is not initialized.");
         }

         io.to(`${creatorId}_users`).emit("creator_mode", {
            message: `${updatedCreator.first_name}.ai is now live`,
            type: "ai_mode",
            ai_mode: updateCreator.creator_status === "ai_mode" ? true : false,
         });
      }
      if (updateCreator.dnd_mode == "true" || updateCreator.dnd_mode == true) {
         //queue data delete for creator
         QueueData.deleteMany({ creator_id: creatorId })
            .then((result) => {
               if (result.deletedCount > 0) {
                  const io = getIoInstance();
                  if (!io) {
                     console.error("Socket.IO instance is not initialized.");
                  }

                  io.to(`${creatorId}_users`).emit("You_are_next", { message: "DND" });
               }
               console.log("Number of documents deleted:", result.deletedCount);
            })
            .catch((err) => {
               console.error("Error deleting documents:", err);
            });

         //kafka topic delete
         kafkaServiceInstance.listTopics().then((topics) => {
            if (topics.includes(`creator_${creatorId}_calls`)) {
               kafkaServiceInstance.deleteTopic(`creator_${creatorId}_calls`);
            } else {
               console.log("Topic not exist");
            }
         });
      } else if (updateCreator.dnd_mode == "false" || updateCreator.dnd_mode == false) {
         //kafka topic create
         kafkaServiceInstance.listTopics().then(async (topics) => {
            if (topics.includes(`creator_${creatorId}_calls`)) {
               console.log("Topic already exist");
            } else {
               const io = getIoInstance();
               if (!io) {
                  console.error("Socket.IO instance is not initialized.");
               }
               await kafkaServiceInstance.createTopic(`creator_${creatorId}_calls`, 2, 2);
               await kafkaServiceInstance.initConsumer(`creator_${creatorId}_calls`);
               await kafkaServiceInstance.startConsuming(`creator_${creatorId}_calls`, io);
            }
         });
      }

      logger.info(`[${CreatorController} updateCreatorProfile API response success]`);

      // Generate a custom message based on the update
      let message = "Creator updated successfully";
      if (updateCreator.dnd_mode !== undefined) {
         message = `DND Mode Turned ${updateCreator.dnd_mode ? "On" : "Off"} Successfully`;
      } else if (updateCreator.creator_status) {
         message = `AI Mode ${updateCreator.creator_status === "ai_mode" ? "Turned On" : "Switched Off"} Successfully`;
      }

      // if(updateCreator.creator_status == "ai_mode" || updateCreator.creator_status == "available"){
      //   // console.log("----",updatedCreator)
      //   publisher.publish("creator_flutter_modes", JSON.stringify(updatedCreator));
      // }

      // Send response
      res.status(200).send({
         statusCode: 200,
         data: updatedCreator,
         message: message,
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} updateCreatorProfile API response error:- ${error.message}]`);
      res.status(500).send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.updateCreatorProfileV2 = async (req, res, next) => {
   try {
      const creatorId = req.creator.id;
      const updateCreator = { ...req.body };

      // console.log("Body", updateCreator);

      // Check if the creator exists
      const checkCreator = await Creator.findById(creatorId);
      if (!checkCreator) {
         return res.status(400).send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      // Prevent password updates through this API
      if (updateCreator.password) {
         delete updateCreator.password;
      }

      // Handle file upload
      if (req.file) {
         // Assuming renameImage function modifies the file name and updates the file path
         // renameImage(req.file);
         // updateCreator.profile_pic = req.file.destination + "/" + req.file.originalname; // Use the updated file path after rename
         const { key } = req.file;
         updateCreator.profile_pic = `${process.env.BASE_URL_FOR_IMAGES}api/creator/profile_pic/view/${key}`;
         // updateCreator.profile_pic = `https://influbot.s3.amazonaws.com/${key}`
      }

      // Update the creator profile
      const updatedCreator = await Creator.findByIdAndUpdate(creatorId, updateCreator, { new: true });

      logger.info(`[${CreatorController} updateCreatorProfile API response success]`);

      // Generate a custom message based on the update
      let message = "Creator updated successfully";
      if (updateCreator.dnd_mode !== undefined) {
         message = `DND Mode Turned ${updateCreator.dnd_mode ? "On" : "Off"} Successfully`;
      } else if (updateCreator.creator_status) {
         message = `AI Mode ${updateCreator.creator_status === "ai_mode" ? "Turned On" : "Switched Off"} Successfully`;
      }

      // Send response
      res.status(200).send({
         statusCode: 200,
         data: updatedCreator,
         message: message,
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} updateCreatorProfile API response error:- ${error.message}]`);
      res.status(500).send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * API controller for deleting a creator's profile.
 *
 * This asynchronous function handles a DELETE request to remove a creator's profile from the database.
 * It uses the creator's ID provided in the request parameters (req.params.id) to locate and delete the creator's record.
 * If the deletion is successful, a confirmation message is sent back. In case of errors, an error message is returned.
 *
 * @returns {void}
 *   The function sends back a JSON response with the status of the deletion.
 *   - On successful deletion, it sends a 200 status code with a message confirming the deletion.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.deleteCreatorProfile = async (req, res, next) => {
   try {
      const creator = await Creator.findByIdAndRemove(req.params.id);
      logger.info(`[${CreatorController} deleteCreatorProfile API response success]`);

      res.send({
         statusCode: 200,
         // data: creator,
         message: "Creator deleted successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} deleteCreatorProfile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         // data: creator,
         message: null,
         error: error.message,
      });
   }
};
/**
 * API controller for deleting a creator's account and all associated data.
 *
 * This asynchronous function handles a DELETE request to remove a creator's account and its related data
 * (chat history, conversation history, video call history, wallet history, audio call history) from the database.
 * It uses the creator's ID provided in the request (req.creator.id) to locate and delete the account and related records.
 * If the deletion is successful, a confirmation message is sent back. In case of errors, an error message is returned.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response with the status of the deletion.
 *   - On successful deletion, it sends a 200 status code with a message confirming the deletion.
 *   - If the creator does not exist, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.deleteAccount = async (req, res, next) => {
   try {
      const fetch_creator_details = await Creator.findById(req.creator.id);
      if (!fetch_creator_details) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist now",
            error: null,
         });
      }

      // Cascade delete operations for each related model
      await ChatHistory.deleteMany({ creator_id: fetch_creator_details.email });
      console.log("All Users Chat History Cleared");
      await Conversation.deleteMany({ creator_id: fetch_creator_details.email });
      console.log("All Users Conversation History Cleared");
      await VideoConnectivty.deleteMany({
         creator_id: fetch_creator_details.email,
      });
      console.log("All Users Video Call History Cleared");
      await Wallet.deleteMany({ creator_email: fetch_creator_details.email });
      console.log("All Users Wallet History Cleared");
      await AudioConnectivty.deleteMany({
         creator_id: fetch_creator_details.email,
      });
      console.log("All Users Audio Call History Cleared");
      await Creator.findByIdAndDelete(req.creator.id);
      console.log("Creator Deleted Successfully");

      logger.info(`[${CreatorController} deleteCreatorProfile API response success]`);

      res.send({
         statusCode: 200,
         // data: creator,
         message: "Creator deleted successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} deleteCreatorProfile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         // data: creator,
         message: null,
         error: error.message,
      });
   }
};
/**
 * API controller for handling creator login.
 *
 * This asynchronous function manages POST requests for creator login. It verifies the creator's credentials,
 * updates their FCM token, generates a JWT token for authentication, and returns the creator's details on successful login.
 * If the creator's email is not found or the password is invalid, a 400 status code with an appropriate error message is returned.
 * On server or database errors, a 500 status code with the error message is returned.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response with the creator's details or an error message.
 *   - On successful login, it sends a 200 status code with the creator's details, including a JWT token.
 *   - If the email is not found or the password is invalid, it sends a 400 status code with an appropriate message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.postLogin = async (req, res, next) => {
   try {
      // console.log("Body", req.body)
      let creator = await Creator.findOne({ email: req.body.email });
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Email is not found",
         });

      // if (creator?.is_logged_in) {
      //   return res.send({
      //     statusCode: 400,
      //     data: null,
      //     message: null,
      //     error: "Creator is already logged in on one device",
      //   });
      // }

      // await OTPSecretMapper.create({
      //   id : creator.id,
      //   secret_value : generateSecret()
      // })

      let validatePassword = await bcrypt.compare(req.body.password, creator.password);
      if (!validatePassword)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Invalid Password",
         });

      // const update_all_hashmap_value_of_creator_to_false = await HashMapper.updateMany({ id : creator.id }, { $set: {
      //     active : false
      // }});

      const hash = generateRandomHash();
      const ipAddress = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
      // console.log("Client IP Address:", ip);
      const save_user_hash = await HashMapper.create({
         id: creator.id,
         secret_value: hash,
         ip,
      });

      // const creatorRequest = creator;
      creator.fcm_token = req.body.fcm_token;
      creator.pushy_device_id = req.body.pushy_device_id;
      creator.is_logged_in = true;
      await creator.save();

      // const updateCreator = await Creator.findByIdAndUpdate(creator.id, {
      //   $set: creatorRequest,
      // });

      // const token = jwt.sign(
      //   { id: creator.id, email: creator.email, role: "creator" },
      //   process.env.CreatorSecretKey
      // );

      const token = jwt.sign({ id: hash, role: "creator" }, process.env.CreatorSecretKey);

      console.log("creator------------------token --------------created-------------", token);
      if (token) {
         console.log("come inside................................");
         let creatorTokenUpdate = await Creator.updateOne({ email: req.body.email }, { $set: { creator_login_token: token } });

         console.log(creatorTokenUpdate);
      }
      creator = _.pick(creator, ["id", "first_name", "last_name", "email", "phone_number", "bio", "profile_pic", "address", "bot_link", "username", "payout_setting"]);
      creator.token = token;
      creator.bot_link = process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;

      logger.info(`[${CreatorController} postLogin API response success]`);

      res.send({
         statusCode: 200,
         data: creator,
         message: "Creator Logged In successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} postLogin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.creatorLoginWithOTP = async (req, res, next) => {
   try {
      let creator = await Creator.findOne({ email: req.body.email });
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Email is not found",
         });

      // if (creator?.is_logged_in) {
      //   return res.send({
      //     statusCode: 400,
      //     data: null,
      //     message: null,
      //     error: "Creator is already logged in on one device",
      //   });
      // }

      // await OTPSecretMapper.create({
      //   id : creator.id,
      //   secret_value : generateSecret()
      // })

      let validatePassword = await bcrypt.compare(req.body.password, creator.password);
      if (!validatePassword)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Invalid Password",
         });

      // const update_all_hashmap_value_of_creator_to_false = await HashMapper.updateMany({ id : creator.id }, { $set: {
      //     active : false
      // }});

      const hash = generateRandomHash();
      const ipAddress = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
      // console.log("Client IP Address:", ip);
      const save_user_hash = await HashMapper.create({
         id: creator.id,
         secret_value: hash,
         ip,
      });

      const otp = await generateOTP();
      const save_otp = await generateHashAndStoreOTP(creator.id);
      if (save_otp) {
         await notifyCreatorAboutLoginOTP(process.env.ADMIN_EMAIL, {
            otp,
            creator,
         });
         logger.info(`[${CreatorController} postLogin API response success]`);
         res.send({
            statusCode: 200,
            data: null,
            message: "OTP sent successfully to your registered email",
            error: null,
         });
      } else {
         res.send({
            statusCode: 400,
            data: null,
            message: "Unable to login at this moment. Please try again later",
            error: null,
         });
      }

      // const creatorRequest = creator;
      // creator.fcm_token = req.body.fcm_token;
      // creator.is_logged_in = true;
      // creator.save()

      // const updateCreator = await Creator.findByIdAndUpdate(creator.id, {
      //   $set: creatorRequest,
      // });

      // const token = jwt.sign(
      //   { id: creator.id, email: creator.email, role: "creator" },
      //   process.env.CreatorSecretKey
      // );

      // const token = jwt.sign(
      //   { id: hash, role: "creator" },
      //   process.env.CreatorSecretKey
      // );

      // creator = _.pick(creator, [
      //   "id",
      //   "first_name",
      //   "last_name",
      //   "email",
      //   "phone_number",
      //   "bio",
      //   "profile_pic",
      //   "address",
      //   "bot_link",
      //   "username",
      //   "payout_setting",
      // ]);
      // creator.token = token;
      // creator.bot_link =
      //   process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;
   } catch (error) {
      logger.error(`[${CreatorController} postLogin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.verifyCreatorLoginOTP = async (req, res, next) => {
   try {
      const { email, otp } = req.body;
      let creator = await Creator.findOne({ email: email });
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Email is not found",
         });

      // if (creator?.is_logged_in) {
      //   return res.send({
      //     statusCode: 400,
      //     data: null,
      //     message: null,
      //     error: "Creator is already logged in on one device",
      //   });
      // }

      // await OTPSecretMapper.create({
      //   id : creator.id,
      //   secret_value : generateSecret()
      // })

      const verify_otp = verifyOTP(creator.id, otp);
      if (verify_otp) {
         res.send({
            statusCode: 200,
            data: creator,
            message: "Creator Logged In successfully",
            error: null,
         });
      } else {
         res.send({
            statusCode: 400,
            data: null,
            message: "OTP Validation failed",
            error: null,
         });
      }

      // const hash = generateRandomHash();
      // const ipAddress =
      //   req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      // const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
      // console.log("Client IP Address:", ip);
      // const save_user_hash = await HashMapper.create({
      //   id: creator.id,
      //   secret_value: hash,
      //   ip,
      // });

      // // const creatorRequest = creator;
      // creator.fcm_token = req.body.fcm_token;
      // creator.is_logged_in = true;
      // creator.save()

      // // const updateCreator = await Creator.findByIdAndUpdate(creator.id, {
      // //   $set: creatorRequest,
      // // });

      // // const token = jwt.sign(
      // //   { id: creator.id, email: creator.email, role: "creator" },
      // //   process.env.CreatorSecretKey
      // // );

      // const token = jwt.sign(
      //   { id: hash, role: "creator" },
      //   process.env.CreatorSecretKey
      // );

      // creator = _.pick(creator, [
      //   "id",
      //   "first_name",
      //   "last_name",
      //   "email",
      //   "phone_number",
      //   "bio",
      //   "profile_pic",
      //   "address",
      //   "bot_link",
      //   "username",
      //   "payout_setting",
      // ]);
      // creator.token = token;
      // creator.bot_link =
      //   process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;

      // logger.info(`[${CreatorController} postLogin API response success]`);
   } catch (error) {
      logger.error(`[${CreatorController} postLogin API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * API controller for sending a notification to a creator.
 *
 * This asynchronous function manages POST requests to send a notification to a creator via Firebase Cloud Messaging (FCM).
 * It first verifies if the creator exists in the database. If the creator does not exist, it returns a 400 status code with a message.
 * After verifying the creator's existence, it generates a conversation with the user and sends a notification to the creator's FCM token.
 * The notification includes details like the user's and creator's IDs, names, and conversation details.
 * If the notification is successfully sent, it responds with a 200 status code. If there is a failure in sending the notification,
 * it catches the error and returns a 400 status code with the error message.
 * In case of any server or database errors, a 500 status code with the error message is returned.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - On successful notification sending, it sends a 200 status code with a success message.
 *   - If the creator is not found or if there's an error in sending the notification, it sends a 400 status code with an error message.
 *   - On server or database errors, it sends a 500 status code with the error message.
 */
module.exports.sendNotificationToCreator = async (req, res, next) => {
   try {
      // console.log("....>>>>><<<>>..>>Send Notification body", req.body);

      let creator = await Creator.findOne({ email: req.body.creatorId });

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      const fetch_user_details = await User.findOne({
         email: req.body.userId,
      });

      if (!fetch_user_details) {
         return res.send({
            statusCode: 400,
            message: "User doesn't exist",
            error: null,
         });
      }

      const check_if_user_has_visited_creator_previously = await UserVisit.findOne({
         creator_id: creator.id,
         user_id: fetch_user_details.id,
      });

      // console.log("check_if_user_has_visited_creator_previously",check_if_user_has_visited_creator_previously)

      if (!check_if_user_has_visited_creator_previously) {
         // console.log("There");
         await UserVisit.create({
            creator_id: creator.id,
            user_id: fetch_user_details.id,
         });
         console.log("Here");
      }

      //generate bot token
      const create_conversation = await createConversation();
      // console.log("Web Url", create_conversation);

      const message = {
         // notification: {
         //   title: "Hey, Someone wants to chat with you",
         //   body: "Hey, Someone wants to chat with you",
         // },
         token: creator.fcm_token,
         data: {
            // type: "chat",
            type: "request_for_chat",
            creatorId: creator.id,
            creatorName: `${creator.first_name} ${creator.last_name}`,
            userConversationId: req.body.userConversationId,
            userId: req.body.userId,
            userName: req.body.userName,
            websocketUrl: create_conversation?.streamUrl,
            botToken: create_conversation?.token,
            conversationId: create_conversation?.conversationId,
         },
      };

      console.log("------>>>>>> Message", message);
      console.log("----->>>>>>> Conversation Data", create_conversation);

      // await storeUserConversation(
      //   {
      //     "type": "message",
      //     "id": req.body.userConversationId,
      //     "timestamp": new Date().toISOString(),
      //     "serviceUrl": "https://directline.botframework.com/",
      //     "channelId": "directline",
      //     "from": {
      //         "id": "65b11697d6b67c149cc5f04b",
      //         "name": req.body.userName
      //     },
      //     "conversation": {
      //         "id": req.body.userConversationId
      //     },
      //     "text": "",
      //     "channelData": {
      //         "isIntent": false,
      //         "chatWith": "bot",
      //         "creatorConversationId": "",
      //         "userConversationId": "",
      //         "userName": req.body.userName,
      //         "creatorName":`${creator.first_name} ${creator.last_name}`,
      //         "userId": req.body.userId,
      //         "creatorId": creator.email
      //     }
      // },""
      // )

      admin
         .messaging()
         .send(message)
         .then(async (response) => {
            await sendMessage(create_conversation?.conversationId, req.body.userConversationId, creator.id, `${creator.first_name} ${creator.last_name}`, create_conversation?.token, `${creator.first_name} ${creator.last_name}`, req.body.userName, creator.email, req.body.userId);
            return res.send({
               statusCode: 200,
               data: null,
               message: "Notification send successfully!",
               error: null,
            });
         })
         .catch((error) => {
            return res.send({
               statusCode: 400,
               data: null,
               message: null,
               error: error,
            });
         });
   } catch (error) {
      return res.send({
         statusCode: 400,
         data: null,
         message: null,
         error: error,
      });
   }
};
/**
 * Checks if a given username is already taken by a creator.
 *
 * This asynchronous function handles requests to check the availability of a username in the Creator model.
 * It searches the Creator collection for a document with the given username.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the username is not found in the database, it sends a 200 status code with a message indicating
 *     that the username is available.
 *   - If the username is found in the database, it sends a 400 status code with a message indicating
 *     that the username already exists.
 *   - In case of a server or database error, it sends a 400 status code with the error message.
 */
module.exports.checkCreatorUsernameExistance = async (req, res, next) => {
   try {
      let creator_username = await Creator.findOne({
         username: req.body.username,
      });
      if (!creator_username) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Username is available",
            error: null,
         });
      } else {
         return res.send({
            statusCode: 400,
            data: null,
            message: "Username already exists",
            error: null,
         });
      }
   } catch (error) {
      return res.send({
         statusCode: 400,
         data: null,
         message: null,
         error: error,
      });
   }
};
/**
 * Initiates the password reset process for a creator by sending an OTP.
 *
 * This function handles requests to reset a password for a creator. It first checks if a creator
 * with the provided email exists in the Creator collection. If the creator is found, it sends
 * an OTP to the creator's email to facilitate the password reset process.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is found, it sends a 200 status code with a message indicating that an OTP
 *     has been sent for password reset.
 *   - If no creator is found with the provided email, it sends a 200 status code with a message
 *     indicating that the creator doesn't exist. (Note: It might be more appropriate to use a
 *     different status code like 404 for not found scenarios).
 *   - In case of an error during the process, it sends a 400 status code with the error message.
 */
module.exports.resetPassword = async (req, res, next) => {
   try {
      let creator = await Creator.findOne({ email: req.body.email });
      if (!creator) {
         return res.send({
            statusCode: 200,
            data: null,
            message: "Creator Doesn't Exist",
            error: null,
         });
      } else {
         // Generate and send OTP
         sendOTPEmail(creator.email);

         return res.send({
            statusCode: 200,
            message: "OTP sent for password reset",
            error: null,
         });
      }
   } catch (error) {
      return res.send({
         statusCode: 400,
         message: null,
         error: error,
      });
   }
};
/**
 * Updates the password of a creator.
 *
 * This function handles requests to update a creator's password. It first checks if a creator
 * with the provided email exists in the Creator collection. If the creator is found, it proceeds
 * to update the password with the new password provided in the request. The new password is
 * encrypted before being saved to the database for security reasons.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is found and the password is successfully updated, it sends a 200 status
 *     code with a message indicating that the password was updated successfully.
 *   - If no creator is found with the provided email, it sends a 404 status code with a message
 *     indicating that the email was not found.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 */

module.exports.updatePassword = async (req, res, next) => {
   try {
      const newPassword = req.body.password;

      // Check if newPassword is provided and is a string
      if (typeof newPassword !== "string" || newPassword.trim() === "") {
         return res.status(400).send({
            statusCode: 400,
            data: null,
            message: "Invalid password",
            error: null,
         });
      }

      // Hash the new password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(newPassword, salt);

      // Update the creator's password
      const result = await Creator.updateOne({ _id: req.creator.id }, { $set: { password: hashedPassword } });

      // Check if the update was successful
      if (result.matchedCount === 0) {
         return res.status(404).send({
            statusCode: 404,
            data: null,
            message: "Creator not found",
            error: null,
         });
      }

      if (result.modifiedCount === 0) {
         return res.status(400).send({
            statusCode: 400,
            data: null,
            message: "Password was not updated",
            error: null,
         });
      }

      logger.info(`[${CreatorController} updatePassword API response success]`);
      res.send({
         statusCode: 200,
         data: null,
         message: "Creator Password updated successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} updatePassword API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * Retrieves notification details for a specific creator.
 *
 * This function handles requests to fetch notification details associated with a creator.
 * It uses the creator's email provided in the request body to look up their notifications.
 * The function relies on the `getNotificationsByCreatorEmail` method, which fetches the
 * notifications from the database.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If notifications for the specified email are found, it sends a 200 status code with
 *     a success message and the list of notifications as data.
 *   - If no notifications are found or the email does not correspond to any creator, it sends
 *     a 404 status code with a message indicating that the email was not found.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 */
module.exports.getNotificationDetails = async (req, res, next) => {
   try {
      // Assuming the email and newPassword are sent in the request body
      let creatorNotificationLists = await getNotificationsByCreatorEmail(req.body.email);
      if (!creatorNotificationLists) {
         return res.send({
            statusCode: 404,
            message: "Email not found",
            error: null,
         });
      } else {
         return res.send({
            statusCode: 200,
            message: "success",
            data: creatorNotificationLists,
            error: null,
         });
      }
   } catch (error) {
      return res.send({
         statusCode: 500,
         message: "An error occurred",
         error: error,
      });
   }
};
/**
 * Deletes all creator records from the database.
 *
 * This function handles the deletion of all creators from the Creator collection. It executes
 * the `deleteMany` method with an empty filter, indicating that all documents in the Creator
 * collection should be removed. This action is irreversible and should be used with caution,
 * as it will result in the loss of all creator data.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the deletion is successful, it sends a 200 status code with a message indicating
 *     that all creators have been deleted successfully, along with the deletion result in the data field.
 *   - In case of an error during the process, it sends a 400 status code with the error message.
 *
 * @note
 *   This function should be used with extreme caution, as it will permanently remove all creator
 *   records from the database. Ensure appropriate backups and confirmations are in place before
 *   executing this operation.
 */
module.exports.deleteAllCreator = async (req, res, next) => {
   try {
      const faq = await Creator.deleteMany({});
      logger.info(`[${CreatorController} deleteAllQuestions API response success]`);
      res.send({
         statusCode: 200,
         data: faq,
         message: "All Creators deleted successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} deleteAllQuestions API response error:- ${error.message}`);
      res.send({
         statusCode: 400,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

/**
 * Updates the profile picture of a creator.
 *
 * This function handles requests to update the profile picture of a creator. It first checks if a creator
 * with the given ID exists in the Creator collection. If the creator is found and a profile picture file
 * is provided in the request, the function updates the creator's profile picture with the new file.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is not found, it sends a 404 status code with a message indicating that the creator
 *     doesn't exist.
 *   - If the creator is found and the profile picture is updated successfully, it sends a 200 status code
 *     with the updated creator data and a success message.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes that the file upload is handled by middleware (e.g., multer) that populates `req.file`
 *   with the uploaded file information.
 */
module.exports.updateCreatorProfilePicture = async (req, res, next) => {
   try {
      const creator = await Creator.findById(req.creator.id);
      if (!creator) {
         return res.send({
            statusCode: 404,
            message: "Creator Doesn't Exist",
            error: null,
         });
      }

      if (req.creator.id && req.file) {
         // Check if a file is uploaded
         if (req.file) {
            const creator = await Creator.findById(req.creator.id);
            if (!creator) {
               return res.json({
                  statusCode: 400,
                  data: creator,
                  message: `Creator with id ${req.creator.id} doesn't exist`,
                  error: null,
               });
            }

            const { filename, destination } = req.file;
            let imagePath = destination + filename;
            creator.profile_pic = imagePath;
            await creator.save();

            return res.send({
               statusCode: 200,
               data: creator,
               message: "Profile Pic Updated Successfully",
               error: null,
            });
         }
         logger.info(`[${CreatorController} updateCreatorProfile API response success]`);
         res.send({
            statusCode: 200,
            data: null,
            message: "Creator updated successfully",
            error: null,
         });
      }
   } catch (error) {
      // Logging error
      logger.error(`[${CreatorController} updateCreatorProfile API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Uploads content images to a creator's gallery.
 *
 * This function handles requests to upload multiple images to a creator's content gallery.
 * It first verifies that the creator exists in the Creator collection using the ID provided in the request.
 * If the creator is found, each image file provided in the request is processed and stored. The function
 * then updates the creator's gallery with the paths of these images and creates corresponding entries
 * in the CreatorContentGallery collection.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is not found, it sends a 400 status code with a message indicating that the creator
 *     doesn't exist.
 *   - If the images are uploaded successfully, it sends a 200 status code with a success message.
 *   - If no images are provided in the request, it sends a 400 status code with a message indicating
 *     that no images were provided.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes that the file upload is handled by middleware (e.g., multer) that populates `req.files`
 *   with the uploaded file information. It also assumes a specific structure for the Creator and
 *   CreatorContentGallery models.
 */
module.exports.uploadCreatorContentGallery = async (req, res, next) => {
   try {
      if (req.creator.id && req.files && req.files.length > 0) {
         const creator = await Creator.findById(req.creator.id);
         if (!creator) {
            return res.json({
               statusCode: 400,
               data: creator,
               message: `Creator with id ${req.creator.id} doesn't exist`,
               error: null,
            });
         }

         // Process each file
         // let imagePaths = req.files.map(
         //   (file) => file.destination + file.filename
         // );

         const imagePaths = await Promise.all(
            req.files.map(async (file) => {
               const { key } = file;
               return key;
               // const bucketName = "influbot";
               // const presignedUrl = await generatePresignedUrl(bucketName, key, 60 * 5);
               // return presignedUrl;
            }),
         );

         console.log("Image Paths", imagePaths);

         // Here you can update the creator's profile with the array of image paths
         // This depends on how you want to store multiple images in your database
         // For example, if you have an array field for images in your creator model
         creator.images = imagePaths;
         await creator.save();

         // console.log("Images", imagePaths);

         const { description, contentType, price, isPrivate } = req.body;

         for (let i = 0; i < imagePaths.length; i++) {
            await CreatorContentGallery.create({
               creator: req.creator.id,
               description,
               contentType,
               contentURL: imagePaths[i],
               price,
               isPrivate,
            });
            // console.log("Image Uploaded");
         }

         return res.send({
            statusCode: 200,
            // data: creator,
            message: "Images uploaded successfully",
            error: null,
         });
      } else {
         return res.send({
            statusCode: 400,
            message: "No images provided",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} uploadCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Retrieves content from a creator's gallery based on visibility (private or public).
 *
 * This function handles requests to fetch content from a specific creator's content gallery.
 * It first checks if the creator exists in the Creator collection using the creator's ID provided
 * in the request. If the creator is found, the function then fetches content from the
 * CreatorContentGallery collection based on the specified visibility type in the request query.
 * The content can be filtered to show either private or public content, or both if no specific
 * type is mentioned.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is not found, it sends a 400 status code with a message indicating that the creator
 *     doesn't exist.
 *   - If the content is fetched successfully, it sends a 200 status code with the content data and a success message.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the presence of the Creator and CreatorContentGallery models. It also assumes
 *   that the `req.creator.id` is set, typically by a preceding authentication middleware.
 */
module.exports.getCreatorContentGallery = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      let creator_content_gallery;
      // console.log("Query", req.query);
      if (req.query.type === "private") {
         creator_content_gallery = await CreatorContentGallery.find({
            isPrivate: true,
            creator: req.creator.id,
         });
      } else if (req.query.type === "public") {
         creator_content_gallery = await CreatorContentGallery.find({
            isPrivate: false,
            creator: req.creator.id,
         });
      } else {
         creator_content_gallery = await CreatorContentGallery.find({
            creator: req.creator.id,
         });
      }

      // Use map to create a new array with updated contentURLs
      const updatedGallery = creator_content_gallery.map((data) => {
         return {
            ...data.toObject(), // Convert Mongoose document to a plain object
            contentURL: process.env.BASE_URL_FOR_IMAGES + data.contentURL,
         };
      });

      logger.info(`[${CreatorController} getCreatorContentGallery API response success]`);
      res.send({
         statusCode: 200,
         data: updatedGallery, // Send the updated gallery
         message: "Creator Content Gallery Fetched Successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Retrieves specific content from a creator's gallery along with its insights.
 *
 * This function is responsible for fetching a specific content item from a creator's content gallery
 * using the content's ID provided in the request parameters. It first validates the existence of the
 * creator based on the creator ID provided in the request. If the creator exists, the function then
 * fetches the specified content from the CreatorContentGallery collection. This function also
 * calculates and adds insights to the content, such as total likes, dislikes, comments, and reports.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is not found, it sends a 400 status code with a message indicating that the creator
 *     doesn't exist.
 *   - If the content is found, it sends a 200 status code with the content data, insights, and a success message.
 *   - If the content is not found, it sends a 200 status code with a message indicating that no content is found.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the presence of the Creator and CreatorContentGallery models. It also assumes
 *   that the `req.creator.id` is set, typically by a preceding authentication middleware, and that the
 *   content ID is provided in the request parameters.
 */
module.exports.getSpecificContent = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      let creator_content_gallery = await CreatorContentGallery.findById(req.params.id).populate("likes.users", "first_name last_name profile_image").populate("dislikes.users", "first_name last_name profile_image");

      if (creator_content_gallery) {
         const insights = {
            totalLikes: creator_content_gallery.likes.count,
            totalDislikes: creator_content_gallery.dislikes.count,
            totalComments: creator_content_gallery.comment.users.length,
            totalReports: creator_content_gallery.reports.length,
         };

         // Convert Mongoose document to a JavaScript object
         creator_content_gallery = creator_content_gallery.toObject();

         // Add insights to the object
         creator_content_gallery.insights = insights;

         if (creator_content_gallery.contentURL) {
            creator_content_gallery.contentURL = process.env.BASE_URL_FOR_IMAGES + creator_content_gallery.contentURL;
         }

         logger.info(`[${CreatorController} getCreatorContentGallery API response success]`);
         res.send({
            statusCode: 200,
            data: creator_content_gallery,
            message: "Creator Content Gallery Fetched Successfully",
            error: null,
         });
      } else {
         res.send({
            statusCode: 200,
            data: null,
            message: "No Image Found",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Retrieves specific content from a creator's gallery along with its insights.
 *
 * This function fetches a specific item from a creator's content gallery based on the content's ID provided
 * in the request parameters. It validates the existence of the creator using the creator ID included in the
 * request (`req.creator.id`). If the creator is found, the function proceeds to retrieve the specified content
 * from the CreatorContentGallery collection. Additionally, it calculates insights such as the total number of
 * likes, dislikes, comments, and reports associated with the content.
 *
 *
 * @returns {void}
 *   - If the creator is not found, it responds with a 400 status code and a message indicating the
 *     non-existence of the creator.
 *   - If the content is successfully retrieved, it responds with a 200 status code, including the content
 *     data, insights, and a success message.
 *   - If the content is not found, it responds with a 200 status code and a message indicating the absence
 *     of the content.
 *   - In the event of an error during processing, it responds with a 500 status code and includes the error
 *     message.
 *
 * @note
 *   This function assumes the availability of the Creator and CreatorContentGallery models in the context.
 *   It also presupposes that `req.creator.id` is populated, typically via a preceding authentication
 *   middleware, and that the content ID is supplied as part of the request parameters.
 */

module.exports.generatePresignedUrlForImage = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      let creator_content_gallery = await CreatorContentGallery.findById(req.params.id).populate("likes.users", "first_name last_name profile_image").populate("dislikes.users", "first_name last_name profile_image");

      if (creator_content_gallery) {
         const insights = {
            totalLikes: creator_content_gallery.likes.count,
            totalDislikes: creator_content_gallery.dislikes.count,
            totalComments: creator_content_gallery.comment.users.length,
            totalReports: creator_content_gallery.reports.length,
         };

         // Convert Mongoose document to a JavaScript object
         creator_content_gallery = creator_content_gallery.toObject();

         // Add insights to the object
         creator_content_gallery.insights = insights;

         if (creator_content_gallery.contentURL) {
            creator_content_gallery.contentURL = process.env.BASE_URL_FOR_IMAGES + creator_content_gallery.contentURL;
         }

         logger.info(`[${CreatorController} getCreatorContentGallery API response success]`);
         res.send({
            statusCode: 200,
            data: creator_content_gallery,
            message: "Creator Content Gallery Fetched Successfully",
            error: null,
         });
      } else {
         res.send({
            statusCode: 200,
            data: null,
            message: "No Image Found",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Deletes specific content from a creator's gallery.
 *
 * This function is responsible for deleting a specific content item from a creator's content gallery
 * using the content's ID provided in the request parameters. It first validates the existence of the
 * creator based on the creator ID provided in the request. If the creator exists, the function then
 * proceeds to delete the specified content from the CreatorContentGallery collection.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator is not found, it sends a 400 status code with a message indicating that the creator
 *     doesn't exist.
 *   - If the content is successfully deleted, it sends a 200 status code with a success message.
 *   - If the content is not found, it sends a 404 status code with a message indicating that the content
 *     was not found.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the presence of the Creator and CreatorContentGallery models. It also assumes
 *   that the `req.creator.id` is set, typically by a preceding authentication middleware, and that the
 *   content ID is provided in the request parameters.
 */

module.exports.deleteSpecificCreatorContent = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);

      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }

      const creator_content_gallery = await CreatorContentGallery.deleteMany({});

      logger.info(`[${CreatorController} getCreatorContentGallery API response success]`);
      res.send({
         statusCode: 200,
         data: creator_content_gallery,
         message: "Creator Content Deleted Successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Adds a discount to a specific content item in a creator's gallery.
 *
 * This function allows adding a discount to a specific content item within the creator's content gallery.
 * It validates the existence of the creator and the specific content item. If both exist, it calculates
 * the discounted price based on the provided discount percentage and updates the content item with
 * the new discount and price.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the creator or content is not found, it sends a 404 status code with a corresponding message.
 *   - If the discount information is not provided in the request body, it sends a 400 status code with a
 *     message indicating the absence of discount data.
 *   - If the discount is successfully added, it sends a 200 status code with the updated content data and a
 *     success message.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the presence of the Creator and CreatorContentGallery models. It also assumes
 *   that the `req.creator.id` is set, typically by a preceding authentication middleware, and that the
 *   content ID is provided in the request parameters.
 */
module.exports.addDiscount = async (req, res, next) => {
   try {
      if (req.body.discount) {
         let creator = await Creator.findById(req.creator.id);

         if (!creator) {
            return res.status(404).send({
               statusCode: 404,
               message: "Creator doesn't exist",
               error: null,
            });
         }

         const { discount, offerDetails } = req.body;
         const { id } = req.params;

         const find_the_content = await CreatorContentGallery.findById(id);

         if (!find_the_content) {
            return res.status(404).send({
               statusCode: 400,
               message: `Content with id ${id} doesn't exist`,
               error: null,
            });
         }

         const discountFactor = (100 - discount) / 100;
         const discountedPrice = find_the_content.price * discountFactor;

         find_the_content.discount = discount;
         find_the_content.offerDetails = offerDetails;
         find_the_content.price = discountedPrice;
         await find_the_content.save();

         logger.info(`[${CreatorController} addDiscount API response success]`);
         return res.send({
            statusCode: 200,
            data: find_the_content,
            message: "Discount added to content successfully",
            error: null,
         });
      } else {
         return res.status(400).send({
            statusCode: 400,
            message: "Discount not provided",
            error: null,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} addDiscount API response error:- ${error.message}]`);
      return res.status(500).send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};
/**
 * Increments the view count of a specific content item in a creator's gallery.
 *
 * This function is responsible for incrementing the view count of a specific content item within
 * a creator's content gallery. It identifies the content item using the content ID provided in the
 * request parameters. Once the content is found, the view count for that content is incremented by one.
 *
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the content is not found, it sends a 400 status code with a message indicating that no content is found.
 *   - If the view is successfully added, it sends a 200 status code with a success message.
 *   - In case of an error during the process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the presence of the CreatorContentGallery model and relies on the content ID being
 *   available in the request parameters.
 */
module.exports.view = async (req, res, next) => {
   try {
      const fetchContent = await CreatorContentGallery.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } });
      if (!fetchContent) {
         return res.send({
            statusCode: 400,
            message: "No Content Found",
            error: error.message,
         });
      }
      return res.send({
         statusCode: 200,
         message: "View Added",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} addDiscount API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.like = async (req, res, next) => {
   try {
      const userId = req.user.id;
      const contentId = req.params.id;

      const content = await CreatorContentGallery.findById(contentId);
      if (!content) {
         return res.status(404).send({ message: "Content not found" });
      }

      const update = {};
      let dislikedAlready = false;

      // Check if the user has already disliked the content
      if (content.dislikes.users.includes(userId)) {
         // User is changing from dislike to like
         update["$inc"] = { "likes.count": 1, "dislikes.count": -1 };
         update["$pull"] = { "dislikes.users": userId };
         update["$push"] = { "likes.users": userId };
         dislikedAlready = true;
      } else if (!content.likes.users.includes(userId)) {
         // User is liking for the first time
         update["$inc"] = { "likes.count": 1 };
         update["$push"] = { "likes.users": userId };
      } else {
         // User has already liked
         return res.status(400).send({ message: "You have already liked this content" });
      }

      await CreatorContentGallery.findByIdAndUpdate(contentId, update);

      return res.send({
         statusCode: 200,
         message: dislikedAlready ? "Dislike removed and content liked" : "Content liked",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} like API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.dislike = async (req, res, next) => {
   try {
      const userId = req.user.id;
      const contentId = req.params.id;

      const content = await CreatorContentGallery.findById(contentId);
      if (!content) {
         return res.status(404).send({ message: "Content not found" });
      }

      const update = {};
      let likedAlready = false;

      // Check if the user has already liked the content
      if (content.likes.users.includes(userId)) {
         // User is changing from like to dislike
         update["$inc"] = { "likes.count": -1, "dislikes.count": 1 };
         update["$pull"] = { "likes.users": userId };
         update["$push"] = { "dislikes.users": userId };
         likedAlready = true;
      } else if (!content.dislikes.users.includes(userId)) {
         // User is disliking for the first time
         update["$inc"] = { "dislikes.count": 1 };
         update["$push"] = { "dislikes.users": userId };
      } else {
         // User has already disliked
         return res.status(400).send({ message: "You have already disliked this content" });
      }

      await CreatorContentGallery.findByIdAndUpdate(contentId, update);

      return res.send({
         statusCode: 200,
         message: likedAlready ? "Like removed and content disliked" : "Content disliked",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} dislike API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.addComment = async (req, res) => {
   try {
      const contentId = req.params.id;
      const userId = req.user.id;
      const commentText = req.body.comment;

      const content = await CreatorContentGallery.findById(contentId);
      if (!content) {
         return res.status(404).send({
            statusCode: 400,
            message: "Content not found",
            error: null,
         });
      }

      // Set the latest comment text and add user to the array of users who commented
      content.comment.text = commentText;
      content.comment.users.push(userId);

      await content.save();

      return res.status(200).send({
         statusCode: 200,
         data: content,
         message: "Comment added successfully",
         error: null,
      });
   } catch (error) {
      return res.status(500).send({
         statusCode: 500,
         message: null,
         error: error.message,
      });
   }
};

module.exports.reportContent = async (req, res) => {
   try {
      const contentId = req.params.id;
      const userId = req.user.id;
      const reportReason = req.body.reason; // Assuming the reason is sent in the request body

      const content = await CreatorContentGallery.findById(contentId);
      if (!content) {
         return res.status(404).send({
            statusCode: 404,
            message: "Content not found",
            error: null,
         });
      }

      // Create a new report object
      const newReport = {
         user: userId,
         reason: reportReason,
         reportedAt: new Date(),
      };

      // Add the new report to the reports array
      content.reports.push(newReport);

      await content.save();

      return res.status(200).send({
         statusCode: 200,
         data: content,
         message: "Content reported successfully",
         error: null,
      });
   } catch (error) {
      return res.status(500).send({
         statusCode: 500,
         message: error.message,
         error: error.message,
      });
   }
};

module.exports.flagContent = async (req, res, next) => {
   try {
      const userId = req.user.id; // ID of the user flagging the content
      const contentId = req.params.id; // ID of the content being flagged

      const content = await CreatorContentGallery.findById(contentId);
      if (!content) {
         return res.status(404).send({ message: "Content not found" });
      }

      // Check if the user has already flagged this content
      if (content.flag.users.includes(userId)) {
         return res.status(400).send({ message: "You have already flagged this content" });
      }

      // Update the content with the new flag
      const updatedContent = await CreatorContentGallery.findByIdAndUpdate(
         contentId,
         {
            $inc: { "flag.count": 1 },
            $push: { "flag.users": userId },
         },
         { new: true },
      );

      // Check if the content has been flagged more than 3 times
      if (updatedContent.flag.count > 3) {
         // Logic to send email to the creator
         // Assuming you have a function sendEmailToCreator defined somewhere
      }

      return res.send({
         statusCode: 200,
         message: "Content flagged successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} flag API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorProfessionList = async (req, res, next) => {
   try {
      logger.info(`[${CreatorController} getCreatorProfessionList API response success]`);
      const data = fs.readFileSync(path.join(__dirname, "../seeder/creator_profession_list.json"), "utf8");
      res.send({
         statusCode: 200,
         data: JSON.parse(data),
         message: "Creator Profession List Fetched Successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfessionList API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorFlagReasonList = async (req, res, next) => {
   try {
      logger.info(`[${CreatorController} getCreatorProfessionList API response success]`);
      const data = fs.readFileSync(path.join(__dirname, "../seeder/creator_flag_reasons_list.json"), "utf8");
      res.send({
         statusCode: 200,
         data: JSON.parse(data),
         message: "Creator Profession List Fetched Successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfessionList API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorReportReasonList = async (req, res, next) => {
   try {
      logger.info(`[${CreatorController} getCreatorProfessionList API response success]`);
      const data = fs.readFileSync(path.join(__dirname, "../seeder/creator_report_reason_list.json"), "utf8");
      res.send({
         statusCode: 200,
         data: JSON.parse(data),
         message: "Creator Profession List Fetched Successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorProfessionList API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.getCreatorFlagAndReports = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.params.id);
      if (!creator) {
         return res.send({
            statusCode: 400,
            message: "Creator doesn't exist",
            error: null,
         });
      }
      let creator_reports_and_flags = await CreatorFlagger.findOne({
         creator: req.params.id,
      });
      // console.log("---", creator_reports_and_flags);
      if (creator_reports_and_flags) {
         logger.info(`[${CreatorController} getCreatorContentGallery API response success]`);
         res.send({
            statusCode: 200,
            data: creator_reports_and_flags,
            message: "Creator Reports and Flags Fetched Successfully",
            error: null,
         });
      } else {
         return res.status(200).send({
            message: `No one has reported or flagged the creator yet`,
         });
      }
   } catch (error) {
      logger.error(`[${CreatorController} getCreatorContentGallery API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.flagCreator = async (req, res, next) => {
   try {
      const userId = req.user.id;
      const creatorId = req.params.id;

      // Check if the creator exists in the Creator collection
      const creatorExists = await Creator.exists({ _id: creatorId });
      if (!creatorExists) {
         return res.status(404).send({
            message: `Creator with id ${creatorId} doesn't exist`,
         });
      }

      // Prepare the new flag object
      const newFlag = {
         user: userId,
         reason: req.body.reason, // Assuming reason is provided in request
         reportedAt: new Date(),
      };

      // Fetch the CreatorFlagger document for the creator
      const fetch_creator_flag_report = await CreatorFlagger.findOne({
         creator: creatorId,
      });

      // Check if the user has already flagged the creator
      if (fetch_creator_flag_report && fetch_creator_flag_report.flag && fetch_creator_flag_report.flag.some((flag) => flag.user.toString() === userId)) {
         return res.status(400).send({ message: "You have already flagged this creator" });
      }

      // Fetch or create a CreatorFlagger document for the creator, and add the flag
      const creatorFlagger = await CreatorFlagger.findOneAndUpdate(
         { creator: creatorId },
         {
            $setOnInsert: { creator: creatorId },
            $push: { flag: newFlag }, // Add flag whether it's a new document or existing one
         },
         { new: true, upsert: true },
      );

      return res.status(200).send({
         message: "Creator flagged successfully",
      });
   } catch (error) {
      console.error(`[flagCreator] API response error: ${error.message}`);
      res.status(500).send({
         message: "An error occurred while processing your request",
         error: error.message,
      });
   }
};

module.exports.unflagCreator = async (req, res, next) => {
   try {
      const userId = req.user.id;
      const creatorId = req.params.id;

      // Check if the creator exists in the Creator collection
      const creatorExists = await Creator.exists({ _id: creatorId });
      if (!creatorExists) {
         return res.status(404).send({
            message: `Creator with id ${creatorId} doesn't exist`,
         });
      }

      // Fetch the CreatorFlagger document for the creator
      const creatorFlagger = await CreatorFlagger.findOne({ creator: creatorId });

      // Check if the user has flagged the creator
      if (!creatorFlagger || !creatorFlagger.flag.some((flag) => flag.user.toString() === userId)) {
         return res.status(400).send({ message: "You have not flagged this creator" });
      }

      // Remove the flag
      await CreatorFlagger.updateOne(
         { creator: creatorId },
         { $pull: { flag: { user: userId } } }, // Remove flag for the user
      );

      return res.status(200).send({
         message: "Creator unflagged successfully",
      });
   } catch (error) {
      console.error(`[unflagCreator] API response error: ${error.message}`);
      res.status(500).send({
         message: "An error occurred while processing your request",
         error: error.message,
      });
   }
};

module.exports.reportCreator = async (req, res, next) => {
   try {
      const { reason, feedback } = req.body;

      if (!reason || !feedback) {
         return res.status(400).send({
            message: `Missing Required Fields (reason,feedback)`,
         });
      }

      const userId = req.user.id;
      const creatorId = req.params.id;

      // Check if the creator exists
      const creatorExists = await Creator.exists({ _id: creatorId });
      if (!creatorExists) {
         return res.status(404).send({
            message: `Creator with id ${creatorId} doesn't exist`,
         });
      }

      // Prepare the new report object
      const newReport = {
         user: userId,
         reason: reason,
         feedback: feedback,
         reportedAt: new Date(),
      };

      // Fetch the CreatorFlagger document for the creator
      const creatorFlagger = await CreatorFlagger.findOne({ creator: creatorId });

      // Check if the user has already reported the creator
      if (creatorFlagger && creatorFlagger.reports && creatorFlagger.reports.some((report) => report.user.toString() === userId)) {
         return res.status(200).send({ message: "You have already reported this creator", reported: true });
      }

      // Fetch or create a CreatorFlagger document for the creator, and add the report
      await CreatorFlagger.findOneAndUpdate(
         { creator: creatorId },
         {
            $setOnInsert: { creator: creatorId },
            $push: { reports: newReport }, // Add report whether it's a new document or existing one
         },
         { new: true, upsert: true },
      );

      return res.status(200).send({
         message: "Creator reported successfully",
      });
   } catch (error) {
      console.error(`[reportCreator] API response error: ${error.message}`);
      res.status(500).send({
         message: "An error occurred while processing your request",
         error: error.message,
      });
   }
};

module.exports.checkIfCreatorAlreadyReported = async (req, res, next) => {
   try {
      const userId = req.user.id;
      const creatorId = req.params.id;

      // Check if the creator exists
      const creatorExists = await Creator.exists({ _id: creatorId });
      if (!creatorExists) {
         return res.status(404).send({
            message: `Creator with id ${creatorId} doesn't exist`,
         });
      }

      // Fetch the CreatorFlagger document for the creator
      const creatorFlagger = await CreatorFlagger.findOne({ creator: creatorId });

      // Check if the user has already reported the creator
      if (creatorFlagger && creatorFlagger.reports && creatorFlagger.reports.some((report) => report.user.toString() === userId)) {
         return res.status(200).send({ message: "You have already reported this creator", reported: true });
      } else {
         return res.status(200).send({ message: "You have not reported this creator", reported: false });
      }
   } catch (error) {
      console.error(`[reportCreator] API response error: ${error.message}`);
      res.status(500).send({
         message: "An error occurred while processing your request",
         error: error.message,
      });
   }
};

module.exports.unreportCreator = async (req, res, next) => {
   try {
      const userId = req.user.id;
      // console.log("---",userId)
      const creatorId = req.params.id;

      // Check if the creator exists
      const creatorExists = await Creator.exists({ _id: creatorId });
      if (!creatorExists) {
         return res.status(404).send({
            message: `Creator with id ${creatorId} doesn't exist`,
         });
      }

      // Fetch the CreatorFlagger document for the creator
      const creatorFlagger = await CreatorFlagger.findOne({ creator: creatorId });

      // Check if the user has reported the creator
      if (!creatorFlagger || !creatorFlagger.reports.some((report) => report.user.toString() === userId)) {
         return res.status(400).send({ message: "You have not reported this creator" });
      }

      // Remove the report
      await CreatorFlagger.updateOne(
         { creator: creatorId },
         { $pull: { reports: { user: userId } } }, // Remove report for the user
      );

      return res.status(200).send({
         message: "Creator unreported successfully",
      });
   } catch (error) {
      console.error(`[unreportCreator] API response error: ${error.message}`);
      res.status(500).send({
         message: "An error occurred while processing your request",
         error: error.message,
      });
   }
};

module.exports.logoutCreator = async (req, res, next) => {
   try {
      let creator = await Creator.findById(req.creator.id);
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Creator not found",
         });

      creator.fcm_token = null;
      creator.is_logged_in = false;
      await creator.save();

      logger.info(`[${CreatorController} logoutCreator API response success]`);

      res.send({
         statusCode: 200,
         data: creator,
         message: "Creator Logged Out successfully",
         error: null,
      });
   } catch (error) {
      logger.error(`[${CreatorController} logoutCreator API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.generateCreatorOTP = async (req, res, next) => {
   try {
      const { email } = req.body;
      let creator = await Creator.findOne({
         email,
      });
      // console.log("Creator",creator)
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Creator not found",
         });

      const get_creator_totp_secret = await OTPSecretMapper.findOne({ id: creator.id });
      // console.log("OTP Details Of Creator", get_creator_totp_secret)
      if (get_creator_totp_secret) {
         const generate_otp = await generateOTP(get_creator_totp_secret.secret_value);
         if (generateOTP) {
            return res.status(200).json({
               statusCode: 200,
               data: generate_otp,
               message: "OTP Generated Succcessfully",
               error: false,
            });
         }
      }
   } catch (error) {
      logger.error(`[${CreatorController} logoutCreator API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.verifyCreatorOTP = async (req, res, next) => {
   try {
      const { email, otp } = req.body;
      let creator = await Creator.findOne({
         email,
      });
      // console.log("Creator",creator)
      if (!creator)
         return res.send({
            statusCode: 400,
            data: null,
            message: null,
            error: "Creator not found",
         });

      const get_creator_totp_secret = await OTPSecretMapper.findOne({ id: creator.id });
      // console.log("OTP Details Of Creator", get_creator_totp_secret)
      if (get_creator_totp_secret) {
         const verify_otp = await verifyOTP(get_creator_totp_secret.secret_value, otp);
         // console.log("OTP", verify_otp)
         if (verify_otp) {
            return res.status(200).json({
               statusCode: 200,
               message: "OTP Verified Succcessfully",
               error: false,
            });
         } else {
            return res.status(400).json({
               statusCode: 200,
               message: "Invalid OTP",
               error: false,
            });
         }
      }
   } catch (error) {
      logger.error(`[${CreatorController} logoutCreator API response error:- ${error.message}]`);
      res.send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

module.exports.generateProfilePicture = async (req, res, next) => {
   try {
      // const creator = await Creator.findById(req.creator.id);
      // if (!creator) {
      //   return res.status(400).json({
      //     statusCode: 400,
      //     data: creator,
      //     message: `Creator with id ${req.creator.id} doesn't exist`,
      //     error: null,
      //   });
      // }

      const bucketName = "influbot";
      // Ensure this function generates a presigned URL for a GET operation
      const presignedUrl = await generatePresignedUrl(bucketName, req.params.id, 60 * 5);

      // console.log("Url", presignedUrl);

      // Redirect to the presigned URL instead of sending it in the response
      return res.redirect(presignedUrl);
   } catch (error) {
      console.error(`[${CreatorController} uploadCreatorContentGallery API response error:- ${error.message}]`);
      return res.status(500).send({
         statusCode: 500,
         data: null,
         message: null,
         error: error.message,
      });
   }
};

// module.exports.getCreatorDetails = async (req, res, next) => {
//    try {
//       let creator = await Creator.findById(req.params.id);

//       if (!creator) {
//          return res.send({
//             statusCode: 400,
//             message: "Creator doesn't exist",
//             error: null,
//          });
//       }

//       creator = creator.toObject();
//       creator.profile_pic = creator.profile_pic ? process.env.BASE_URL_FOR_IMAGES + creator.profile_pic : "";
//       creator.bot_link = process.env.BASE_URL_FOR_CREATOR + "/" + creator.username;

//       logger.info(`[${CreatorController} createCreator API response success]`);
//       res.send({
//          statusCode: 200,
//          data: creator,
//          message: "Creator profile captured successfully",
//          error: null,
//       });
//    } catch (error) {
//       logger.error(`[${CreatorController} getCreatorProfile API response error:- ${error.message}]`);
//       res.send({
//          statusCode: 500,
//          data: null,
//          message: null,
//          error: error.message,
//       });
//    }
// };
