const { BaseRates } = require("../models/BaseRate");

const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");


const BaseRateController = "BASE_RATE_CONTROLLER";


/**
 * Retrieves the list of base rates from the BaseRates collection.
 *
 * This function is responsible for fetching all entries from the BaseRates collection in the database.
 * It queries the collection without any specific filters, thus returning all the base rates present.
 * This information might be used for various purposes, such as displaying pricing details or
 * calculating charges for services.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the base rates are successfully retrieved, it sends a 200 status code with the data
 *     containing the list of base rates and a success message.
 *   - If there is an error during the retrieval process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a BaseRates model that represents the base rates data.
 *   No query parameters are applied, meaning all records in the BaseRates collection will be retrieved.
 *   The function is typically used to provide a comprehensive view of all base rate settings.
 */
module.exports.getBaseRates = async (req, res, next) => {
  try {
    // const redis_key = 'base_rates';
    // const cached_data = await redis.get(redis_key);
    // if (cached_data) {
    //   logger.info(`[BaseRateController] Base Rates fetched from cache`);
    //   return res.status(200).json({
    //     statusCode: 200,
    //     data: JSON.parse(cached_data),
    //     message: "Base Rates list fetched successfully from cache",
    //     error: null,
    //   });
    // }

    // If not found in cache, fetch from database
    const chat_list_for_creator = await BaseRates.find({});

    // Cache the fetched result for future requests, with an expiration time (e.g., 60 seconds)
    // await redis.set(redis_key, JSON.stringify(chat_list_for_creator), 'EX', 600);

    logger.info(`[BaseRateController] getBaseRates API response success`);
    res.status(200).json({
      statusCode: 200,
      data: chat_list_for_creator,
      message: "Base Rates list fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${BaseRateController} getBaseRates API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Creates or updates the base rates in the BaseRates collection.
 *
 * This function either updates the existing base rates or creates a new entry in the BaseRates collection.
 * It first attempts to find an existing base rates document. If found, it updates this document with
 * the provided data. If no existing document is found, it creates a new entry with the provided data.
 * This function is essential for maintaining up-to-date and accurate base rate information, which can
 * be critical for billing, pricing, or other financial calculations within the application.
 *
 * @returns {void}
 *   The function sends back a JSON response.
 *   - If the base rates are successfully updated or created, it sends a 200 status code for updates
 *     or 201 for creations, along with the details of the base rates and a success message.
 *   - If there is an error during the update/creation process, it sends a 500 status code with the error message.
 *
 * @note
 *   The function assumes the existence of a BaseRates model. It is designed to ensure that there is
 *   always only one base rates document in the collection. The function handles both creation and updating
 *   scenarios, making it a versatile tool for managing base rates data.
 */
module.exports.changeBaseRates = async (req, res, next) => {
    try {
      let baseRates = await BaseRates.findOne();
  
      if (baseRates) {
        // Update existing base rates
        await BaseRates.updateOne({}, req.body);
        baseRates = await BaseRates.findOne(); // Fetch updated document
        logger.info('[BaseRateController createOrUpdateBaseRates] Base rates updated successfully');
      } else {
        // Create new base rates
        baseRates = new BaseRates(req.body);
        await baseRates.save();
        logger.info('[BaseRateController createOrUpdateBaseRates] Base rates created successfully');
      }
  
      res.status(200).json({
        statusCode: baseRates ? 200 : 201,
        data: baseRates,
        message: `Base rates ${baseRates ? 'updated' : 'created'} successfully`,
        error: null,
      });
    } catch (error) {
      logger.error(`[BaseRateController createOrUpdateBaseRates error: ${error.message}]`);
      res.status(500).json({
        statusCode: 500,
        data: null,
        message: null,
        error: error.message,
      });
    }
  };