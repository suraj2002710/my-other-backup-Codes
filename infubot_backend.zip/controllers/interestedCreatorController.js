const { InterestedCreator } = require("../models/interestedCreator");
const { sendOTPEmail } = require("../services/emailNotification");
const _ = require("lodash");
const jwt = require("jsonwebtoken");
const admin = require("firebase-admin");

const {
  getNotificationsByCreatorEmail,
} = require("../services/notificationStore");

const bcrypt = require("bcryptjs");

const logger = require("winston");
const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { Wallet } = require("../models/Wallet");
const { renameImage } = require("../services/renameImage");

const fs = require("fs");

const InterestedCreatorController = "INTERESTED_CREATOR_CONTROLLER";

// module.exports.getAllInterestedCreators = async (req, res, next) => {
//   try {
//     const interested_creators = await InterestedCreator.find({});
//     logger.info(`[${InterestedCreatorController} getAllInterestedCreators API response success]`);
//     res.send({
//       statusCode: 200,
//       data: interested_creators,
//       message: "Interested Creator lists fetched successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${InterestedCreatorController} getAllInterestedCreators API response error:- ${error.message}]`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.getAllInterestedCreators = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1; // Default to page 1 if not specified
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page if not specified
    const skip = (page - 1) * limit;

    const totalInterestedCreators = await InterestedCreator.countDocuments({}); // Get total count of interested creators
    const interested_creators = await InterestedCreator.find({}).skip(skip).limit(limit);

    logger.info(`[${InterestedCreatorController} getAllInterestedCreators API response success]`);

    // Determine if there's a next page
    const hasNextPage = page * limit < totalInterestedCreators;
    const nextPageUrl = hasNextPage
      ? `${req.protocol}://${req.get('host')}${req.originalUrl.split('?')[0]}?page=${page + 1}&limit=${limit}`
      : null;

    res.send({
      statusCode: 200,
      data: interested_creators,
      nextPage: nextPageUrl,
      message: "Interested Creator lists fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${InterestedCreatorController} getAllInterestedCreators API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



module.exports.interestedCreatorSignup = async (req, res, next) => {
  try {
    const requiredFields = {
      fullname: "Fullname",
      email: "Email",
      dob: "Password",
    };

    const missingFields = Object.entries(requiredFields)
      .filter(([field, label]) => req.body[field] === undefined)
      .map(([field, label]) => label);

    if (missingFields.length > 0) {
      return res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: `${missingFields.join(" and ")} ${
          missingFields.length > 1 ? "are" : "is"
        } required.`,
      });
    }


    let isCreatorExists = await InterestedCreator.findOne({ email: req.body.email });
   
    if (isCreatorExists)
      return res.send({
        statusCode: 404,
        data: null,
        message: null,
        error: `You have already signed up with ${isCreatorExists.email}`,
      });

    let createCreator = await InterestedCreator.create(req.body);
   await createCreator.save();
    

    logger.info(`[${InterestedCreatorController} interestedCreatorSignup API response success]`);

    res.send({
      statusCode: 201,
      data: createCreator,
      message: "Sign Up Successfull",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${InterestedCreatorController} interestedCreatorSignup API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.deleteAllInterestedCreator = async (req, res, next) => {
  try {
    const faq = await InterestedCreator.deleteMany({});
    // const faq = await Creator.collection.drop()
    logger.info(
      `[${InterestedCreatorController} deleteAllQuestions API response success]`
    );
    res.send({
      statusCode: 200,
      data: faq,
      message: "All Creators deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${InterestedCreatorController} deleteAllQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.updateCreatorProfilePicture = async (req, res, next) => {
  try {
    if (req.creator.id && req.file) {

      // Check if a file is uploaded
      if (req.file) {
        const creator = await Creator.findById(req.creator.id);
        if (!creator) {
          return res.json({
            statusCode: 400,
            data: creator,
            message: `Creator with id ${req.creator.id} doesn't exist`,
            error: null,
          });
        }

        const { filename, destination } = req.file;
        let imagePath = destination + filename;

        creator.profile_pic = imagePath;
        await creator.save();

        return res.send({
          statusCode: 200,
          data: creator,
          message: "Profile Pic Updated Successfully",
          error: null,
        });
      }

      // Logging success
      logger.info(
        `[${InterestedCreatorController} updateCreatorProfile API response success]`
      );
      res.send({
        statusCode: 200,
        // data: creator,
        message: "Creator updated successfully",
        error: null,
      });
    }
  } catch (error) {
    // Logging error
    logger.error(
      `[${InterestedCreatorController} updateCreatorProfile API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.updateInterestedCreatorStatus = async (req, res, next) => {
  try {
    let check_if_interested_creator_exist = await InterestedCreator.findOne({ email: req.body.email });
   
    if (check_if_interested_creator_exist)
      return res.send({
        statusCode: 404,
        data: null,
        message: null,
        error: `Request with ${req.body.email} doesn't exist`,
      });

    const status = req.body.status;
    if(status == "InProgress" || status == "Document Processing" || status == "Complete"){
      check_if_interested_creator_exist.processing_stage = status;
     await check_if_interested_creator_exist.save();
      return res.send({
        statusCode: 200,
        data: null,
        message: "Status Updated Successfully",
        error: null,
      });
    }else{
      return res.send({
        statusCode: 400,
        data: null,
        message: null,
        error: `Invalid Status ${status}`,
      });
    }
    

    logger.info(`[${InterestedCreatorController} interestedCreatorSignup API response success]`);

    res.send({
      statusCode: 201,
      data: createCreator,
      message: "Sign Up Successfull",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${InterestedCreatorController} interestedCreatorSignup API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
