const { SOMETHING_WENT_WRONG } = require("../constant");
const { CompanyPolicy } = require("../models/policy");

const logger = require("winston");


const CompanyPolicyController = "COMPANY_POLICY_CONTROLLER";

module.exports.getStartChatMessage = async (req, res, next) => {
  try {
    const check_if_start_chat_message_exist = await CompanyPolicy.findOne({
      policyType: "Start Chat Message",
    });
    logger.info(
      `[${CompanyPolicyController} changeStartChatMessage API response success]`
    );
    if(!check_if_start_chat_message_exist){
      res.send({
        statusCode: 400,
        data: null,
        message: "Start Chat Message Doesn't Exist",
        error: null,
      });
    }

    res.send({
      statusCode: 200,
      data: check_if_start_chat_message_exist,
      message: "Start Chat Message Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CompanyPolicyController} changeStartChatMessage API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getPrivacyPolicyApprovalText = async (req, res, next) => {
  try {
    logger.info(
      `[${CompanyPolicyController} changePrivacyPolicyApprovalText API response success]`
    );
    res.send({
      statusCode: 200,
      data: "This is the privacy Policy Approval Text",
      message: "Privacy Policy Approval Text Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CompanyPolicyController} changePrivacyPolicyApprovalText API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getPrivacyPolicy = async (req, res, next) => {
  try {
    logger.info(
      `[${CompanyPolicyController} changePrivacyPolicy API response success]`
    );
    res.send({
      statusCode: 200,
      data: "This is the Privacy Policy",
      message: "Privacy Policy Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CompanyPolicyController} changePrivacyPolicy API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



module.exports.updateMessages = async (req, res, next) => {
  try {
    const {policy_type,content} = req.body;
    const valid_policy_types = ["Privacy Policy", "Start Chat Message", "Privacy Policy Approval Text","Web UI Message"]
    if(!valid_policy_types.includes(policy_type)){
      res.send({
        statusCode: 400,
        data: null,
        message: null,
        error: "Invalid Policy Type",
      });
    }
    const check_if_start_chat_message_exist = await CompanyPolicy.findOne({
      policyType: policy_type,
    });

    if (check_if_start_chat_message_exist) {
      // Update the existing record
      const updatedPolicy = await CompanyPolicy.findOneAndUpdate(
        { policyType: policy_type },
        { 
          content : content
        },
        { new: true }
      );
    } else {
      // Create a new record
      const newPolicy = new CompanyPolicy({
        policyType: policy_type,
        content : req.body.content
      });

      await newPolicy.save();
    }

    logger.info(
      `[${CompanyPolicyController} updateMessages API response success]`
    );

    res.send({
      statusCode: 200,
      data: null,
      message: `${policy_type} Message Added Successfully`,
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CompanyPolicyController} updateMessages API response error:- ${error.message}`
    );

    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



