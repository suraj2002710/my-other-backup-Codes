const logger = require("winston");
const VideoConnectivty = require("../models/VideoConnection");
const AudioConnectivty = require("../models/AudioConnection");
const { ChatHistory } = require("../models/ChatHistory");
const {
  CreatorUserConversationMessage,
} = require("../socket_chat_infra/models/creator_user_conversation_message");
const { Creator } = require("../models/Creator");
const {UserVisit} = require("../models/UserVisits");


creatorBotInsights = "CREATOR_BOT_INSIGHTS";


/**
 * Retrieves insights related to a specific creator's bot interactions.
 *
 * This function fetches various insights related to a creator's bot, including details about audio and video calls, 
 * and chat history. It first retrieves the creator's details using their ID, and then fetches data from AudioConnectivity,
 * VideoConnectivity, and ChatHistory collections using the creator's email. The function compiles and returns a summary 
 * of these insights.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the insights data and a success message.
 *   - If the creator does not exist, returns a 500 status code with a message indicating that the creator does not exist.
 *   - If an error occurs during data fetching, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of Creator, AudioConnectivity, VideoConnectivity, and ChatHistory models.
 *   The creator's ID is expected to be provided in the request (req.creator.id) and is used to fetch the creator's details.
 *   The insights are based on the creator's email extracted from the creator's details.
 *   The function uses a logger for logging information and errors.
 */

module.exports.getCreatorBotInsights = async (req, res, next) => {
  try {
    const get_creator_details = await Creator.findOne({
      "_id" : req.creator.id
    })
    if(get_creator_details){
       console.log("get_creator_details---------------------",get_creator_details)
      const get_creator_audio_call_details = await AudioConnectivty.find({
        creator_id : get_creator_details.email
      })

    

      const get_creator_video_call_details = await VideoConnectivty.find({
        creator_id : get_creator_details.id,
        connection:"complete"
      })

      console.log("get_creator_video_call_details---------------------",get_creator_video_call_details)

      const get_user_visits = await UserVisit.find({
        creator_id : get_creator_details.id
      })


      const chat_list_for_creator =await CreatorUserConversationMessage.find({
        creator_id : get_creator_details.id,
        from_ai:false,
        recipient:"creator"
        
      })
      //  await ChatHistory.aggregate([
      //   {
      //     $match: { creator_id: get_creator_details.id },
      //   },
      //   {
      //     $sort: { user_id: 1, createdAt: -1 },
      //   },
      //   {
      //     $group: {
      //       _id: "$user_id",
      //       lastMessage: { $first: "$$ROOT" },
      //     },
      //   },
      //   {
      //     $replaceRoot: { newRoot: "$lastMessage" },
      //   },
      // ]);
    
      res.send({
        statusCode: 200,
        data: {
          user_visites: get_user_visits.length,
          user_dm: chat_list_for_creator.length,
          video_calls: get_creator_video_call_details.length,
          audio_calls: get_creator_audio_call_details.length,
        },
        message: "Creator Bot Insights fetched successfully",
        error: null,
      });
    }else{
      res.send({
        statusCode: 500,
        data: null,
        message: "Creator Doesn't Exist",
        error: null,
      });
    }
   
  } catch (error) {
    logger.error(
      `[${creatorBotInsights} getCreatorBotInsights API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


