const logger = require("winston");

const commonControllers = "commonControllers";

const { getMicrosoftToken } = require("../services/common");



const AudioConnectivty = require("../models/AudioConnection");
const VideoConnectivty = require("../models/VideoConnection");
const { ChatHistory } = require("../models/ChatHistory");
const {
  CreatorUserConversationMessage,
} = require("../socket_chat_infra/models/creator_user_conversation_message");
const { Conversation } = require("../models/Conversation");
const { CreatorBankDetails } = require("../models/CreatorBankDetails");
const { CreatorKYC } = require("../models/CreatorKYC");
const { CreatorBillingDetails } = require("../models/CreatorBillingDetails");
const {UserVisit} = require("../models/UserVisits");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { CreatorLinkSuggestion } = require("../models/CreatorLinkSuggestion");










module.exports.getSystemHealth = async (req, res, next) => {
  try {
    res.send(200);
  } catch (error) {
    logger.error(
      `[${commonControllers} getSystemHealth API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.getServerHealth = async (req, res, next) => {
  try {
    let response = {
      serverHealth: true,
      serverRunningTime: Date.now(),
    };
    res.send(200, response);
  } catch (error) {
    logger.error(
      `[${commonControllers} getServerHealth API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.getToken = async (req, res, next) => {
  try {
    let response = await getMicrosoftToken();
    res.send(200, response);
  } catch (error) {
    logger.error(
      `[${commonControllers} getServerHealth API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
