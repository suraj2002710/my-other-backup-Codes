const { GoogleUser } = require("../models/GoogleUser");
const { User } = require("../models/Users");

const logger = require("winston");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const _ = require("lodash");
const { SOMETHING_WENT_WRONG } = require("../constant");

const GoogleUserController = "GOOGLE_USER_CONTROLLER";

module.exports.getAllGoogleUsers = async (req, res, next) => {
  try {
    const googleUser = await GoogleUser.find({});
    logger.info(
      `[${GoogleUserController} getAllGoogleUsers API response success]`
    );
    res.send({
      statusCode: 200,
      data: googleUser,
      message: "Google User list captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${GoogleUserController} getAllGoogleUsers API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getGoogleUserByEmail = async (req, res, next) => {
  try {
    const googleUser = await GoogleUser.findOne({ email: req.body.email });
    logger.info(
      `[${GoogleUserController} getGoogleUserByEmail API response success]`
    );
    res.send({
      statusCode: 200,
      data: googleUser,
      message: "Google User list captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${GoogleUserController} getGoogleUserByEmail API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getGoogleUserProfile = async (req, res, next) => {
  try {
    const googleUser = await GoogleUser.findById(req.user.id);
    logger.info(
      `[${GoogleUserController} getGoogleUserProfile API response success]`
    );
    res.send({
      statusCode: 200,
      data: googleUser,
      message: "Users profile captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${GoogleUserController} getGoogleUserProfile API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.createGoogleUser = async (req, res, next) => {
  try {
    if (!req.body.sub || !req.body.email) {
      return res.send({
        statusCode: 500,
        data: null,
        message: null,
        error: "Google auth are required.",
      });
    }

    let checkUser = await User.findOne({ email: req.body.email });
    if (!checkUser) {
      req.body.sign_up_method = "google"
      await GoogleUser.create(req.body);
    }

    const token = jwt.sign(
      { id: checkUser.id, email: checkUser.email, role: "user" },
      process.env.UserSecretKey
    );

    googleUser = _.pick(googleUser, ["id", "first_name", "last_name", "email"]);

    googleUser.token = token;

    logger.info(
      `[${GoogleUserController} createGoogleUser API response success]`
    );

    res.send({
      statusCode: 200,
      data: googleUser,
      message: "Users created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${GoogleUserController} createGoogleUser API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
