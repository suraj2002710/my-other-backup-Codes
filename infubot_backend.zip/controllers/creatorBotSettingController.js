const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { BaseRates } = require("../models/BaseRate");
// const redis = require("../queue_infra/redis_connection");
// const {config} = require("../queue_infra/redis_config");

const logger = require("winston");

const CreatorBotSettingController = "CREATOR_BOT_SETTING_CONTROLLER";


//Publisher Setup
// const io_redis = require('ioredis');
// const publisher = new io_redis(config);


/**
 * Retrieves bot setting details for a specific creator.
 *
 * This function fetches the bot setting details associated with a creator from the CreatorBotSetting
 * collection using the creator's ID. It is designed to return the bot settings that include various
 * configuration and preferences set by the creator for their bot.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the bot setting details and a success message.
 *   - If an error occurs during the retrieval process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBotSetting model.
 *   The creator's ID is expected to be provided in the request (req.creator.id) and is used to fetch the bot settings.
 *   The function uses a logger for logging information and errors.
 */

module.exports.getCreatorBotSettingDetails = async (req, res, next) => {
  try {
    const creator_bot_setting = await CreatorBotSetting.findOne({
      creator_id: req.creator.id,
    }).lean(); // Add .lean() to convert Mongoose document to a plain JavaScript object

    if (!creator_bot_setting) {
      return res.status(404).send({
        statusCode: 404,
        data: null,
        message: "Creator Bot settings not found",
        error: "Not Found",
      });
    }

    const base_rates = await BaseRates.findOne({});

    if (base_rates) {
      creator_bot_setting.base_rates = base_rates;
    }

    logger.info(`[${CreatorBotSettingController} getCreatorBotSettingDetails API response success]`);
    res.status(200).send({
      statusCode: 200,
      data: creator_bot_setting,
      message: "Creator Bot details captured successfully!",
      error: null,
    });
  } catch (error) {
    logger.error(`[${CreatorBotSettingController} getCreatorBotSettingDetails API response error:- ${error.message}`);
    res.status(500).send({
      statusCode: 500,
      data: null,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

//With Redis Caching
// module.exports.getCreatorBotSettingDetails = async (req, res, next) => {
//   try {
//     const redis_key = `creator_bot_setting:${req.creator.id}`;
//     const cached_data = await redis.get(redis_key);
    
//     if (cached_data) {
//       logger.info(`[${CreatorBotSettingController} getCreatorBotSettingDetails fetched from cache]`);
//       return res.status(200).json({
//         statusCode: 200,
//         data: JSON.parse(cached_data),
//         message: "Creator Bot details fetched successfully from cache",
//         error: null,
//       });
//     }

//     const creator_bot_setting = await CreatorBotSetting.findOne({
//       creator_id: req.creator.id,
//     }).lean(); // Convert Mongoose document to plain JavaScript object for easier serialization

//     if (!creator_bot_setting) {
//       return res.status(404).send({
//         statusCode: 404,
//         data: null,
//         message: "Creator Bot settings not found",
//         error: "Not Found",
//       });
//     }

//     const base_rates = await BaseRates.findOne({});
//     if (base_rates) {
//       creator_bot_setting.base_rates = base_rates;
//     }

//     // Cache the fetched result for future requests, with an expiration time (e.g., 10 minutes = 600 seconds)
//     await redis.set(redis_key, JSON.stringify(creator_bot_setting), 'EX', 120);

//     logger.info(`[${CreatorBotSettingController} getCreatorBotSettingDetails API response success]`);
//     res.status(200).send({
//       statusCode: 200,
//       data: creator_bot_setting,
//       message: "Creator Bot details captured successfully!",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[${CreatorBotSettingController} getCreatorBotSettingDetails API response error:- ${error.message}`);
//     res.status(500).send({
//       statusCode: 500,
//       data: null,
//       message: "Internal Server Error",
//       error: error.message,
//     });
//   }
// };



/**
 * Adds new bot settings for a creator.
 *
 * This function handles the creation of new bot settings for a creator. It checks for the required fields 
 * in the request body, such as bot title, language, welcome message, cost per minute, and text suggestions. 
 * If any required field is missing, it returns an error. If all required fields are present, the function 
 * then checks if bot settings for the creator already exist. If they do, it informs the user that settings 
 * already exist. Otherwise, it creates new bot settings with the provided details.
 *
 * @returns {void}
 *   - If required fields are missing, returns a 500 status code with an error message specifying the missing fields.
 *   - If bot settings already exist for the creator, returns a 201 status code with a message to update the settings.
 *   - On successful creation of bot settings, returns a 201 status code with the created settings details and a success message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBotSetting model.
 *   The creator's ID is expected to be provided in the request (req.creator.id) and is used along with the request body to create the bot settings.
 *   The function uses a logger for logging information and errors.
 */

module.exports.addCreatorBotSetting = async (req, res, next) => {
  try {
    let reqBody = req.body;

    const requiredFields = {
      bot_title: "Bot Title is required for bot setup",
      bot_language: "Bot Language is required for bot setup",
      message: "Welcome Message is Required",
      cost_per_min: "Cost Per Minute is Required",
      textSuggestion : "Text Suggestion is Required",
    };

    const missingFields = Object.entries(requiredFields)
      .filter(([field, label]) => req.body[field] === undefined)
      .map(([field, label]) => label);

    if (missingFields.length > 0) {
      return res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: `${missingFields.join(" and ")} ${
          missingFields.length > 1 ? "are" : "is"
        } required.`,
      });
    }


    reqBody.creator_id = req.creator.id;
    const check_creator_bot_settings = await CreatorBotSetting.find({
      creator_id: req.creator.id,
    });
    // console.log("Creator Bot Settings",check_creator_bot_settings )
    if(check_creator_bot_settings){
      res.send({
        statusCode: 201,
        data : null,
        message: "Creator Bot Settings Already Exist. Please Update the settings",
        error: null,
      });
    }else{
      const creator_bot_setting = await CreatorBotSetting.create(reqBody);
    logger.info(
      `[${CreatorBotSettingController} addCreatorBotSetting API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_bot_setting,
      message: "Creator Bot Settings Setup Completed",
      error: null,
    });
    }  
  } catch (error) {
    logger.error(
      `[${CreatorBotSettingController} addCreatorBotSetting API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Updates the bot settings for a specific creator.
 *
 * This function updates the bot settings associated with a creator. It uses the creator's ID to find the
 * existing bot settings in the CreatorBotSetting collection and then updates these settings with the new
 * information provided in the request body. The updated settings are then returned to the client.
 *
 * @returns {void}
 *   - On successful update, returns a 201 status code with the updated bot settings and a success message.
 *   - If an error occurs during the update process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBotSetting model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 *   The 'new: true' option in findOneAndUpdate ensures that the updated document is returned.
 */
module.exports.updateCreatorBotSetting = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator = req.creator;



    const creator_bot_setting = await CreatorBotSetting.findOneAndUpdate(
      { creator_id: req.creator.id },
      reqBody,
      { new: true }
    );

    // if(req.body.message){
    //   publisher.publish("creator_bot_status", JSON.stringify(creator_bot_setting));
    // }


    logger.info(
      `[${CreatorBotSettingController} updateCreatorBotSetting API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_bot_setting,
      message: "Creator updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBotSettingController} updateCreatorBotSetting API response error:- ${error.message}`
    );
    res.send({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
