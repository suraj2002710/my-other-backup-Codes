const { Transaction } = require("../models/Transaction");
const { Wallet } = require("../models/Wallet");

const logger = require("winston");

const TransactionController = "TRANSACTION_CONTROLLER";

module.exports.getAllTransaction = async (req, res, next) => {
  try {
    const transaction = await Transaction.find({}); //pagination
    logger.info(
      `[${TransactionController} getAllTransaction API response success]`
    );
    res.send(transaction);
  } catch (error) {
    logger.error(
      `[${TransactionController} getAllTransaction API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.getUserTranscation = async (req, res, next) => {
  // console.log('Here')
  try {
    const transaction = await Transaction.find({
      user_id: req.user.id,
      $or: [
        { type: "Video" },
        { status: "success" }
      ]
    });
    
    // console.log("Transactions", transaction)
    logger.info(
      `[${TransactionController} getUserTranscation API response success]`
    );
    return res.status(200).json({
      statusCode: 200,
      data: transaction,
      message: "All users transaction fetced successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${TransactionController} getuserTranscation API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.getCreatorTranscation = async (req, res, next) => {
  try {
    const transaction = await Transaction.find({
      creator_id: req.body.creator_id,
    }); //pagination
    logger.info(
      `[${TransactionController} getCreatorTranscation API response success]`
    );
    res.send(transaction);
  } catch (error) {
    logger.error(
      `[${TransactionController} getCreatorTranscation API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.sendTransaction = async (req, res, next) => {
  try {
    const transaction = await Transaction.create(req.body);

    // const userWallet = await Wallet.findOneAndUpdate({ user_id: req.body.user_id }, { wallet_balance:  })
  } catch (error) {
    logger.error(
      `[${TransactionController} sendTransaction API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
