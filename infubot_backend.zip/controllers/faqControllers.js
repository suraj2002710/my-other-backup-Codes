const { SOMETHING_WENT_WRONG } = require("../constant");
const { FAQ } = require("../models/FAQ");

const logger = require("winston");

const faqController = "FAQ_CONTROLLERS";

module.exports.getAllFAQs = async (req, res, next) => {
  try {
    const faq = await FAQ.find({});
    logger.info(`[${faqController} getFAQs API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "Get all FAQs list",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} getFAQs API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.postFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.create(req.body);
   await faq.save();
    logger.info(`[${faqController} getFAQs API response success]`);
    res.send({
      statusCode: 201,
      data: faq,
      message: "FAQ created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} postFAQ API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getDetailFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.findById(req.params.id);
    logger.info(`[${faqController} getDetailFAQ API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "Fetch FAQ details successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} getDetailFAQ API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.updateFaq = async (req, res, next) => {
  try {
    const update_faq = await FAQ.findByIdAndUpdate(req.params.id, req.body);
    logger.info(`[${faqController} updateFaq API response success]`);
    res.send({
      statusCode: 200,
      data: update_faq,
      message: "FAQ updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} postFAQ API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.deleteFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.findByIdAndRemove(req.params.id);
    logger.info(`[${faqController} deleteFAQ API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "FAQ deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} deleteFAQ API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.deleteAllFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.deleteMany({});
    logger.info(`[${faqController} deleteAllFAQ API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "All FAQ's deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${faqController} deleteAllFAQ API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
