const { SOMETHING_WENT_WRONG } = require("../constant");
const { OnboardingQuestions } = require("../models/onboardingQuestions");

const logger = require("winston");

const onboardingQuestions = "ONBOARDING_QUESTIONS";

module.exports.getAllQuestions = async (req, res, next) => {
  try {
    const faq = await OnboardingQuestions.find({});
    logger.info(`[${onboardingQuestions} getAllQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "Get all Questions List",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} getAllQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addGenreOnboardingQuestion = async (req, res, next) => {
  try {
    const requiredFields = {
        creator_niche: "Creator Niche/Genre",
        question: "question",
        type: "Type",
      };
  
      const missingFields = Object.entries(requiredFields)
        .filter(([field, label]) => req.body[field] === undefined)
        .map(([field, label]) => label);
  
      if (missingFields.length > 0) {
        return res.status(500).send({
          statusCode: 500,
          data: null,
          message: null,
          error: `${missingFields.join(" and ")} ${
            missingFields.length > 1 ? "are" : "is"
          } required.`,
        });
      }
    const faq = await OnboardingQuestions.create(req.body);
    // faq.save();
    logger.info(`[${onboardingQuestions} addGenreOnboardingQuestion API response success]`);
    res.send({
      statusCode: 201,
      data: faq,
      message: "FAQ created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} addGenreOnboardingQuestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getAllQuestionsOfNiche = async (req, res, next) => {
  try {
    const {creator_niche} = req.params;
    if(!creator_niche){
       return {
        statusCode: 500,
        data: null,
        message: null,
        error: "Creator Niche is required",
       }
    }
    const faq = await OnboardingQuestions.find({
        creator_niche
    });
    logger.info(`[${onboardingQuestions} getAllQuestionsOfNiche API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "Niche Questions Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} getAllQuestionsOfNiche API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.deleteOnboardingQuestions = async (req, res, next) => {
  try {
    const {creator_niche,question_id} = req.params;
    const faq = await OnboardingQuestions.findOneAndRemove({
        creator_niche,id : question_id
    });
    logger.info(`[${onboardingQuestions} deleteOnboardingQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "FAQ deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} deleteOnboardingQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.deleteAllQuestions = async (req, res, next) => {
  try {
    const faq = await OnboardingQuestions.deleteMany({
      
    });
    logger.info(`[${onboardingQuestions} deleteOnboardingQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "FAQ deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} deleteOnboardingQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
