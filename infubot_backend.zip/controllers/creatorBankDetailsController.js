const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorBankDetails } = require("../models/CreatorBankDetails");
const { Creator } = require("../models/Creator");

const logger = require("winston");
const { CreatorKYC } = require("../models/CreatorKYC");
const { CreatorBillingDetails } = require("../models/CreatorBillingDetails");

const CreatorBankDetailsController = "CREATOR_BANK_DETAILS_CONTROLLER";


/**
 * Retrieves bank details for a specific creator.
 *
 * This function fetches the bank details associated with a creator from the CreatorBankDetails collection
 * using the creator's ID. It is designed to return the bank details that are stored for a particular creator.
 *
 * @returns {void}
 *   - On successful retrieval, returns a 200 status code with the bank details data and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBankDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */

module.exports.getCreatorBankDetails = async (req, res, next) => {
  try {
    const checkCreator = await Creator.findById(req.creator.id);
    if (!checkCreator) {
      return res.status(400).send({
        statusCode: 400,
        message: "Creator doesn't exist",
        error: null,
      });
    }


    const creator_bank_details = await CreatorBankDetails.findOne({
      creator_id: req.creator.id,
    });
    if(creator_bank_details){
      logger.info(
        `[${CreatorBankDetailsController} getCreatorBankDetails API response success]`
      );
      res.status(200).json({
        statusCode: 200,
        data: creator_bank_details,
        message: "Creator Bank details captured sucessfully!",
        error: null,
      });
    }else{
      res.status(200).json({
        statusCode: 200,
        data: null,
        message: "Creator Bank details doesn't exist",
        error: null,
      });
    }

  } catch (error) {
    logger.error(
      `[${CreatorBankDetailsController} getCreatorBankDetails API response error:- ${error.message}`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


/**
 * Adds bank details for a specific creator.
 *
 * This function adds new bank details for a creator to the CreatorBankDetails collection. 
 * It first checks if the creator exists and if bank details for the creator already exist.
 * If the creator does not exist or bank details already exist, it returns an error.
 * Otherwise, it adds the new bank details to the collection.
 *
 * @returns {void}
 *   - If the creator does not exist, returns a 400 status code with a message indicating the creator doesn't exist.
 *   - If bank details for the creator already exist, returns a 400 status code with a message suggesting to update them.
 *   - On successful addition, returns a 201 status code with the added bank details data and a success message.
 *   - If an error occurs, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a Creator and CreatorBankDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 *   It also updates the `payout_setting` flag in the Creator model upon successful addition.
 */
module.exports.addCreatorBankDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator_id = req.creator.id;

    const check_if_creator_exist = await Creator.findById(reqBody.creator_id)
    if(!check_if_creator_exist){
      return  res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    const check_if_creator_bank_details_exist = await CreatorBankDetails.find({
      creator_id: req.creator.id,
    });
    // console.log("check_if_creator_bank_details_exist",check_if_creator_bank_details_exist)
    if(check_if_creator_bank_details_exist){
      return  res.status(400).json({
        statusCode: 400,
        data: check_if_creator_bank_details_exist,
        message: "Creator bank Details Already Exist. Please update if need to be changed",
        error: null,
      });
    }

    const creator_bank_details = await CreatorBankDetails.create(reqBody);
    logger.info(
      `[${CreatorBankDetailsController} addCreatorBankDetails API response success]`
    );


    check_if_creator_exist.payout_setting = true;
   await check_if_creator_exist.save()

    res.status(201).json({
      statusCode: 201,
      data: creator_bank_details,
      message: "Creator Bank details added successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBankDetailsController} addCreatorBankDetails API response error:- ${error.message}`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Updates bank details for a specific creator.
 *
 * This function updates the bank details for a creator in the CreatorBankDetails collection. 
 * It uses the creator's ID from the request to identify the specific bank details to be updated.
 * The function then updates the bank details with the new information provided in the request body.
 *
 * @returns {void}
 *   - On successful update, returns a 201 status code with the updated bank details data and a success message.
 *   - If an error occurs during the update, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBankDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */
module.exports.updateCreatorBankDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator = req.creator.id;
    const creator_bank_details = await CreatorBankDetails.updateOne(
      { creator_id: req.creator.id },
      reqBody
    );
    logger.info(
      `[${CreatorBankDetailsController} updateCreatorBankDetails API response success]`
    );
    res.status(201).json({
      statusCode: 201,
      data: creator_bank_details,
      message: "Creator Bank Details updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBankDetailsController} updateCreatorBankDetails API response error:- ${error.message}`
    );
    res.status(201).json({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};



/**
 * Deletes bank details for a specific creator.
 *
 * This function deletes the bank details associated with a creator in the CreatorBankDetails collection. 
 * It uses the creator's ID from the request to identify and delete the specific bank details.
 * The deletion is performed based on a match with the creator's ID.
 *
 * @returns {void}
 *   - On successful deletion, returns a 200 status code with a message indicating successful deletion.
 *   - If an error occurs during the deletion, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of a CreatorBankDetails model.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */
module.exports.deleteCreatorBankDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    reqBody.creator = req.creator.id;
    const creator_bank_details = await CreatorBankDetails.deleteOne(
      { creator_id: req.creator.id }
    );
    logger.info(
      `[${CreatorBankDetailsController} deleteCreatorBankDetails API response success]`
    );
    res.status(200).json({
      statusCode: 200,
      data: null,
      message: "Creator Bank Details deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorBankDetailsController} updateCreatorBankDetails API response error:- ${error.message}`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

/**
 * Updates or adds bank details for a specific creator.
 *
 * This function first checks if a creator exists in the database using the creator's ID. If the creator does not exist,
 * it sends a response indicating the absence of the creator. If the creator exists, it checks if the creator already 
 * has bank details stored. Depending on whether the bank details exist or not, the function either updates the existing 
 * bank details or adds new bank details to the CreatorBankDetails collection.
 *
 * @returns {void}
 *   - If the creator does not exist, returns a 400 status code with an appropriate message.
 *   - On successful update or addition of bank details, returns a 201 status code with the bank details and a success message.
 *   - If an error occurs during the process, returns a 500 status code with an error message.
 *
 * @note
 *   The function assumes the existence of Creator and CreatorBankDetails models.
 *   The creator's ID is expected to be provided in the request (req.creator.id).
 *   The function uses a logger for logging information and errors.
 */

module.exports.changeBankDetails = async (req, res, next) => {
  try {
    let reqBody = req.body;
    // console.log("req", reqBody)

    const check_if_creator_exist = await Creator.findById(req.creator.id)
    if(!check_if_creator_exist){
      return  res.status(400).json({
        statusCode: 400,
        data: null,
        message: "Creator doesn't exist",
        error: null,
      });
    }

    const check_if_creator_bank_account_exist = await CreatorBankDetails.findOne({creator_id:req.creator.id});
    
    if(check_if_creator_bank_account_exist){
      // console.log("Creator Bank Details Exist. Updating the details")
      reqBody.creator = req.creator.id;
      const creator_bank_details = await CreatorBankDetails.updateOne(
        { creator_id: req.creator.id },
        reqBody,
        {new : true}
      );
      const updated_creator_bank_details = await CreatorBankDetails.findOne(
        {creator_id:req.creator.id}
      );
      
      logger.info(
        `[${CreatorBankDetailsController} updateCreatorBankDetails API response success]`
      );
      res.status(201).json({
        statusCode: 201,
        data: updated_creator_bank_details,
        message: "Creator Bank Details updated successfully",
        error: null,
      });
    }else{
      // console.log("Creator Bank Details Doesn't Exist. Adding the bank details")
      reqBody.creator_id = req.creator.id
      const creator_bank_details = await CreatorBankDetails.create(reqBody);
      // console.log("----creator_bank_details",creator_bank_details)
      logger.info(
        `[${CreatorBankDetailsController} addCreatorBankDetails API response success]`
      );
      check_if_creator_exist.payout_setting = true;
      check_if_creator_exist.is_banking_details_added = true
     await check_if_creator_exist.save()
  
      res.status(201).json({
        statusCode: 201,
        data: creator_bank_details,
        message: "Creator Bank details added successfully",
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${CreatorBankDetailsController} updateCreatorBankDetails API response error:- ${error.message}`
    );
    res.status(201).json({
      statusCode: 201,
      data: null,
      message: null,
      error: error.message,
    });
  }
};