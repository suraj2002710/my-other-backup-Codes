const { User } = require("../models/Users");
const { OTP } = require("../models/otp"); // Adjust the path
const { sendOTPEmail } = require("../services/emailNotification");

module.exports.validateOTP = async (req, res, next) => {
  const { email, otp } = req.body;

  if (!email || !otp) {
    return res.status(400).send("Email and OTP are required");
  }

  try {
    const otpRecord = await OTP.findOne({
      email: email,
      otp: otp,
      isValid: true,
    });

    if (!otpRecord) {
      return res.status(400).send({
        statusCode: 200,
        message: "Invalid OTP Email",
        error: null,
      });
    }

    // Optionally invalidate the OTP after successful validation
    otpRecord.isValid = false;
    await otpRecord.save();

    return res.send({
      statusCode: 200,
      message: "OTP validated successfully",
      error: null,
    });
    // return res.status(200).send('OTP validated successfully');
  } catch (error) {
    console.error(error);
    // return res.status(500).send("Server error");
    return res.send({
      statusCode: 200,
      message: null,
      error: error.message,
    });
  }
};

module.exports.sendOTP = async (req, res, next) => {
  const { email } = req.body;

  // console.log("Email", email)

  if (!email) {
    return res.status(400).json({
      statusCode: 400,
      message: "email is required",
      error: null,
    });
  }

  const check_if_user_exist = await User.findOne({
    email
  })

  // console.log("....",check_if_user_exist)

  if (check_if_user_exist) {
    return res.status(400).json({
      statusCode: 400,
      message: `Email already exist`,
      error: null,
    });
  }

  try {
    const delete_active_otp_from_user = await OTP.deleteMany({
      email: email,
      isValid: true,
    });

    // console.log("User Previous OTP's", delete_active_otp_from_user)


    const otpDetails = await sendOTPEmail(email);
    return res.status(200).json({
      statusCode: 200,
      message: `OTP sent successfully`,
      error: null,
    });
  } catch (error) {
    console.error(error);
    // return res.status(500).send("Server error");
    return res.status(500).json({
      statusCode: 500,
      message: null,
      error: error.message,
    });
  }
};

module.exports.resendOTP = async (req, res, next) => {
  const { email } = req.body;

  // console.log("Email", email)

  if (!email) {
    return res.send({
      statusCode: 400,
      message: "email is required",
      error: null,
    });
  }

  // const check_if_user_exist = await User.findOne({
  //   email
  // })

  // console.log("....",check_if_user_exist)

  // if(check_if_user_exist){
  //   return res.send({
  //     statusCode: 400,
  //     message: `User with email ${email} already exist`,
  //     error: null,
  //   });
  // }

  try {

    const get_user_otp_details = await OTP.findOne({
      email: email,
      isValid: true,
    });

    console.log("---", get_user_otp_details)

    if (get_user_otp_details.isValid == true && get_user_otp_details.count >= 5) {
      return res.status(400).json({
        statusCode: 400,
        message: `OTP resend limit exceeded`,
        error: null,
      });
    } else {
      get_user_otp_details.count = get_user_otp_details.count + 1
      await get_user_otp_details.save()
      const otpDetails = await sendOTPEmail(email);
      return res.status(200).json({
        statusCode: 200,
        message: `OTP resent successfully`,
        data: get_user_otp_details,
        error: null,
      });
    }

    // console.log("User Previous OTP's", delete_active_otp_from_user)



  } catch (error) {
    console.error(error);
    // return res.status(500).send("Server error");
    return res.status(500).json({
      statusCode: 500,
      message: null,
      error: error.message,
    });
  }
};
