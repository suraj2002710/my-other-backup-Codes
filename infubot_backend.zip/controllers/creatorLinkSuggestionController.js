const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorLinkSuggestion } = require("../models/CreatorLinkSuggestion");

const logger = require("winston");

const CreatorLinkSuggestionController = "CREATOR_LINK_SUGGESTION_CONTROLLER";

module.exports.getCreatorLinkSuggestion = async (req, res, next) => {
  try {
    const creator_link_suggestion = await CreatorLinkSuggestion.find({});
    logger.info(
      `[${CreatorLinkSuggestionController} getCreatorLinkSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_link_suggestion,
      message: "Get all creator link suggestion successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorLinkSuggestionController} getCreatorLinkSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getActiveCreatorLinkSuggestion = async (req, res, next) => {
  try {
    const creator_link_suggestion = await CreatorLinkSuggestion.find({
      is_active: true,
    });
    logger.info(
      `[${CreatorLinkSuggestionController} getActiveCreatorLinkSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_link_suggestion,
      message: "Active creator link suggestions captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorLinkSuggestionController} getActiveCreatorLinkSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addCreatorLinkSuggestion = async (req, res, next) => {
  try {
    const creator_link_suggestion = await CreatorLinkSuggestion.create(
      req.body
    );
    logger.info(
      `[${CreatorLinkSuggestionController} addCreatorLinkSuggestion API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_link_suggestion,
      message: "Creator link suggestion created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorLinkSuggestionController} addCreatorLinkSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.updateCreatorLinkSuggestion = async (req, res, next) => {
  try {
    const creator_link_suggestion =
      await CreatorLinkSuggestion.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });
    logger.info(
      `[${CreatorLinkSuggestionController} updateCreatorLinkSuggestion API response success]`
    );
    res.send({
      statusCode: 201,
      data: creator_link_suggestion,
      message: "Creator link suggestion updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorLinkSuggestionController} updateCreatorLinkSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.deleteCreatorLinkSuggestion = async (req, res, next) => {
  try {
    const creator_link_suggestion =
      await CreatorLinkSuggestion.findByIdAndRemove(req.params.id);
    logger.info(
      `[${CreatorLinkSuggestionController} deleteCreatorLinkSuggestion API response success]`
    );
    res.send({
      statusCode: 200,
      data: creator_link_suggestion,
      message: "Creator link suggestion deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${CreatorLinkSuggestionController} deleteCreatorLinkSuggestion API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: "Creator Link suggestion deleted successfully",
    });
  }
};
