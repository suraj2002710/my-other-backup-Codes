const { SOMETHING_WENT_WRONG } = require("../constant");
const { CreatorOnboardingQuestionReply } = require("../models/onboardingQuestions");
const { Creator } = require("../models/Creator");

const logger = require("winston");

const OnboardingQuestionReply = "ONBOARDING_QUESTIONS_REPLY";

module.exports.getAllCreatorsReplyOfOnboardingQuestions = async (req, res, next) => {
  try {
    const faq = await CreatorOnboardingQuestionReply.find({});
    logger.info(`[${OnboardingQuestionReply} getAllQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "All Onboarding questions reply fetched successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${OnboardingQuestionReply} getAllQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.addReplyOfCreatorOnboardingQuestions = async (req, res, next) => {
    try {
      const { username, questions } = req.body;
  
      // Check for required fields
      if (!username || !questions || !Array.isArray(questions) || questions.length === 0) {
        return res.status(500).send({
          statusCode: 500,
          data: null,
          message: null,
          error: "Creator Username and Questions array are required.",
        });
      }
  
      // Check if the creator exists
      const fetchCreatorDetails = await Creator.findOne({ "username": username });
      if (!fetchCreatorDetails) {
        return res.status(500).send({
          statusCode: 500,
          data: null,
          message: null,
          error: "Creator doesn't exist",
        });
      }
  
      // Process and save question replies
      const replies = questions.map(async (question) => {
        const addReply = await CreatorOnboardingQuestionReply.create({
          creator_id: fetchCreatorDetails.id,
          question_id: question.question,
          reply: question.reply,
        });
        return addReply;
      });
  
      await Promise.all(replies); // Wait for all replies to be saved
  
      logger.info("[addReplyOfCreatorOnboardingQuestions API response success]");
      res.status(201).send({
        statusCode: 201,
        data: null,
        message: "Creators Reply added successfully",
        error: null,
      });
    } catch (error) {
      logger.error(`[addReplyOfCreatorOnboardingQuestions API response error: ${error.message}]`);
      res.status(500).send({
        statusCode: 500,
        data: null,
        message: null,
        error: error.message,
      });
    }
  };
  

module.exports.getAllQuestionsOfNiche = async (req, res, next) => {
  try {
    const {creator_niche} = req.params;
    if(!creator_niche){
       return {
        statusCode: 500,
        data: null,
        message: null,
        error: "Creator Niche is required",
       }
    }
    const faq = await OnboardingQuestions.find({
        creator_niche
    });
    logger.info(`[${onboardingQuestions} getAllQuestionsOfNiche API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "Niche Questions Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} getAllQuestionsOfNiche API response error:- ${error.message}`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.deleteOnboardingQuestions = async (req, res, next) => {
  try {
    const {creator_niche,question_id} = req.params;
    const faq = await OnboardingQuestions.findOneAndRemove({
        creator_niche,id : question_id
    });
    logger.info(`[${onboardingQuestions} deleteOnboardingQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "FAQ deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} deleteOnboardingQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};


module.exports.deleteAllQuestions = async (req, res, next) => {
  try {
    const faq = await OnboardingQuestions.deleteMany({
      
    });
    logger.info(`[${onboardingQuestions} deleteOnboardingQuestions API response success]`);
    res.send({
      statusCode: 200,
      data: faq,
      message: "FAQ deleted successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${onboardingQuestions} deleteOnboardingQuestions API response error:- ${error.message}`
    );
    res.send({
      statusCode: 200,
      data: null,
      message: null,
      error: error.message,
    });
  }
};
