const { User } = require("../models/Users");
const { ChatHistory } = require("../models/ChatHistory");
const { Conversation } = require("../models/Conversation");
const { Orders } = require("../models/Orders");
const VideoConnectivty = require("../models/VideoConnection");
const AudioConnectivty = require("../models/AudioConnection");
const { DeletedUser } = require("../models/UserAccountSelfDeletedList")
const {
  CreatorUserConversationMessage,
} = require("../socket_chat_infra/models/creator_user_conversation_message");
const admin = require("firebase-admin");

const logger = require("winston");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const _ = require("lodash");
const { Wallet } = require("../models/Wallet");
const { SOMETHING_WENT_WRONG } = require("../constant");
const { sendOTPEmail } = require("../services/emailNotification");
const { HashMapper } = require("../models/HashMapper");
const { generateRandomHash } = require("../utilities/hasher");
const fs = require("fs");
const path = require("path");
const { random_user_profile } = require("../utilities/random_profile_images")

const UserController = "USER_CONTROLLER";

module.exports.getAllUsers = async (req, res, next) => {
  try {
    const user = await User.find({});
    logger.info(`[${UserController} getAllUsers API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: user,
      message: "Users list captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} getAllUsers API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getAllLiveUsers = async (req, res, next) => {
  try {
    const user = await User.find({
      is_logged_in: true,
    });
    logger.info(`[${UserController} getAllUsers API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: user,
      message: "Users list captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} getAllUsers API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getUserByEmail = async (req, res, next) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    logger.info(`[${UserController} getUserByEmail API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: user,
      message: "Users list captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} getUserByEmail API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.checkIfEmailExist = async (req, res, next) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    logger.info(`[${UserController} getUserByEmail API response success]`);
    if (user) {
      res.status(400).json({
        statusCode: 400,
        data: null,
        message: `Users already exist with email ${req.body.email}`,
        error: null,
      });
    } else {
      res.status(400).json({
        statusCode: 400,
        data: null,
        message: `Users doesn't exist with email ${req.body.email}`,
        error: null,
      });
    }
  } catch (error) {
    logger.error(
      `[${UserController} getUserByEmail API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    console.log("User", user)
    if (!user) {
      return res.status(400).json({
        statusCode: 400,
        data: user,
        message: "Users profile doesn't exist",
        error: null,
      });
    }

    if (user.has_logged_in_for_first_time) {
      user.has_logged_in_for_first_time = false;
      await user.save()
    }

    logger.info(`[${UserController} getUserProfile API response success]`);
    const randomNumber = Math.floor(Math.random() * 30) + 1;
    user.profile_image = user.profile_image
      ? user.profile_image
      // : process.env.BASE_URL_FOR_IMAGES + "public/user_dummies/dummy_1.png";
      // : "http://192.168.29.186:3978" + `/public/user_dummies/dummy_${randomNumber}.png`;
      : random_user_profile();
    return res.status(200).json({
      statusCode: 200,
      data: user,
      message: "Users profile captured successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} getUserProfile API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.createUser = async (req, res, next) => {
  try {
    // console.log("Data",req.body)
    if (req.body.email === undefined) {
      return res.status(500).json({
        statusCode: 500,
        data: null,
        message: null,
        error: "Email is required.",
      });
    }

    const check_if_user_exist = await User.findOne({
      email: req.body.email,
      // phone_number : phone_number
    })
    if (check_if_user_exist) {
      return res.status(500).json({
        statusCode: 500,
        data: null,
        message: null,
        error: "Email already exist",
      });
    }

    // const salt = await bcrypt.genSalt(10);
    // const hashedPassword = await bcrypt.hash(req.body.password, salt);
    let user = await User.create(req.body);
    // let user = new User({
    //   ...req.body,
    //   password: hashedPassword
    // });
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);
    await user.save();
    // await user.save();
    // user.password = undefined;
    console.log("called google auth........")
    let wallet = await Wallet.create({
      user_id: user._id,
      wallet_balance: 0,
      sign_up_bonus:50,
      user_email: req.body.email,
    });

    console.log("user wallet created ..... ",wallet)
    const token = jwt.sign(
      { id: user.id, email: user.email, role: "user" },
      process.env.UserSecretKey
    );

    user = _.pick(user, [
      "id",
      "first_name",
      "last_name",
      "email",
      // "phone_number",
      "is_logged_in",
      "is_active",
    ]);

    user.token = token;

    logger.info(`[${UserController} createUser API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: user,
      message: "Users created successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} createUser API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.loginUser = async (req, res, next) => {
  try {
    let user = await User.findOne({ email: req.body.email });
    if (!user) {
      logger.info(
        `[${UserController} createUser API response message :- User ${req.body.email} not found]`
      );
      return res.status(400).json({
        statusCode: 404,
        data: null,
        message: null,
        error: "User not found!",
      });
    }
    if (!user.is_active)
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: null,
        error: "User is not active.",
      });

    user.is_logged_in = true;
   await user.save();
    let validatePassword = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (!validatePassword) {
      return res.status(400).json({
        statusCode: 400,
        data: null,
        message: null,
        error: "Invalid Password",
      });
    }

    // const token = jwt.sign(
    //   { id: user.id, email: user.email, role: "user" },
    //   process.env.UserSecretKey
    // );


    // const update_all_hashmap_value_of_user_to_false = await HashMapper.updateMany({ id : user.id }, { $set: {
    //   active : false
    // } });

    const hash = generateRandomHash();
    const ipAddress =
      req.headers["x-forwarded-for"] || req.connection.remoteAddress;
    const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
    // console.log("Client IP Address:", ip);
    const save_user_hash = await HashMapper.create({
      id: user.id,
      secret_value: hash,
      ip,
    });

    if (save_user_hash) {
      user = _.pick(user, [
        "id",
        "first_name",
        "last_name",
        "email",
        "phone_number",
        // "gender",
        "is_logged_in",
        "is_active",
        "has_logged_in_for_first_time",
      ]);

      const token = jwt.sign(
        { id: hash, role: "user" },
        process.env.UserSecretKey
      );

      user.token = token;
      logger.info(`[${UserController} createUser API response success]`);
      return res.status(200).json({
        statusCode: 200,
        data: user,
        message: "Users logged In successfully",
        error: null,
      });
    } else {
      return res.status(400).json({
        statusCode: 200,
        data: null,
        message: "Something went wrong. Unable to login at this momemt",
        error: true,
      });
    }
  } catch (error) {
    logger.error(
      `[${UserController} loginUser API response error:- ${error.message}]`
    );
    res.status(500).send({ error: error.message });
  }
};

module.exports.GoogleUser = async (req, res, next) => {
  // console.log("Data",req.body);
  const reqBody = {};
  const data = req.body.providerData[0]
  const fullname = data.displayName.split(" ");
  reqBody.first_name = fullname[0]
  reqBody.last_name = fullname.slice(1).join(" ");
  reqBody.sign_up_method = "Google";
  reqBody.email = data.email;
  reqBody.profile_image = data.photoURL;

  try {
    // const {first_name,last_name,email,phone_number,gender} = req.body
    if (reqBody.email === undefined) {
      return res.status(500).json({
        statusCode: 500,
        data: null,
        message: null,
        error: "Email is required.",
      });
    }

    const check_if_user_exist = await User.findOne({
      email: reqBody.email,
    })

    let user;

    console.log("called........",check_if_user_exist)
    
    if (!check_if_user_exist) {
      // console.log("User Doesn't exist")
   
      user = await User.create(reqBody);
      let wallet = await Wallet.create({
        user_id: user._id,
        wallet_balance: 0,
        sign_up_bonus:50,
        user_email: req.body.email,
      });
      user.has_logged_in_for_first_time = true;
    } else {
      // console.log("User Exist")
      user = check_if_user_exist
      user.has_logged_in_for_first_time = false;

    }

    // if (user.has_logged_in_for_first_time) {
    // }

    user.is_logged_in = true;
    await user.save()

    const hash = generateRandomHash();
    const ipAddress =
      req.headers["x-forwarded-for"] || req.connection.remoteAddress;
    const ip = ipAddress ? ipAddress.split(",")[0].trim() : "";
    // console.log("Client IP Address:", ip);
    const save_user_hash = await HashMapper.create({
      id: user.id,
      secret_value: hash,
      ip,
    });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: "user" },
      process.env.UserSecretKey
    );

    if (save_user_hash) {
      user = _.pick(user, [
        "id",
        "first_name",
        "last_name",
        "email",
        "phone_number",
        // "gender",
        "is_logged_in",
        "is_active",
        "has_logged_in_for_first_time",
      ]);

      const token = jwt.sign(
        { id: hash, role: "user" },
        process.env.UserSecretKey
      );

      user.token = token;
      logger.info(`[${UserController} createUser API response success]`);
      return res.status(200).json({
        statusCode: 200,
        data: user,
        message: "Users logged In successfully",
        error: null,
      });
    } else {
      return res.status(400).json({
        statusCode: 200,
        data: null,
        message: "Something went wrong. Unable to login at this momemt",
        error: true,
      });
    }
  } catch (error) {
    logger.error(
      `[${UserController} createUser API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

module.exports.logoutUser = async (req, res, next) => {
  try {
    let user = await User.findById(req.user.id);
    if (!user) {
      return res.status(400).json({
        statusCode: 404,
        data: null,
        message: null,
        error: "User not found!",
      });
    }

    // if(!user.is_logged_in == true){
    //   return res.send({
    //     statusCode: 404,
    //     data: null,
    //     message: null,
    //     error: "User Is Not Logged In",
    //   });
    // }

    user.is_logged_in = false;
   await user.save();
    return res.status(200).json({
      statusCode: 200,
      data: null,
      message: "Users logged Out successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} loginUser API response error:- ${error.message}]`
    );
    res.status(500).send({ error: error.message });
  }
};

module.exports.updateUserDetails = async (req, res, next) => {
  try {
    let updateUser = req.body;
    if (updateUser?.password) {
      delete updateUser.password;
    }
    const user = await User.update({ _id: req.user.id }, { $set: updateUser });
    logger.info(`[${UserController} updateUserDetails API response success]`);
    res.status(200).json({
      statusCode: 200,
      data: user,
      message: "User updated successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} updateUserDetails API response error:- ${error.message}]`
    );
    res.status(500).json({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};

// module.exports.deleteAllUsers = async (req, res, next) => {
//   try {
//     // Fetch all users
//     const users = await User.find({});

//     // Loop through each user and perform cascade delete operations
//     for (const user of users) {
//       await Promise.all([
//         ChatHistory.deleteMany({ user_id: user.email }),
//         Conversation.deleteMany({ user_id: user.email }),
//         Orders.deleteMany({ user_id: user.id }),
//         VideoConnectivty.deleteMany({ user_id: user.email }),
//         Wallet.deleteMany({ user_email: user.email }),
//         AudioConnectivty.deleteMany({ user_id: user.email }),
//         CreatorUserConversationMessage.deleteMany({ user_id: user.id })
//       ]);
//     }

//     // Delete all users
//     await User.deleteMany({});

//     logger.info(`[${UserController} deleteAllUsers API response success]`);
//     res.status(200).json({
//       statusCode: 200,
//       data: null,
//       message: "All Users and related data deleted successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[${UserController} deleteAllUsers API response error: ${error.message}]`);
//     res.status(500).json({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };


// module.exports.deleteUser = async (req, res, next) => {
//   try {
//     await
//     const user = await User.findByIdAndDelete(req.params.id);
//     logger.info(`[${UserController} deleteAllUsers API response success]`);
//     res.send({
//       statusCode: 200,
//       data: null,
//       message: "User Deleted Successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(
//       `[${UserController} updateUserDetails API response error:- ${error.message}]`
//     );
//     res.send({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

// module.exports.deleteUser = async (req, res, next) => {
//   try {
//     const userId = req.params.id;

//     // Fetch user details and delete user in parallel
//     const [user, fetch_user_details] = await Promise.all([
//       User.findByIdAndDelete(userId),
//       User.findById(userId)
//     ]);

//     // Cascade delete operations for related models
//     await Promise.all([
//       ChatHistory.deleteMany({ user_id: fetch_user_details.email }),
//       Conversation.deleteMany({ user_id: fetch_user_details.email }),
//       Orders.deleteMany({ user_id: fetch_user_details.id }),
//       VideoConnectivty.deleteMany({ user_id: fetch_user_details.email }),
//       Wallet.deleteMany({ user_email: fetch_user_details.email }),
//       AudioConnectivty.deleteMany({ user_id: fetch_user_details.email }),
//       CreatorUserConversationMessage.deleteMany({ user_id: fetch_user_details.id })
//     ]);

//     logger.info(`[${UserController} deleteUser API response success]`);
//     res.status(200).json({
//       statusCode: 200,
//       data: null,
//       message: "User and all related data deleted successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[${UserController} deleteUser API response error: ${error.message}]`);
//     res.status(500).json({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

// module.exports.deleteAccount = async (req, res, next) => {
//   try {
//     const { reason } = req.body;
//     const userId = req.user.id;

//     // Fetch user details and delete user in parallel
//     const [user, fetch_user_details] = await Promise.all([
//       User.findByIdAndDelete(userId),
//       User.findById(userId)
//     ]);

//     // Cascade delete operations for related models
//     await Promise.all([
//       ChatHistory.deleteMany({ user_id: fetch_user_details.email }),
//       Conversation.deleteMany({ user_id: fetch_user_details.email }),
//       Orders.deleteMany({ user_id: fetch_user_details.id }),
//       VideoConnectivty.deleteMany({ user_id: fetch_user_details.email }),
//       Wallet.deleteMany({ user_email: fetch_user_details.email }),
//       AudioConnectivty.deleteMany({ user_id: fetch_user_details.email }),
//       CreatorUserConversationMessage.deleteMany({ user_id: fetch_user_details.id })
//     ]);

//     // Create entry in DeletedUser collection
//     await DeletedUser.create({
//       user_id: fetch_user_details.id,
//       email: fetch_user_details.email,
//       name: `${fetch_user_details.first_name} ${fetch_user_details.last_name}`,
//       reason: reason
//     });

//     logger.info(`[${UserController} deleteUser API response success]`);
//     res.status(200).json({
//       statusCode: 200,
//       data: null,
//       message: "User and all related data deleted successfully",
//       error: null,
//     });
//   } catch (error) {
//     logger.error(`[${UserController} deleteUser API response error: ${error.message}]`);
//     res.status(500).json({
//       statusCode: 500,
//       data: null,
//       message: null,
//       error: error.message,
//     });
//   }
// };

module.exports.deletedReasonList = async (req, res, next) => {
  try {
    logger.info(
      `[${UserController} deletedReasonList API response success]`
    );
    const data = fs.readFileSync(
      path.join(__dirname, "../seeder/user_account_delete_reason_list.json"),
      "utf8"
    );
    res.send({
      statusCode: 200,
      data: JSON.parse(data),
      message: "User Account Delete Reason List Fetched Successfully",
      error: null,
    });
  } catch (error) {
    logger.error(
      `[${UserController} deletedReasonList API response error:- ${error.message}]`
    );
    res.send({
      statusCode: 500,
      data: null,
      message: null,
      error: error.message,
    });
  }
};