const { CreatorPDFDocument } = require("../models/CreatorPDFModel");

const logger = require("winston");

const CreatorPDFController = "CONVERSATION_CONTROLLER";

module.exports.getAllCreatorDocuments = async (req, res, next) => {
  try {
    const creator_document_data = await CreatorPDFDocument.find({});
    logger.info(
      `[${CreatorPDFController} getAllCreatorDocuments API response success]`
    );
    return res.send({
        statusCode: 200,
        data: creator_document_data,
        message: "All Creator Document Data Fetched Successfully",
        error: null,
      });
  } catch (error) {
    logger.error(
      `[${CreatorPDFController} getAllCreatorDocuments API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};

module.exports.addCreatorDocumentData = async (req, res, next) => {
  try {
    let conversation = await CreatorPDFDocument.create(req.body);
    await conversation.save();

    logger.info(
      `[${CreatorPDFController}] addCreatorDocumentData API response success`
    );
    return res.send({
        statusCode: 200,
        message: "Creator Document Added Successfully",
        error: null,
      });
  } catch (error) {
    logger.error(
      `[${CreatorPDFController} addCreatorDocumentData API response error:- ${error.message}`
    );
    res.send(500, { error: error.message });
  }
};
