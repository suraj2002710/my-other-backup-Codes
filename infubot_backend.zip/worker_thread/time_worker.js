const { parentPort } = require('worker_threads');

let timerId = null;
let startTime = null;

function millisecondsToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = hours < 10 ? "0" + hours : hours;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    return hours + ":" + minutes + ":" + seconds;
}

parentPort.on("message", ({ command, id, elapsedTime = 0 }) => {
    if (command === "start") {
        // If there's already a timer running, clear it first
        if (timerId !== null) {
            clearInterval(timerId);
        }
        
        startTime = Date.now() - elapsedTime; // Adjust startTime based on any elapsed time provided
        timerId = setInterval(() => {
            const currentTime = Date.now();
            const elapsed = currentTime - startTime;
            console.log(`Timer ${id} elapsed time: ${millisecondsToTime(elapsed)}`);
        }, 1000); // Update every second
    } else if (command === "stop" && id === id) {
        clearInterval(timerId);
        const stopTime = Date.now();
        const totalElapsedTime = stopTime - startTime;
        console.log(`Timer ${id} stopped. Total elapsed time: ${millisecondsToTime(totalElapsedTime)}`);
        // Send back the total elapsed time in milliseconds
        parentPort.postMessage({ id, stopped: true, duration: millisecondsToTime(totalElapsedTime) });
        timerId = null; // Reset the timerId to allow a new timer to be started
    }
});
