const { RtcTokenBuilder, RtmTokenBuilder, RtcRole, RtmRole } = require("agora-token");

const generateRtcToken = () => {
   // Rtc Examples
   const appId = "4905bd32493641b79e51a1692254dc4c";
   const appCertificate = "fde5bc6497e647ebabb12ef0c3114f84";
   const channelName = "aabbcc";
   const uid = 0;
   const userAccount = "test_user_id";
   const role = RtcRole.PUBLISHER;

   const expirationTimeInSeconds = 3600;

   const currentTimestamp = Math.floor(Date.now() / 1000);

   const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

   // IMPORTANT! Build token with either the uid or with the user account. Comment out the option you do not want to use below.

   // Build token with uid
   const tokenA = RtcTokenBuilder.buildTokenWithUid(appId, appCertificate, channelName, uid, role, privilegeExpiredTs);
   console.log("Token With Integer Number Uid: " + tokenA);

   // Build token with user account
   const tokenB = RtcTokenBuilder.buildTokenWithAccount(appId, appCertificate, channelName, userAccount, role, privilegeExpiredTs);
   console.log("Token With UserAccount: " + tokenB);
};
generateRtcToken();
