const { Kafka } = require('kafkajs')
let fs=require('fs');
let path=require('path');
let newPath=path.join(__dirname,'ca.pem');

const dotenv = require("dotenv");
const ENV_FILE = process.env.NODE_ENV || "development";
const envPath = `.env.${ENV_FILE}`;
console.log(envPath);
dotenv.config({ path: envPath });

let kafkaCred=ENV_FILE==='development'?{
  clientId: `${process.env.KAFKA_CLIENT_ID}`,
  brokers: [`${process.env.KAFKA_BROKER}`],
  ssl: {
    ca: fs.readFileSync(newPath, "utf-8"),
    rejectUnauthorized: false,

  },
  sasl: {
    mechanism: "plain",
    username: "avnadmin",
    password: "AVNS_xD5pUvS7j5cdylmEqIx",
 },
}:{
  clientId: `${process.env.KAFKA_CLIENT_ID}`,
  brokers: [`${process.env.KAFKA_BROKER}`],
  // ssl: {
  //   ca: fs.readFileSync(newPath, "utf-8"),
  // },
  // sasl: {
  //   mechanism: "plain",
  //   username: "avnadmin",
  //   password: "AVNS_088Aio3vBZebUHHcmlh",
  // },
}

console.log(kafkaCred);
 class KafkaConnection {
  constructor() {
    this.kafka = new Kafka(kafkaCred);
  }

   createTopic=async(topic, partition, replicationFactor)=> {
    try {
      const admin = this.kafka.admin();
      await admin.connect();
      await admin.createTopics({
        topics: [
          {
            topic,
            numPartitions: partition,
            replicationFactor,
          },
        ],
      });
      console.log("Topic created successfully......................................");
      await admin.disconnect();
    } catch (error) {
      console.log("Error creating topic:", error.message);
    }
  }

   generateProducer=async()=> {
    const producer = this.kafka.producer({allowAutoTopicCreation:true,metadataMaxAge: 300000});
    await producer.connect();
    return producer;
  }

   generateConsumer=async(groupId)=> {
    const consumer = this.kafka.consumer({ groupId });
    await consumer.connect();
    return consumer;
  }

   fetchTopicList=async()=> {
    try {
      const admin = this.kafka.admin();
      await admin.connect();
      const clusterMetadata = await admin.fetchTopicMetadata();
      const topics = clusterMetadata.topics
        .filter(topicMetadata => !topicMetadata.name.startsWith('_'))
        .map(topicMetadata => topicMetadata.name);
      await admin.disconnect();
      return topics;
    } catch (error) {
      console.error('Error fetching topic list:', error);
      return [];
    }
  }

   fetchTopicMetadata=async()=> {
    try {
      const admin = this.kafka.admin();
      await admin.connect();
      const data = await admin.fetchOffsets({
        groupId: "test-group",
        topics: ["doctor_creator1_calls"],
      });
      if (data) {
        console.log(data[0].partitions);
      }
      await admin.disconnect();
    } catch (error) {
      console.error('Error fetching topic metadata:', error);
      return {};
    }
  }
}

module.exports = KafkaConnection;