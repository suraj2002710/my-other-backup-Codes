const KafkaConnection = require("../connection/kafkaConnection");let { send_notification_to_creator_for_video_call } = require("../../notification_infra");
const { Creator } = require("../../models/Creator");
const { random_user_profile } = require("../../utilities/random_profile_images");
const QueueData = require("../../models/QueueData");

class KafkaService extends KafkaConnection {
   producer;
   consumer;
   consumers;
   worker;
   io;
   constructor() {
      super();
      this.producer = undefined;
      this.consumer = undefined;
      this.consumers = new Map();
      this.worker = undefined;
      this.initProducer();
   }

   //  init = () => {
   //    console.log("Socket is available in kafka service");
   //    this.io.to('65ef1b2001d045f26b2f21bb').emit('message', { message: 'Hello' })
   // };

   initProducer = async () => {
      try {
         this.producer = await this.generateProducer();
         console.log("Producer connected successfully...........");
      } catch (error) {
         console.error("Error initializing producer:", error);
      }
   };

   initConsumer = async (groupId) => {
      try {
         this.consumer = await this.generateConsumer(groupId);
         console.log("Consumer connected successfully...........");
         this.consumers.set(groupId, this.consumer);
      } catch (error) {
         console.error("Error initializing consumer:", error);
      }
   };

   startConsuming = async (topic, io) => {
      try {
         const consumer = this.consumers.get(topic);
         if (consumer) {
            console.log("Consumer subscribing to topic:", topic);
            await consumer.subscribe({ topic });
            await consumer.run({
               eachMessage: async ({ topic, partition, message }) => {
                  if (message.value) {
                     let isUserExist = await QueueData.findOne({ user_id: message.key.toString(),position_in_queue_when_insert_in_queue:JSON.parse(message.value).position_in_queue_when_insert_in_queue});

                     if (!isUserExist) {
                       console.log("...User is not in queue ..................");
                        return;
                     }
                     // if (isUserExist.position_in_queue > JSON.parse(message.value).position_in_queue){
                     //    console.log("or user is in queue but new position is less than previous position");
                     //    return;
                     // }
                     console.log("going to pause")
                     this.pauseConsumption(topic);

                     const messageData = JSON.parse(message.value);
                     const creator_details = await Creator.findById(messageData.creator_id);
                     if (!creator_details) {
                        return io.to(messageData.user_id).emit("send_message_error_occurred", {
                           message: "Creator doesn't exist",
                        });
                     }
                     if (!creator_details.is_creator_on_screen) {
                        console.log("call sent via notify")
                        this.sendNotification(JSON.parse(message.value));
                     } 
                     else {
                        console.log("call sent via message")

                        const notificationData = {
                           type: "video_call",
                           appId: process.env.AGORA_APP_ID,
                           video_token: messageData.agora_token,
                           channel_room: messageData.channel_room,
                           user_id: messageData.user_id,
                           video_id: messageData.video_id,
                           username: `${messageData.user_detail.first_name} ${messageData.user_detail.last_name}`,
                           user_profile_image: random_user_profile(),
                           user_wallet: messageData.user_wallet,
                           // user_wallet_balance
                        };
                        io.to(messageData.creator_id).emit("next_user_video_join", { callingData: { ...notificationData } });
                     }
                     io.to(messageData.user_id).emit("You_are_next", { message: "NEXT" });
                     // console.log({
                     //    key: message.key.toString(),
                     //    value: message.value.toString(),
                     //    offset: message.offset,
                     //    partition: partition,
                     //    topic: topic,
                     // });
                     
                  }
               },
            });
         } else {
            console.error("No consumer found for topic:", topic);
         }
      } catch (error) {
         console.error("Error consuming messages for topic:", topic, error);
      }
   };

   sendNotification = async (message) => {
      try {
         let { user_id, creator_id, channel_room, agora_token, video_id, user_detail, creator_detail,user_wallet } = message;

         const notify = await send_notification_to_creator_for_video_call(creator_detail, user_detail, {
            channel_room: channel_room,
            video_id: video_id,
            token: agora_token,
            user_wallet
         });
         if (notify) {
            console.log("Notification sent successfully");
         } else {
            console.log("Notification not sent");
         }
      } catch (error) {
         if (error instanceof Error) {
            console.log("Error sending notification:", error.message);
         }
      }
   };

   pauseConsumption = async (topic) => {
      try {
         const consumer = this.consumers.get(topic);
         if (consumer) {
            await consumer.pause([{ topic }]);
            console.log(`Consumer paused for topic: ${topic}`);
         } else {
            console.error(`Consumer not found for topic: ${topic}`);
         }
      } catch (error) {
         console.error("Error pausing consumption for topic:", topic, error);
      }
   };

   resumeConsumption = async (topic) => {
      try {
         const consumer = this.consumers.get(topic);
         if (consumer) {
            await consumer.resume([{ topic }]);
            console.log(`Consumer resumed for topic: ${topic}`);
         } else {
            console.error(`Consumer not found for topic: ${topic}`);
         }
      } catch (error) {
         console.error("Error resuming consumption for topic:", topic, error);
      }
   };

   deleteTopic = async (topic) => {
      try {
         const consumer = this.consumers.get(topic);
         if (consumer) {
            await consumer.disconnect();
            this.consumers.delete(topic);
            console.log(`Consumer for topic ${topic} stopped.`);
         }
      } catch (error) {
         console.log("Error deleting topic:", error.message);
      } finally {
         const admin = this.kafka.admin();
         await admin.connect();
         await admin.deleteTopics({
            topics: [topic],
         });
         console.log("Topic deleted successfully:", topic);

         await admin.disconnect();
      }
   };

   unSubscribe = async (topic) => {
      try {
         if (this.consumer) {
            // await this.consumer.unsubscribe({ topic });
            // await this.consumer.subscribe({ topic, fromBeginning:true});
            // console.log('Consumer unsubscribed from topic:', topic);
         }
      } catch (error) {
         console.error("Error unsubscribing:", error);
      }
   };

   produceMessage = async (topic, message, partition) => {
      try {
         if (this.producer) {
            await this.producer.connect();
            let data = await this.producer.send({
               topic: topic,
               messages: [{ key: message.user_id, value: JSON.stringify(message), partition: partition }],
            });
            console.log("Call sent successfully");
            return {
               status: true,
               message: data,
            };
         } else {
            console.log("Producer not found");
            await this.initProducer();
            return this.produceMessage(topic, message, partition);
         }
      } catch (error) {
         return {
            status: false,
            message: error.message,
         };
         console.error("Error producing message:", error);
      }
   };

   findMessageByKey = async () => {
      try {
      } catch (error) {
         if (error instanceof Error) {
            console.log("Error fetching message:", error.message);
         }
      }
   };

   listTopics = async () => {
      try {
         const admin = this.kafka.admin();
         await admin.connect();
         const topic = await admin.listTopics();
         return topic;
      } catch (error) {
         return [];
         console.error("Error fetching topics:", error);
      }
   };

   deleteTopic = async (topic) => {
      try {
         const consumer = this.consumers.get(topic);
         if (consumer) {
            await consumer.disconnect();
            this.consumers.delete(topic);
            console.log(`Consumer for topic ${topic} stopped.`);
         }
      } catch (error) {
         console.log("Error deleting topic:", error.message);
      } finally {
         const admin = this.kafka.admin();
         await admin.connect();
         await admin.deleteTopics({
            topics: [topic],
         });
         console.log("Topic deleted successfully:", topic);

         await admin.disconnect();
      }
   };
}

module.exports = KafkaService;
