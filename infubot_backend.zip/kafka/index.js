const kafkaService = require('./service/kafkaService');

let kafkaServiceInstance = new kafkaService();

console.log('Kafka Service Instance Created');
module.exports = kafkaServiceInstance;