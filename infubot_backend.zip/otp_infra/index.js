const crypto = require('crypto');
const {CreatorLoginOTP} = require("../models/CreatorOTPMapper");


async function generateOTP() {
    // Generate a 6-digit random number
    const otp = Math.floor(100000 + Math.random() * 900000);
    return otp.toString();
}

// Function to hash OTP
function hashOTP(otp, salt) {
    const hash = crypto.createHash('sha256').update(`${otp}${salt}`).digest('hex');
    return hash.substring(0, 10);
}

// Example of generating an OTP, hashing it, and storing it
async function generateHashAndStoreOTP(user_id, otp) {
    const hashedOTP = hashOTP(otp, user_id);
    // Storing the hashedOTP and user_id in the database
    try {
        const save_otp = await CreatorLoginOTP.create({
            id: user_id,
            otp: hashedOTP,
            is_valid: true,
        });
        if(save_otp){
            return true;
        }else{
            return false
        }
    } catch (error) {
        console.error('Error storing OTP:', error);
        return false;
    }
}

// Example of verifying a submitted OTP
async function verifyOTP(creator_id, submitted_otp) {
    console.log("Inside verify otp",creator_id, submitted_otp)
    try {
        // Fetch the stored hashed OTP for the user
        const fetch_otp_of_creator = await CreatorLoginOTP.findOne({
            id : creator_id,
            is_valid : true
        });

        if (!fetch_otp_of_creator) {
            console.log('No active OTP found for user.');
            return false;
        }

        // Hash the submitted OTP
        const hashedSubmittedOtp = hashOTP(submitted_otp, creator_id);

        // console.log("Stored Hash", storedOtpRecord.otp)
        // console.log("Generated Hash", hashedSubmittedOtp)

        // // Compare the hashed submitted OTP with the stored hashed OTP
        if (hashedSubmittedOtp === fetch_otp_of_creator.otp) {
            // Deactivate the OTP after successful verification
            // await storedOtpRecord.update({ is_active: false });
            fetch_otp_of_creator.is_valid = false;
            await fetch_otp_of_creator.save()
            return {
                status : true,
                message : "OTP Matched Successfully"
            }
        } else {
            console.log('OTP does not match.');
            // Optionally, deactivate OTP even on failure to prevent brute-force attempts
            // await storedOtpRecord.update({ is_active: false });
            // fetch_otp_of_creator.is_valid = false
            if(fetch_otp_of_creator.count && fetch_otp_of_creator.count > 3){
                fetch_otp_of_creator.is_valid = false;
                await fetch_otp_of_creator.save()
                return {
                    status : false,
                    message : "OTP Doesn't Match"
                }
            }else{
                fetch_otp_of_creator.count = fetch_otp_of_creator.count + 1
                await fetch_otp_of_creator.save()
                return {
                    status : false,
                    message : "OTP Checking Limit Exceeded"
                }
            }

        }
    } catch (error) {
        console.error('Error verifying OTP:', error);
        return false;
    }
}


module.exports = {
    generateOTP,
    generateHashAndStoreOTP,
    verifyOTP
}