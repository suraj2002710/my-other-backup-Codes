const router = require("express").Router();
const { Orders } = require("../../models/Orders");
const fs = require('fs');



router.get("/redirect", (req, res) => {
  console.log("Inside Return URL Get",req.query)
  return res.render('payment-success')
});




// router.post("/payment_link", async(req, res, next) => {
//     console.log("Inside Payment Link")
//     const order_id = req.body.data.link_id;
//     console.log("Order Id", order_id, req.body,req.body?.data.link_status);
//     const fetch_order_details = await Orders.findOne({order_id});
//     console.log("Order Details", fetch_order_details)
//     if(fetch_order_details){
//       if(req.body?.data.link_status == "PAID"){
//         fetch_order_details.txn_status = "success"
//       }else{
//         fetch_order_details.txn_status = "failed"
//       }
//       fetch_order_details.payment_method = "card"
//       fetch_order_details.save();
//       return res.render('payment-success')
//     }
// });

router.post("/payment_success", async(req, res, next) => {
  console.log("Payment Success", JSON.stringify(req.body,null,2));
  if(req.body?.type == "WEBHOOK"){
    return res.status(200).json({
      message : "Verified"
    })
  }
  if(req.body?.data?.order?.order_tags?.link_id){
  const order_id = req.body.data.order?.order_tags?.link_id;
  console.log("Order Id", order_id);
  const fetch_order_details = await Orders.findOne({order_id});
  console.log("Order Details", fetch_order_details,req.body.data.payment)
  if(req.body.data.payment?.payment_status == "SUCCESS"){
      fetch_order_details.txn_status = "success"
      if(req.body.data.payment?.payment_group == "net_banking"){
        fetch_order_details.payment_method = "Net Banking"
      }else if(req.body.data.payment?.payment_group == "debit_card"){
        fetch_order_details.payment_method = "Card"
      } else if(req.body.data.payment?.payment_group == "upi"){
        fetch_order_details.payment_method = "UPI"
      } else if(req.body.data.payment?.payment_group == "wallet"){
        fetch_order_details.payment_method = "Wallet"
      }
      await fetch_order_details.save()
      return res.render('payment-success') 
  }
  }else{
    res.status(400).json({
      message : "Something Went Wrong"
    })
  }
});

router.post("/payment_failed", async(req, res, next) => {
  console.log("Payment Failed", JSON.stringify(req.body,null,2));
  if(req.body?.type == "WEBHOOK"){
    return res.status(200).json({
      message : "Verified"
    })
  }

  if(req.body?.data?.order?.order_tags?.link_id){
    const order_id = req.body.data.order?.order_tags?.link_id;
    console.log("Order Id", order_id);
    const fetch_order_details = await Orders.findOne({order_id});
    console.log("Order Details", fetch_order_details)
    if(req.body.data.payment?.payment_status == "FAILED"){
        fetch_order_details.txn_status = "failed"
        if(req.body.data.payment?.payment_group == "net_banking"){
          fetch_order_details.payment_method = "Net Banking"
        }else if(req.body.data.payment?.payment_group == "debit_card"){
          fetch_order_details.payment_method = "Card"
        }else if(req.body.data.payment?.payment_group == "upi"){
          fetch_order_details.payment_method = "UPI"
        }else if(req.body.data.payment?.payment_group == "wallet"){
          fetch_order_details.payment_method = "Wallet"
        }
       await fetch_order_details.save()
        return res.render('payment-failed') 
    }
  }else{
    res.status(400).json({
      message : "Something Went Wrong"
    })
  }
});




  // router.post("/user_dropped_payment", (req, res, next) => {
  //   console.log("Inside Cahsfree Payment Auto Refund")
  //   console.log("Body", req.body);
  //   res.status(200).json({
  //     status : "Done"
  //   })
  // });

// router.post("/privacy_policy", CompanyPolicyController.changePrivacyPolicyApprovalText);

// router.post("/privacy_policy_approval_text", CompanyPolicyController.changePrivacyPolicy);


module.exports = router;
