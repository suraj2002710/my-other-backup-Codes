
const {sendEmail} = require("./mailer");
const {creator_multiple_times_login_mail_template, user_multiple_times_login_mail_template,send_otp_to_creator_for_login} = require("./templates")

const notifyAboutCreatorMultipeLogin = async(email,payload) => {
    const subject = "Multiple Login From Creator Detected"
    const get_template = await creator_multiple_times_login_mail_template(payload);
    const send_email = sendEmail(subject,get_template,email)
}

const notifyAboutUserMultipeLogin = async(email,payload) => {
    const subject = "Multiple Login From User Detected"
    const get_template = await user_multiple_times_login_mail_template(payload);
    const send_email = sendEmail(subject,get_template,email)
}

const notifyCreatorAboutLoginOTP = async(email,payload) => {
    const subject = "Login OTP"
    const get_template = await send_otp_to_creator_for_login(payload);
    const send_email = sendEmail(subject,get_template,email)
}

module.exports = {
    notifyAboutCreatorMultipeLogin,
    notifyAboutUserMultipeLogin,
    notifyCreatorAboutLoginOTP
}