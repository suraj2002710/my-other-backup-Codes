const creator_multiple_times_login_mail_template = async(data) => {
    // Assuming data object has properties: id, name, and email
    const { id, name, email } = data; // Destructure the needed properties

    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Creator Account Login Detected</title>
          <style>
              body {
                  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                  background-color: #f4f4f4;
                  margin: 0;
                  padding: 20px;
              }
              .email-container {
                  max-width: 600px;
                  margin: 20px auto;
                  padding: 20px;
                  background-color: #ffffff;
                  border-radius: 10px;
                  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
              }
              .header {
                  font-size: 20px;
                  color: #333333;
                  padding-bottom: 10px;
                  border-bottom: 2px solid #eeeeee;
                  margin-bottom: 20px;
              }
              .body-text {
                  font-size: 16px;
                  color: #666666;
                  line-height: 1.5;
              }
              .details {
                  background-color: #f9f9f9;
                  padding: 15px;
                  margin-top: 20px;
                  border-left: 4px solid #007bff;
                  font-size: 14px;
              }
              .footer {
                  font-size: 12px;
                  color: #999999;
                  text-align: center;
                  margin-top: 30px;
              }
          </style>
      </head>
      <body>
          <div class="email-container">
              <div class="header">Login Alert: Creator Account</div>
              <div class="body-text">
                  We detected multiple login attempts with your Creator account. Please review the details below to ensure your account's security:
                  <div class="details">
                      <strong>ID:</strong> ${id}<br>
                      <strong>Name:</strong> ${name}<br>
                      <strong>Email:</strong> ${email}
                  </div>
                  If you did not initiate these login attempts, we recommend updating your password immediately and contacting support.
              </div>
              <div class="footer">This is an automated message, please do not reply directly to this email.</div>
          </div>
      </body>
      </html>
    `;
};

  

const user_multiple_times_login_mail_template = async(data) => {
    const { id, name, email } = data; // Destructure the needed properties
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>User Account Login Detected</title>
          <style>
              body {
                  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                  background-color: #f4f4f4;
                  margin: 0;
                  padding: 20px;
              }
              .email-container {
                  max-width: 600px;
                  margin: 20px auto;
                  padding: 20px;
                  background-color: #ffffff;
                  border-radius: 10px;
                  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
              }
              .header {
                  font-size: 20px;
                  color: #333333;
                  padding-bottom: 10px;
                  border-bottom: 2px solid #eeeeee;
                  margin-bottom: 20px;
              }
              .body-text {
                  font-size: 16px;
                  color: #666666;
                  line-height: 1.5;
              }
              .details {
                  background-color: #f9f9f9;
                  padding: 15px;
                  margin-top: 20px;
                  border-left: 4px solid #007bff;
                  font-size: 14px;
              }
              .footer {
                  font-size: 12px;
                  color: #999999;
                  text-align: center;
                  margin-top: 30px;
              }
          </style>
      </head>
      <body>
          <div class="email-container">
              <div class="header">Security Alert: User Account Login</div>
              <div class="body-text">
                  We've detected multiple login attempts for your user account. The details of the attempt are as follows:
                  <div class="details">
                      <strong>ID:</strong> ${id}<br>
                      <strong>Name:</strong> ${name}<br>
                      <strong>Email:</strong> ${email}
                  </div>
                  If these attempts were not made by you, we strongly recommend securing your account by changing your password and reviewing your security settings.
              </div>
              <div class="footer">This email was automatically generated. Please do not reply to this email.</div>
          </div>
      </body>
      </html>
    `;
};

const send_otp_to_creator_for_login = async(data) => {
    const { creator, otp } = data; // Destructure the needed properties
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Login Verification</title>
          <style>
              body {
                  font-family: Arial, sans-serif;
                  background-color: #ffffff;
                  color: #333;
                  margin: 0;
                  padding: 0;
              }
              .email-container {
                  max-width: 600px;
                  margin: auto;
                  padding: 40px;
                  background: #f9f9f9;
              }
              .header {
                  color: #444444;
                  font-size: 22px;
                  margin-bottom: 30px;
                  text-align: center;
                  line-height: 1.2;
              }
              .body-content {
                  font-size: 16px;
                  line-height: 1.6;
                  background: #ffffff;
                  padding: 20px;
                  border: 1px solid #dddddd;
                  border-radius: 8px;
                  color: #555555;
              }
              .otp-code {
                  font-size: 20px;
                  font-weight: bold;
                  display: block;
                  text-align: center;
                  margin: 20px 0;
                  padding: 15px 0;
                  background-color: #e1f4f3;
                  color: #31A6A6;
                  border-radius: 5px;
              }
              .instructions {
                  font-size: 14px;
                  margin-top: 20px;
                  text-align: center;
                  color: #999999;
              }
              .footer {
                  font-size: 12px;
                  text-align: center;
                  color: #aaaaaa;
                  margin-top: 40px;
              }
          </style>
      </head>
      <body>
          <div class="email-container">
              <div class="header">Secure Login Verification</div>
              <div class="body-content">
                  Dear ${creator.first_name},<br><br>
                  A login attempt requires verification. Please use the following One-Time Password (OTP) to proceed:
                  <span class="otp-code">${otp}</span>
                  This OTP is valid for 10 minutes and is for one-time use only.<br><br>
                  If you did not initiate this login attempt, please change your password immediately and contact support for further assistance.
              </div>
              <div class="instructions">
                  Need help? Contact our support team.
              </div>
              <div class="footer">
                  &copy; ${new Date().getFullYear()} Your Brand. All rights reserved.
              </div>
          </div>
      </body>
      </html>
    `;
};



  

module.exports = {
    creator_multiple_times_login_mail_template,
    user_multiple_times_login_mail_template,
    send_otp_to_creator_for_login
}