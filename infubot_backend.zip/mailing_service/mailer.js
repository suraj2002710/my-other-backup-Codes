const nodemailer = require("nodemailer");
const { OTP } = require("../models/otp"); // Adjust the path to your OTP model file


// Function to send OTP via email
module.exports.sendEmail = async(subject,template,email) => {
  // Configure your SMTP transporter
  const transporter = nodemailer.createTransport({
    service: process.env.MAIL_SERVICE,
    auth: {
      user: process.env.MAIL_USER,
      pass: process.env.USER_PASS,
    },
  });

  // Email options
  const mailOptions = {
    from: process.env.FROM_MAIL,
    to: email,
    subject: subject,
    html : template
  };

  try {
    await transporter.sendMail(mailOptions);
    return true
  } catch (error) {
    console.error("Error sending email", error);
    return false
  }
}


