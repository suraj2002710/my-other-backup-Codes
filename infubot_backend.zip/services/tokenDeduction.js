// const { Creator } = require("../models/Creator");// const { CreatorBotSetting } = require("../models/CreatorBotSetting");// const { CreatorRevenueHistory } = require("../models/CreatorRevenueHistory");
// const { Wallet } = require("../models/Wallet");

// module.exports.deductToken = async (channelData, type) => {
//   try {
//     console.log("Deduct Token", channelData)
//     let wallet = await Wallet.findOne({ user_id: channelData.userId });
//     console.log("Wallet Details --->", wallet)
//     let creator = await Creator.findOne({ email: channelData.creatorId });
//     let creator_details = await CreatorBotSetting.findOne({
//       creator_id: creator._id,
//     });

//     let cost;
//     if (type === "audio") {
//       cost = parseInt(creator_details.cost_audio_per_min / 6);
//     } else if (type === "video") {
//       cost = parseInt(creator_details.cost_video_per_min / 6);
//     } else if (type === "ai") {
//       cost = parseInt(creator_details.cost_per_ai_msg);
//     } else {
//       cost = parseInt(creator_details.cost_per_msg);
//     }

//     // Check if wallet balance is sufficient
//     if (parseInt(wallet.wallet_balance) - cost < 0) {
//       console.log("Insufficient balance to deduct.");
//       return "Insufficient balance"; // Or handle as needed
//     }

//     let updated_balance = wallet.wallet_balance = parseInt(wallet.wallet_balance) - cost;

//     console.log("-------------------- DEDUCTING BALANCE--------------------", wallet, updated_balance);
//     await Wallet.findByIdAndUpdate(wallet._id, {
//       $set: { wallet_balance: updated_balance }, // Directly set updated_balance
//     });

//     CreatorRevenueHistory.create({
//       creator_email: channelData.creatorId,
//       user_email: channelData.userId,
//       creator_name: channelData.creatorName,
//       user_name: channelData.userName,
//       amount: cost,
//       type: type,
//     });

//     return updated_balance;
//   } catch (error) {
//     console.error("Error in deducting token:", error.message);
//     return error.message;
//   }
// };

const { Creator } = require("../models/Creator");
const { CreatorBotSetting } = require("../models/CreatorBotSetting");
const { CreatorRevenueHistory } = require("../models/CreatorRevenueHistory");
const { BaseRates } = require("../models/BaseRate");
const { Wallet } = require("../models/Wallet");
const { Transaction } = require("../models/Transaction");
const { User } = require("../models/Users");
const { CreatorEarning } = require("../models/creatorEarning");

module.exports.deductToken = async (channelData, type, duration = 0) => {
   // Default duration to 0 for types that don't use it
   try {
      console.log("Deduct Token", duration);

      const base_rate = await BaseRates.find({});

      const user = await User.findById(channelData.userId);
      if (!user) {
         console.log("User not found.");
         return {
            error: true,
            message: "User not found",
         };
      }

      const wallet = await Wallet.findOne({ user_id: channelData.userId });
      if (!wallet) {
         console.log("Wallet not found.");
         return {
            error: true,
            message: "Wallet not found",
         };
      }

      const creator = await Creator.findOne({ email: channelData.creatorId });
      if (!creator) {
         console.log("Creator not found.");
         return {
            error: true,
            message: "Creator not found",
         };
      }

      const creatorDetails = await CreatorBotSetting.findOne({
         creator_id: creator._id,
      });
      console.log("Creator Bot Settings", creatorDetails);
      if (!creatorDetails) {
         console.log("Creator details not found.");
         return {
            error: true,
            message: "Creator details not found",
         };
      }

      let cost;
      let creatorEarning;
      switch (type) {
         case "audio":
         case "audio":
            const cost_of_audio_per_sec = creatorDetails.cost_audio_per_min / 60; // Cost per second
            console.log("--------------------------------");
            console.log("Cost Of Creator Audio Per Second", cost_of_audio_per_sec);
            console.log("Call Duration", duration + " seconds");
            console.log("Total Cost Of User", cost_of_audio_per_sec * duration);
            console.log("--------------------------------");
            cost = cost_of_audio_per_sec * duration;
            break;
         case "video":
            const cost_of_video_per_sec = creatorDetails.cost_video_per_min / 60; // Cost per second
            console.log("--------------------------------");
            console.log("Cost Of Creator Video Per Second", cost_of_video_per_sec);
            console.log("Call Duration", duration + " seconds");
            console.log("Total Cost Of User", cost_of_video_per_sec * duration);
            console.log("--------------------------------");

            // Creator
            creatorEarning = await CreatorEarning.findOne({ creator_id: creatorDetails.creator_id });
            if (!creatorEarning) {
               CreatorEarning.create({
                  creator_id: creatorDetails.creator_id,
                  creator_earning: creatorDetails.cost_video_per_min,
                  earn_by_video_call: creatorDetails.cost_video_per_min,
               });
            } else {
               let updatedCreatorEarning = await CreatorEarning.findOneAndUpdate(
                  { creator_id: creatorDetails.creator_id },
                  {
                     $inc: { creator_earning: creatorDetails.cost_video_per_min, earn_by_video_call: creatorDetails.cost_video_per_min },
                  },
                  { new: true },
               );
            }

            // cost = cost_of_video_per_sec * duration;
            cost = Number(creatorDetails.cost_video_per_min);
            break;
         case "ai":
            console.log("--------------------------------");
            console.log("Cost Of Creator AI Message", parseInt(base_rate[0].base_cost_per_ai_msg));
            console.log("--------------------------------");

            console.log("sign up bonus ------------", wallet.sign_up_bonus);
            console.log(wallet.sign_up_bonus > 0);
            // let finalAmount = wallet.sign_up_bonus > 0 && wallet.sign_up_bonus <= 50;
            // Creator
            if (wallet.sign_up_bonus == 50||wallet.sign_up_bonus == 35||wallet.sign_up_bonus ==20 || wallet.sign_up_bonus == 5) {
               console.log("....................sign up bonus is 50 ..................");
               cost=15
            } else {
               creatorEarning = await CreatorEarning.findOne({ creator_id: creatorDetails.creator_id });
               if (!creatorEarning) {
                  CreatorEarning.create({
                     creator_id: creatorDetails.creator_id,
                     creator_earning:wallet.sign_up_bonus ==5 ?5:parseInt(base_rate[0].base_cost_per_ai_msg),
                     earn_by_ai_message:wallet.sign_up_bonus ==5 ?5:parseInt(base_rate[0].base_cost_per_ai_msg),
                  });
               } else {
                  let updatedCreatorEarning = await CreatorEarning.findOneAndUpdate(
                     { creator_id: creatorDetails.creator_id },
                     {
                        $inc: { creator_earning: parseInt(base_rate[0].base_cost_per_ai_msg),earn_by_ai_message: parseInt(base_rate[0].base_cost_per_ai_msg) },
                     },
                     { new: true },
                  );
               }
               cost = parseInt(parseInt(base_rate[0].base_cost_per_ai_msg) - parseInt(wallet.sign_up_bonus));
            }
 
            break;
         case "chat":
            console.log("--------------------------------");
            console.log("Cost Of Creator Message", parseInt(creatorDetails.cost_per_msg));
            console.log("--------------------------------");

            creatorEarning = await CreatorEarning.findOne({ creator_id: creatorDetails.creator_id });
            if (!creatorEarning) {
               CreatorEarning.create({
                  creator_id: creatorDetails.creator_id,
                  creator_earning: parseInt(creatorDetails.cost_per_msg),
                  earn_by_message: parseInt(creatorDetails.cost_per_msg),
               });
            } else {
               let updatedCreatorEarning = await CreatorEarning.findOneAndUpdate(
                  { creator_id: creatorDetails.creator_id },
                  {
                     $inc: { creator_earning: parseInt(creatorDetails.cost_per_msg), earn_by_message: parseInt(creatorDetails.cost_per_msg) },
                  },
                  { new: true },
               );
            }

            cost = parseInt(creatorDetails.cost_per_msg);
            break;
         default:
            console.log("Unsupported type for deduction.");
            return {
               error: true,
               message: "Unsupported type for deduction",
            };
      }

      console.log("Cost", cost);

      if (isNaN(cost) || cost <= 0) {
         console.log("Invalid cost calculation.");
         return {
            error: true,
            message: "Invalid cost calculation",
         };
      }

      if (wallet.wallet_balance+wallet.sign_up_bonus < cost) {
         console.log("Insufficient balance to deduct.", wallet.wallet_balance, cost);
         return {
            error: true,
            message: "Insufficient balance",
         };
      }

      const updatedBalance = wallet.wallet_balance - cost;
         
      console.log("-------------------- DEDUCTING BALANCE--------------------");

      console.log("Previous Balance", wallet.wallet_balance);
      console.log("Updated Deducted Balance", updatedBalance);

      if(type === "ai" && wallet.sign_up_bonus>0){
             if(wallet.sign_up_bonus==50){
               await Wallet.findByIdAndUpdate(wallet._id, {
                  $set: { sign_up_bonus:35},
               });
             }else if(wallet.sign_up_bonus==35){
               await Wallet.findByIdAndUpdate(wallet._id, {
                  $set: { sign_up_bonus:20},
               });
             }else if(wallet.sign_up_bonus==20){
               await Wallet.findByIdAndUpdate(wallet._id, {
                  $set: { sign_up_bonus:5},
               });
             }
             else{
               await Wallet.findByIdAndUpdate(wallet._id, {
               $set: { sign_up_bonus:0, wallet_balance:wallet.wallet_balance-10},
               });

             }
              console.log("Sign Up Bonus Updated");
     
      }else{
            await Wallet.findByIdAndUpdate(wallet._id, {
               $set: { wallet_balance: parseInt(updatedBalance) },
            });
         }
     

     if(type === "ai" && wallet.sign_up_bonus>0){
         if(wallet.sign_up_bonus==50){
            // await CreatorRevenueHistory.create({
            //    creator_email: channelData.creatorId,
            //    user_email: channelData.userId,
            //    creator_name: creatorDetails.creator_name,
            //    user_name: user.name,
            //    amount: 15,
            //    type: type,
            // });
         }
         else if(wallet.sign_up_bonus==35){

         }else if(wallet.sign_up_bonus==20){

         }
         else{
            await CreatorRevenueHistory.create({
               creator_email: channelData.creatorId,
               user_email: channelData.userId,
               creator_name: channelData.creatorName,
               user_name: channelData.userName,
               amount: 10,
               type: type,
               duration: type === "audio" || type === "video" ? duration : null, // Record duration only for audio/video
            });
         }
     }else{
      await CreatorRevenueHistory.create({
         creator_email: channelData.creatorId,
         user_email: channelData.userId,
         creator_name: channelData.creatorName,
         user_name: channelData.userName,
         amount: cost,
         type: type,
         duration: type === "audio" || type === "video" ? duration : null, // Record duration only for audio/video
      });


     }

      if (type == "audio" || type == "video") {
         let transaction_type;
         if (type == "audio") {
            transaction_type = "Audio";
         } else if (type == "video") {
            transaction_type = "Video";
         }
         console.log("Adding To Transaction");
         await Transaction.create({
            creator_email: creator.email,
            user_email: user.email,
            user_id: user.id,
            creator_id: creator.id,
            type: transaction_type,
            amount: cost,
         });
         console.log("Transaction Added Successfully");
      }

      if(type === "ai" && wallet.sign_up_bonus>0){
          if(wallet.sign_up_bonus==50){
            return {
               error: false,
               message: "Wallet Balance Deducted Successfully",
               data:wallet.wallet_balance+35,
            };
          }else if(wallet.sign_up_bonus==35){
            return {
               error: false,
               message: "Wallet Balance Deducted Successfully",
               data:wallet.wallet_balance+20,
            };
          }else if(wallet.sign_up_bonus==20){
            return {
               error: false,
               message: "Wallet Balance Deducted Successfully",
               data:wallet.wallet_balance+5,
            };
          }
            else{
               return {
                  error: false,
                  message: "Wallet Balance Deducted Successfully",
                  data: wallet.wallet_balance-20,
               };
            }
      }else{
         return {
            error: false,
            message: "Wallet Balance Deducted Successfully",
            data: parseInt(updatedBalance)+wallet.sign_up_bonus,
         };
      }
   } catch (error) {
      console.error("Error in deducting token:", error.message);
      return {
         error: true,
         message: error.message,
      };
   }
};
