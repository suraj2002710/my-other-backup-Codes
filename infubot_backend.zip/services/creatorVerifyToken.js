const jwt = require("jsonwebtoken");const { HashMapper } = require("../models/HashMapper");
let { Creator } = require("../models/Creator");

module.exports.creatorVerifyToken = async function (req, res, next) {
   try {
      const bearerHeader = req.headers["authorization"];
      const token = bearerHeader.split(" ")[1];
      console.log("called...... creator verification...............", token);

      // console.log("Token", token,req.body)
      if (!token)
         return res.send({
            statusCode: 401,
            data: null,
            message: null,
            error: "Access denied.",
         });
      const verified = await jwt.verify(token, process.env.CreatorSecretKey);
      console.log("Verified", verified);
      // req.creator = verified;
      if (verified) {
        console.log("inside in token .................",verified)
         const get_creator_id_from_hash_mapper = await HashMapper.findOne({
            secret_value: verified.id,
            active: true,
         });
       
         if (get_creator_id_from_hash_mapper) {
            req.creator = {
               id: get_creator_id_from_hash_mapper.id,
               // email: get_creator_id_from_hash_mapper.email,
               role: verified.role,
               iat: verified.iat,
            };

            // let isCreatorId=get_creator_id_from_hash_mapper.id;
            // if(isCreatorId){
            //   let getCreatorDetails = await Creator.findOne({ _id: isCreatorId });
            //   if(getCreatorDetails){
            //     if(getCreatorDetails.creator_login_token!==token||getCreatorDetails.creator_login_token==undefined){
            //       console.log("token mismatch.........")
            //       return res.send({
            //          statusCode: 401,
            //          data: null,
            //          message: null,
            //          error: "Token Mismatch",
            //       });
            //     }
                
            //   }else{
            //     console.log("no creator details found...")
            //   }
            // }
            // console.log("isCreatorId-----------------id....",isCreatorId)
         } else {
            return res.send({
               statusCode: 200, //403
               data: null,
               message: null,
               // error: "Malformed Token",
               error: null,
            });
         }
      }
   } catch (error) {
      return res.send({
         statusCode: 403,
         data: null,
         message: null,
         error: "Invalid Token",
      });
   }
   next();
};
