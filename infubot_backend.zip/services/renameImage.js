const fs = require("fs");

module.exports.renameImage = (file, name = false) => {
  let { originalname, destination, filename, path } = file;
  oldname = __basename + "/" + destination + "/" + filename;
  if (!name) {
    newname = __basename + "/" + destination + "/" + originalname;
  } else {
    originalname = name + "." + originalname.split(".").pop();
    newname = __basename + "/" + destination + "/" + originalname;
  }
  fs.rename(oldname, newname, () => {});
};
