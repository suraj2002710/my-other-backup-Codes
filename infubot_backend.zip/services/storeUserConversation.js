const { Conversation } = require("../models/Conversation");

const logger = require("winston");

const storeUserConversation = "STORE_USER_CONVERSATION";

module.exports.storeUserConversation = async (userDetails, intentDetail) => {
  try {



    const conversationBody = {
      user_id: userDetails?.channelData?.userId,
      creator_id: userDetails?.channelData?.creatorId,
      conversation_id: userDetails.conversation.id,
      user_message: userDetails.text,
      intent: intentDetail,
      webId: userDetails.channelId,
      activity: userDetails,
    };


    console.log("Conversation body", conversationBody,intentDetail)

    conversation = await Conversation.create(conversationBody);
  } catch (error) {
    logger.error(
      `[${storeUserConversation}] storeUserConversation error`,
      error
    );
  }
};
