const jwt = require("jsonwebtoken");
const { User } = require("../models/Users");
const {UserHolded} = require("../models/UserHolded")
const {HashMapper} = require("../models/HashMapper");

module.exports.userVerifyToken = async function (req, res, next) {
  try {
    const bearerHeader = req.headers["authorization"];
    const token = bearerHeader.split(" ")[1];
    if (!token)
      return res.send({
        statusCode: 401,
        data: null,
        message: null,
        error: "Access denied.",
      });
    const verified = await jwt.verify(token, process.env.UserSecretKey);
    console.log("Verified", verified)
    if(verified){
      const get_user_id_from_hash_mapper = await HashMapper.findOne({
        secret_value : verified.id,
        active : true
      });
      
      if(get_user_id_from_hash_mapper){
        const check_if_user_is_holded = await User.findById(get_user_id_from_hash_mapper.id);
        // if(check_if_user_is_holded.user_holded){
        //   const holdTime = new Date(check_if_user_is_holded.user_holded_at);
        //   const holdDuration = parseInt(process.env.HOLD_DURATION);
        //   const currentTime = new Date();
        //   holdTime.setMinutes(holdTime.getMinutes() + holdDuration);
        //   if (currentTime > holdTime) {
        //     await User.findByIdAndUpdate(get_user_id_from_hash_mapper.id, { user_holded: false });
        //     req.user = {
        //       id : get_user_id_from_hash_mapper.id,
        //       email : get_user_id_from_hash_mapper.email,
        //       role : verified.role,
        //       iat : verified.iat
        //     }
        //   } else {
        //     // If hold duration has not passed, send hold message
        //     return res.send({
        //       statusCode: 401,
        //       data: null,
        //       message: null,
        //       error: `You cannot access this API. You have been held for ${process.env.HOLD_DURATION} minutes.`,
        //     });
        //   }
        // }else{
        //   req.user = {
        //     id : get_user_id_from_hash_mapper.id,
        //     email : get_user_id_from_hash_mapper.email,
        //     role : verified.role,
        //     iat : verified.iat
        //   }
        // }
        req.user = {
          id : get_user_id_from_hash_mapper.id,
          // email : get_user_id_from_hash_mapper.email,
          role : verified.role,
          iat : verified.iat
        }
      }else{
        return res.send({
          statusCode: 401,
          data: null,
          message: null,
          error: "Malformed Token",
        });
      }
    }
  } catch (error) {
    return res.send({
      statusCode: 400,
      data: null,
      message: null,
      error: "Invalid Token",
    });
  }
  next();
};
