const admin = require("firebase-admin");

module.exports.sendAIInteractionNotification = async (creator, activity) => {
  try {
    const message = {
      notification: {
        title: "Your AI Mode is Live",
        body: "User is currently interacting with your AI Mode",
      },
      token: creator.fcm_token,
      data: {
        type: "ai_mode_chat",
        creatorId: activity.channelData.creatorId,
        creatorName: activity.channelData.creatorName,
        userConversationId: activity.channelData.userConversationId,
        userId: activity.channelData.userId,
        userName: activity.channelData.userName,
      },
    };

    console.log("Message", message)

    admin
      .messaging()
      .send(message)
      .then((response) => {
        return {
          statusCode: 200,
          data: null,
          message: "Notification send successfully!",
          error: null,
        };
      })
      .catch((error) => {
        console.log("---Error-----",error)
        return {
          statusCode: 400,
          data: null,
          message: null,
          error: error,
        };
      });
  } catch (error) {
    console.log("---Error",error)
    return {
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    };
  }
};
