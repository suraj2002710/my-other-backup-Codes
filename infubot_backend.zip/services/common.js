const axios = require("axios");
const logger = require("winston");
const url = "https://directline.botframework.com/v3/directline/tokens/generate";
const token = "H2cxW_fyy-I.2x5YFFjUxGvdJW5ezDcyn7Di9EKJPu1Vl7iH1jJp1-s";
const directLineUrl = "https://directline.botframework.com/v3/directline";
const tokenUrl = `${directLineUrl}/tokens/generate`;
const conversationUrl = `${directLineUrl}/conversations`;
const secretToken = "H2cxW_fyy-I.2x5YFFjUxGvdJW5ezDcyn7Di9EKJPu1Vl7iH1jJp1-s";

async function getMicrosoftToken() {
  try {
    const response = await axios.post(
      url,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}

async function createConversation() {
  try {
    const tokenResponse = await getMicrosoftToken();
    const conversationToken = tokenResponse.token;

    const response = await axios.post(
      conversationUrl,
      {},
      {
        headers: {
          Authorization: `Bearer ${conversationToken}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    logger.error("Error creating conversation", error);
    throw error;
  }
}

async function sendMessage(creator_conversation_id, user_conversation_id, creator_id, creator_name,token,creator_name,user_name,creator_email,user_email) {
  try {
    console.log(
      "----",
      `${directLineUrl}/conversations/${creator_conversation_id}/activities`,
      "-------------",
      JSON.stringify({
        from: { id: creator_id, name: creator_name },
        timestamp: "2024-01-24T06:43:08.482Z",
        type: "message",
        text: "Hi",
        channelData: {
          chatWith: "user",
          creatorConversationId: creator_conversation_id,
          userConversationId: user_conversation_id,
          userName: user_name,
          creatorName: creator_name,
          userId: user_email,
          creatorId: creator_email,
        },
      },null,2),
    );


    const response = await axios.post(
      `${directLineUrl}/conversations/${creator_conversation_id}/activities`,
      {
        from: { id: creator_id, name: creator_name },
        timestamp: new Date().toISOString(),
        type: "message",
        text: "Hi",
        channelData: {
          chatWith: "user",
          creatorConversationId: creator_conversation_id,
          userConversationId: user_conversation_id,
          userName: user_name,
          creatorName: creator_name,
          userId: user_email,
          creatorId: creator_email,
        },
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log("Error", error)
    logger.error("Error sending message", error);
    throw error;
  }
}

module.exports = {
  getMicrosoftToken,
  createConversation,
  sendMessage,
};
