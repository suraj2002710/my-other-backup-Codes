const jwt = require("jsonwebtoken");

module.exports.superAdminVerifyToken = async function (req, res, next) {
  try {
    const bearerHeader = req.headers["authorization"];
    const token = bearerHeader.split(" ")[1];
    if (!token)
      return res.send({
        statusCode: 401,
        data: null,
        message: null,
        error: "Access denied.",
      });
    const verified = jwt.verify(token, process.env.SuperAdminSecretKey);
    req.super_admin = verified;
  } catch (error) {
    return res.send({
      statusCode: 400,
      data: null,
      message: null,
      error: "Invalid Token",
    });
  }
  next();
};
