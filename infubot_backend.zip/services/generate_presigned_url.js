
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");


const s3 = new S3Client({
  region: process.env.AWS_S3_REGION,
  credentials: {
    accessKeyId: process.env.AWS_KEY,
    secretAccessKey: process.env.AWS_SECRET,
  },
});

async function generate_presigned_url(key) {
  const params = {
    Bucket: "influbot",
    Key: key,
    ResponseContentDisposition: "inline",
  };

  try {
    const command = new GetObjectCommand(params);
    return await getSignedUrl(s3, command, { expiresIn: 60 * 720 });
  } catch (error) {
    throw error;
  }
}

module.exports = {
    generate_presigned_url
}