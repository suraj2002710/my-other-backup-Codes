const Pushy = require('pushy');

const pushy = new Pushy('f5c1d94240392edb88ca25efbe96ca346381701834e77cee0a2a99ff0fd41209');




const send_notification = async (payload) => {
    const {data, to, options} = payload;
    console.log('Payload', data, to, options);

    if (!data || !to || !options) {
        throw new Error("Required field is missing");
    }

    // Wrap the pushy.sendPushNotification call in a Promise
    return new Promise((resolve, reject) => {
        pushy.sendPushNotification(data, to, options, function (err, result) {
            if (err) {
                console.error(err);
                reject(err); // Reject the Promise with the error
            } else {
                console.log('Push sent successfully! (ID: ' + result.id + ')');
                resolve(true); // Resolve the Promise with true
            }
        });
    });
};

const check_device_availability = async (token) => {
    // Wrap the pushy.getDevicePresence call in a Promise
    return new Promise((resolve, reject) => {
        pushy.getDevicePresence(token, function (err, devicePresence) {
            if (err) {
                console.error(err);
                reject(err); // Reject the Promise with the error
            } else {
                console.log('Device Presence: ', JSON.stringify(devicePresence, null, 2));
                resolve(devicePresence); // Resolve the Promise with the device presence data
            }
        });
    });
};


module.exports = {
    send_notification,
    check_device_availability
};













