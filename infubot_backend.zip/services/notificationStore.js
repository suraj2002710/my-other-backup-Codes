const mongoose = require("mongoose");
const { CallNotification } = require('../models/notificationHistory'); // Adjust the path as necessary

// Function to store a new call notification
const storeCallNotification = async (creatorEmail, userId, creatorId, callType, username, callId) => {
    try {
        const newNotification = new CallNotification({ 
            creator_email: creatorEmail, 
            creator_id: creatorId,
            call_type: callType, 
            call_id: callId,
            user_name: username,
            user_id: userId
        });

        await newNotification.save();
        console.log("Call notification stored successfully.");
    } catch (error) {
        console.error("Error storing call notification:", error.message);
    }
};

// Function to get notifications by creator email
const getNotificationsByCreatorEmail = async (creatorEmail) => {
    try {
        const notifications = await CallNotification.find({ creator_email: creatorEmail });
        return notifications;
    } catch (error) {
        console.error("Error retrieving notifications:", error.message);
        return [];
    }
};

// Export the functions
module.exports = {
    storeCallNotification,
    getNotificationsByCreatorEmail
};
