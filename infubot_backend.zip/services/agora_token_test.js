// const {
//   RtcTokenBuilder,
//   RtmTokenBuilder,
//   RtcRole,
//   RtmRole,
// } = require("agora-token");
// const axios = require("axios");
// const { v4: uuidv4 } = require('uuid');

// module.exports.generateAgoraTestToken = async (role) => {
//   try {

//     role == "publisher" ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER
//     console.log("Role", role)

//     // const role = RtcRole.PUBLISHER;
//     const expirationTimeInSeconds = 3600;
//     const currentTimestamp = Math.floor(Date.now() / 1000);
//     const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
//     const channel_room = uuidv4()

//     const token = RtcTokenBuilder.buildTokenWithUid(
//       process.env.AGORA_APP_ID,
//       process.env.AGORA_APP_CERTIFICATE,
//       channel_room,
//       '0',
//       role,
//       privilegeExpiredTs
//     );

//     return {
//       token,
//       channel_room
//     }
      
//   } catch (error) {
//     return error;
//   }
// };

const {
  RtcTokenBuilder,
  RtmTokenBuilder,
  RtcRole,
  RtmRole,
} = require("agora-token");
const axios = require("axios");
const { v4: uuidv4 } = require('uuid');

function generateRandom4DigitNumber() {
  const randomNumber = Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
  return randomNumber;
}

module.exports.generateAgoraTestToken = async (role) => {
  try {

    role == "publisher" ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER
    console.log("Role", role)

    // const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const channel_room =`agora_${generateRandom4DigitNumber()}` ///user name _ 4 digit number

    const token = RtcTokenBuilder.buildTokenWithUid(
      process.env.AGORA_APP_ID,
      process.env.AGORA_APP_CERTIFICATE,
      channel_room,
      '0',
      role,
      privilegeExpiredTs
    );

    return {
      token,
      channel_room
    }
      
  } catch (error) {
    return error;
  }
};


