const admin = require("firebase-admin");

//Pushy Setup
// const Pushy = require("pushy");
// const pushy = new Pushy(
//   "b603688ed570e21d66a27ab519aafe86f63d60a6a165be29f132741f53a124f5"
// );

module.exports.sendUnseenActivityNotifications = async (creator, activity) => {
  console.log("---", creator, activity)
  try {
    const message = {
      notification: {
        title: `${activity.channelData.userName}`,
        body: activity.text,
      },
      token: creator.fcm_token,
      data: {
        type: "chat",
        creatorId: activity.channelData.creatorId,
        creatorName: activity.channelData.creatorName,
        userConversationId: activity.channelData.userConversationId,
        userId: activity.channelData.userId,
        userName: activity.channelData.userName,
      },
    };

    console.log("Message", message)

    admin
      .messaging()
      .send(message)
      .then((response) => {
        return {
          statusCode: 200,
          data: null,
          message: "Notification send successfully!",
          error: null,
        };
      })
      .catch((error) => {
        console.log("---Error-----",error)
        return {
          statusCode: 400,
          data: null,
          message: null,
          error: error,
        };
      });
  } catch (error) {
    console.log("---Error",error)
    return {
      statusCode: 400,
      data: null,
      message: null,
      error: error,
    };
  }
};

// module.exports.sendUnseenActivityNotifications = async (creator, activity) => {
//   console.log("---", creator, activity);
//   try {
//     const data = {
//       message: activity.text,
//       type: "chat",
//       creatorId: activity.channelData.creatorId,
//       creatorName: activity.channelData.creatorName,
//       userConversationId: activity.channelData.userConversationId,
//       userId: activity.channelData.userId,
//       userName: activity.channelData.userName,
//       title: `${activity.channelData.userName}`,
//       body: activity.text,
//     };

//     const to = "86cb82fd7d639abe581ad8";

//     const options = {
//       notification: {
//         title: `${activity.channelData.userName}`,
//         body: activity.text,
//         badge: 1,
//         sound: "ping.aiff",
//       },
//     };

//     return new Promise((resolve, reject) => {
//       pushy.sendPushNotification(data, to, options, function (err, result) {
//         if (err) {
//           console.error(err);
//           reject({
//             statusCode: 400,
//             data: null,
//             message: null,
//             error: err,
//           });
//         } else {
//           console.log("Push sent successfully! (ID: " + result.id + ")");
//           resolve({
//             statusCode: 200,
//             data: null,
//             message: "Notification send successfully!",
//             error: null,
//           });
//         }
//       });
//     });
//   } catch (error) {
//     console.log("---Error", error);
//     return {
//       statusCode: 400,
//       data: null,
//       message: null,
//       error: error,
//     };
//   }
// };
