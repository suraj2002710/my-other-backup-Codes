const { RtcTokenBuilder, RtmTokenBuilder, RtcRole, RtmRole } = require("agora-token");

const AGORA_APP_ID = process.env.AGORA_APP_ID;
const AGORA_APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE;

module.exports.generateAgoraToken = async (channelName) => {
   try {
      const role = RtcRole.SUBSCRIBER;
      const expirationTimeInSeconds = 3600;
      const currentTimestamp = Math.floor(Date.now() / 1000);
      const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

      return RtcTokenBuilder.buildTokenWithUid(process.env.AGORA_APP_ID, process.env.AGORA_APP_CERTIFICATE, channelName, "0", role, privilegeExpiredTs);
   } catch (error) {
      return error;
   }
};
