const nodemailer = require("nodemailer");
const { OTP } = require("../models/otp"); // Adjust the path to your OTP model file

// Function to generate OTP
function generateOTP() {
  let otp = "";
  for (let i = 0; i < 6; i++) {
    otp += Math.floor(Math.random() * 10).toString();
  }
  return otp;
}

// Function to send OTP via email
async function sendOTPEmail(email) {
  const otp = generateOTP();

  // Configure your SMTP transporter
  const transporter = nodemailer.createTransport({
    service: process.env.MAIL_SERVICE,
    auth: {
      user: process.env.MAIL_USER,
      pass: process.env.USER_PASS,
    },
  });

  // Email options
  const mailOptions = {
    from: process.env.FROM_MAIL,
    to: email,
    subject: "Your OTP for Influbot Signup",
    // text: `Your OTP is: ${otp}\n\nPlease do not share this OTP with anyone. It is for validating your BotAl Chat signup completion.`,
    html : `
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            .email-container {
                font-family: Arial, sans-serif;
                color: #333333;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
                border: 1px solid #dddddd;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            }
            .header {
                font-size: 24px;
                margin-bottom: 20px;
            }
            .body-text {
                font-size: 16px;
                line-height: 1.5;
                margin-bottom: 25px;
            }
            .otp-code {
                font-size: 20px;
                font-weight: bold;
                color: #007bff;
                padding: 10px;
                border-radius: 5px;
                background-color: #f2f2f2;
                display: inline-block;
                margin-bottom: 20px;
            }
            .footer {
                font-size: 14px;
                color: #777777;
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="header">Your OTP for Influbot Signup</div>
            <div class="body-text">
                Hello,<br>
                Your One Time Password (OTP) for signing up to Influbot is:
            </div>
            <div class="otp-code">${otp}</div>
            <div class="body-text">
                Please do not share this OTP with anyone. It is for validating your Influbot signup completion.
            </div>
        </div>
    </body>
    </html>
    
    `
  };

  // Send email
  try {
    await transporter.sendMail(mailOptions);

    // Save the OTP to the database
    const newOTP = new OTP({
      email: email,
      otp: otp,
    });

    await newOTP.save();

    console.log(`OTP sent to ${email}`);
    return {
      otp: otp,
      email: email,
    };
  } catch (error) {
    console.error("Error sending OTP email:", error);
  }
}

module.exports = { sendOTPEmail };
