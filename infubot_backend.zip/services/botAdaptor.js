const { BotFrameworkAdapter } = require("botbuilder");

let botAdapter = null;

module.exports.create = function (done) {
  if (botAdapter) return done();

  botAdapter = new BotFrameworkAdapter({
    appId: process.env.MicrosoftAppID,
    appPassword: process.env.MicrosoftAppPassword,
  });
  return botAdapter;
};

module.exports.instance = function () {
  return botAdapter;
};
