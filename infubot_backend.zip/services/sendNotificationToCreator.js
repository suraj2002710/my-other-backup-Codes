const { CardFactory, TurnContext } = require("botbuilder");
const botAdapter = require("../services/botAdaptor");
const { Conversation } = require("../models/Conversation");
const { ChatHistory } = require("../models/ChatHistory");

const findActivity = async (conversation_id,recActivity) => {
  console.log("Conversation ID", conversation_id)
  try {
    let details = await Conversation.findOne({ conversation_id }).sort({
      createdAt: -1,
    });
    if(details && details?.activity){
      return details.activity;
    }
  } catch (error) {
    console.log(error);
  }
};

const sendNotificationToCreator = async (channelData, recActivity) => {
  let ref;
  if (channelData.chatWith === "creator") {
    ref = await findActivity(channelData.creatorConversationId,recActivity);
  } else {
    ref = await findActivity(channelData.userConversationId,recActivity);
  }


  console.log("reference", ref)

  const activity = {};

  if (recActivity.text) {
    activity.text = recActivity.text;
  }
  activity.channelData = channelData;

  const adapter = botAdapter.instance();

  const reference = TurnContext.getConversationReference(ref);

  await adapter.continueConversation(reference, async (turnContext) => {
    try {
      await turnContext.sendActivity(activity);
      if (recActivity.text) {


        console.log("Channel Data ...........", channelData)

        await ChatHistory.create({
          user_name: channelData.userName,
          creator_name: channelData.creatorName,
          user_id: channelData.userId,
          creator_id: channelData.creatorId,
          message_from: channelData.chatWith === "creator" ? "user" : "creator",
          message_text: recActivity.text,
          message_id: recActivity.id,
          user_conversation_id: channelData.userConversationId,
          from_ai : channelData.fromAI ? true : false
        });

        console.log("Chat History Added Successfully",{
          user_name: channelData.userName,
          creator_name: channelData.creatorName,
          user_id: channelData.userId,
          creator_id: channelData.creatorId,
          message_from: channelData.chatWith === "creator" ? "user" : "creator",
          message_text: recActivity.text,
          message_id: recActivity.id,
          user_conversation_id: channelData.userConversationId,
          from_ai : channelData.fromAI ? true : false
        })
      }
    } catch (error) {
      console.log(error);
      // logger.info(`Failed to send notification due to ${error.message}`, error);
    }
  });
};

module.exports = sendNotificationToCreator;
