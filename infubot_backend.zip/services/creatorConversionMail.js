const nodemailer = require("nodemailer");
const { OTP } = require("../models/otp"); // Adjust the path to your OTP model file



// Function to send OTP via email
async function sendConversionNotificationMailToCreator(email,username,password) {
  // Configure your SMTP transporter
  const transporter = nodemailer.createTransport({
    service: process.env.MAIL_SERVICE,
    auth: {
      user: process.env.MAIL_USER,
      pass: process.env.USER_PASS,
    },
  });

  // Email options
  const mailOptions = {
    from: process.env.FROM_MAIL,
    to: email,
    subject: "Welcome to Influbot: Your Creator Account Details",
    html: `
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                color: #4A4A4A;
                background-color: #F4F4F4;
                margin: 0;
                padding: 0;
            }
            .email-container {
                max-width: 600px;
                margin: 20px auto;
                padding: 20px;
                background-color: #FFFFFF;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .header {
                color: #007BFF;
                font-size: 22px;
                border-bottom: 2px solid #EEEEEE;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            .body-text {
                font-size: 16px;
                line-height: 1.6;
                margin-bottom: 20px;
            }
            .credentials {
                font-weight: bold;
                background-color: #F9F9F9;
                border-left: 4px solid #007BFF;
                padding: 10px;
                margin-bottom: 10px;
            }
            .note {
                font-size: 14px;
                color: #888888;
                margin-top: 20px;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="header">Your Influbot Creator Account is Ready!</div>
            <div class="body-text">
                Hello ${username},<br>
                We're excited to welcome you to the Influbot creator community! Your account has been set up and you can start using your credentials below to log in:
            </div>
            <div class="credentials">Username: ${username}</div>
            <div class="credentials">Password: ${password}</div>
            <div class="body-text">
                For your account's security, please change your password upon your first login. If you have any questions or require assistance, our support team is here to help.
            </div>
            <div class="note">
                This is an automated message, please do not reply directly to this email. For support, contact our helpdesk.
            </div>
        </div>
    </body>
    </html>
    `,
    attachments: [
        {
          filename: 'Contract.pdf', // Specify the file name of the PDF
          path: "Restaurant_Booking_Bot_SOW.pdf", // Provide the absolute path to the PDF file
        },
      ]
  };
  

  // Send email
  try {
    await transporter.sendMail(mailOptions);

    // Save the OTP to the database
  } catch (error) {
    console.error("Error sending OTP email:", error);
  }
}

module.exports = { sendConversionNotificationMailToCreator };
