const sendUserToAILog = "SEND_USER_TO_AI ./services";

const axios = require("axios");

const logger = require("winston");

module.exports.sendUserToAI = async (
  user_query,
  creator_email_id,
  user_email_id
) => {
  try {
    let data = JSON.stringify({
      question: user_query,
      creator_email_id,
      user_email_id,
    });

    let config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "", //todo
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    let res = await axios.request(config);

    //Store chat History in DB

    logger.info(`[${sendUserToAILog}] success`);
    return res.data;
  } catch (error) {
    logger.error(`[${sendUserToAILog}] error :- ${error.message}`);
  }
};
